#!/usr/bin/env python
# coding: utf-8

import os
from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='lapin',
    version='0.2.0',
    author='Laurent Gauthier, Antoine Laurent',
    author_email='lgauthier@agencemobilitedurable.ca, alaurent@agencemobilitedurable.ca',
    description='LAPI data analysis package',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://statdemontreal.visualstudio.com/Analyse%20de%20mobilit%C3%A9%20LAPI/_git/rev_saint_denis',
    license='GPL-3.0+',
    packages=['lapin', 'lapin.analysis', 'lapin.enhancement', 'lapin.figures', 'lapin.tools', 'lapin.transactions'],
    install_requires=[
        'adjusttext>=0.7.3',
        'contextily>=1.2.0',
        'folium>=0.14.0',
        'geopandas>=0.12.2',
        'geopy>=2.2.0',
        'importlib_resources>=5.4.0',
        'matplotlib>=3.5.0',
        'mapclassify>=2.5.0',
        'networkx>=3.0.0',
        'numba>=0.56',
        'numpy>=1.23',
        'openpyxl>=3.0',
        'osmnx>=1.3',
        'osrm-py>=0.5',
        'pandas>=1.5',
        'pathvalidate>=2.5',
        'pillow>=9.4',
        'psycopg2>=2.9.3',
        'pyodbc>=4.0',
        'requests>=2.28.0',
        'scikit-learn>=1.2.0',
        'scipy>=1.10',
        'seaborn>=0.12.2',
        'six>=1.16.0',
        'sqlalchemy>=1.4.28',
        'statsmodels>=0.13.0',
        ],
)
