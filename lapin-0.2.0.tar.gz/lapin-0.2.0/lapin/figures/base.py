# -*- coding: utf-8 -*-
"""
Created on Wed Jun  9 10:12:56 2021

This file contains generic functions used to create graphs and maps

@author: lgauthier
"""
import io
import copy
import numbers

from importlib_resources import files
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
from matplotlib import pylab
from mpl_toolkits.axes_grid1 import make_axes_locatable
import seaborn as sns
import geopandas as gpd
import shapely
import contextily as ctx
import numpy as np
import pandas as pd
import mapclassify
from adjustText import adjust_text
from rasterio.warp import transform_bounds

from . import colors
from . import config
from ..tools.geohelper import MONTREAL_CRS, UNIVERSAL_CRS, DEFAULT_CRS

##############
### Basemap
##############

def get_tile(source, west, sud, east, north, is_lat_lng=True):

    ghent_img, ghent_ext = ctx.bounds2img(w=west, s=sud, e=east, n=north,
                                     ll=is_lat_lng,
                                     source=source
                                    )
    return ghent_img, ghent_ext

"""Les tuiles mapbox obtenues à l'aide de contextily sont des static tiles, dont
la résolution dépend du niveau de zoom. Le niveau de zoom contrôle aussi les
bounds de la tuile.

Pour régler ce problème, on pourrait investiguer l'utilisation des vector tiles
de mapbox, qui ne peuvent être géré par contextily. La librairie suivante semble
être en mesure de les gérer:
    https://github.com/mapbox/vector-tile-base

"""

def rotate_fig_elements(ax, angle, o_x, o_y):
    r = mpl.transforms.Affine2D().rotate_deg_around(o_x, o_y, angle)
    for x in ax.images + ax.lines + ax.collections:
        trans = x.get_transform()
        x.set_transform(r+trans)
        if isinstance(x, mpl.collections.PathCollection):
            transoff = x.get_offset_transform()
            x._transOffset = r+transoff
    return r

def get_transformed_extents(ax, transform):
    xmin=None; xmax=None
    ymin=None; ymax=None
    for x in ax.collections:
        for path in x.get_paths():
            [p1x, p1y], [p2x, p2y] = path.transformed(transform=transform).get_extents().get_points()

            if xmin is None: xmin = p1x
            elif xmin > p1x: xmin = p1x

            if xmax is None: xmax = p2x
            elif xmax < p2x: xmax = p2x

            if ymin is None: ymin = p1y
            elif ymin > p1y: ymin = p1y

            if ymax is None: ymax = p2y
            elif ymax < p2y: ymax = p2y

    return xmin, ymin, xmax, ymax

def get_rotated_total_bounds(poly, rot, p=None, q=None, buffer=0):
    p = poly.centroid.x
    q = poly.centroid.y
    if rot <0:
        rot+=360
    xs = []
    ys = []
    for x, y in poly.convex_hull.exterior.coords:
        xs.append((x - p) * np.cos(rot) - (y - q) * np.sin(rot) + p)
        ys.append((x - p) * np.sin(rot) + (y - q) * np.cos(rot) + q)
    
    return min(xs)-buffer, min(ys)-buffer, max(xs)+buffer, max(ys)+buffer

def create_bounds_gdf(gdf, add_side_buffers=0):

    minx, miny, maxx, maxy = gdf.total_bounds

    p1 = shapely.geometry.Point(minx-add_side_buffers, maxy+add_side_buffers)
    p2 = shapely.geometry.Point(maxx+add_side_buffers, maxy+add_side_buffers)
    p3 = shapely.geometry.Point(maxx+add_side_buffers, miny-add_side_buffers)
    p4 = shapely.geometry.Point(minx-add_side_buffers, miny-add_side_buffers)

    np1 = (p1.coords.xy[0][0], p1.coords.xy[1][0])
    np2 = (p2.coords.xy[0][0], p2.coords.xy[1][0])
    np3 = (p3.coords.xy[0][0], p3.coords.xy[1][0])
    np4 = (p4.coords.xy[0][0], p4.coords.xy[1][0])

    bb_polygon = shapely.geometry.Polygon([np1, np2, np3, np4])

    df2 = gpd.GeoDataFrame(gpd.GeoSeries(bb_polygon), columns=['geometry'], crs=MONTREAL_CRS)

    bbox = df2.total_bounds

    return df2, bbox

def basemap_from_shapefile(bounds, background_color='#ffffff', figsize=(10,10),
                           dpi=config.MAP_DPI,
                           hydro_order=1, road_order=2,
                           hydro_path=config.HYDRO_SHAPE,
                           road_path=config.ROAD_SHAPE):

    df2, bbox = create_bounds_gdf(bounds)

    f, ax = plt.subplots(figsize=figsize, dpi=dpi)

    # hydro
    gpd.clip(gpd.read_file(hydro_path).to_crs(MONTREAL_CRS), df2)\
       .plot(
            color=colors.LAPIN_COLORS['HYDRO'],
            ax=ax,
            zorder=hydro_order
    )
    # road
    gpd.clip(gpd.read_file(road_path).to_crs(MONTREAL_CRS), df2)\
       .plot(
            color=colors.LAPIN_COLORS['ROADS'],
            ax=ax,
            alpha=0.33,
            zorder=road_order
    )

    ax.set_xlim(xmin=bbox[0], xmax=bbox[2])
    ax.set_ylim(ymin=bbox[1], ymax=bbox[3])

    ax.set_xticks([])
    ax.set_yticks([])

    ax.set_facecolor(background_color)

    return f, ax

def add_cbar(vmax, vmin, cmap, ax, bar_title='', tickslabels=None):

    norm = mpl.colors.Normalize(vmin=vmax, vmax=vmin)
    cmap = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)

    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="3%", pad=0.1)
    cbar = plt.colorbar(cmap, cax=cax)
    cbar.ax.set_ylabel(bar_title)

    if tickslabels != None:
        tick_locator = ticker.MaxNLocator(nbins=len(tickslabels)-1, )
        cbar.locator = tick_locator
        cbar.update_ticks()
        cbar.ax.set_yticklabels(tickslabels)

################################
### DEFAULT MAP PLOTING FUNC ###
################################

def _numerical_cuts(y, k=None, prec=0, base=1):
    numerical_cuts = {}
    if k:
        mc = mapclassify.NaturalBreaks(y, k)
    else:
        mc = mapclassify.NaturalBreaks(y)

    # round
    bins = np.round(base * np.ceil(mc.bins/base), prec)

    for i in range(len(mc.bins)):
        if i == 0 :
            numerical_cuts[config.LEGEND_LABEL['first'].format(int(bins[i]))] = bins[i]
        elif i == len(mc.bins) - 1:
            numerical_cuts[config.LEGEND_LABEL['last'].format(int(bins[i-1]))] = bins[-1]
        else:
            numerical_cuts[config.LEGEND_LABEL['middle'].format(int(bins[i-1]), int(bins[i]))] = bins[i]
    return numerical_cuts

def _numeric_color(labels, cmap):
    numeric_colors = {}
    labels_len = len(labels)

    for i in range(labels_len):
        numeric_colors[labels[i]] = cmap(1/labels_len * i)

    return numeric_colors

def plot_heat_map(data, path, crs='epsg:4326', lat_col='lat', lng_col='lng',
                  basemap=np.array([]), b_ext=np.array([]), fig_buffer=50,
                  dpi=config.MAP_DPI,
                  rotation=[0], compass_rose=False): 

    data = data.copy()
    data = gpd.GeoDataFrame(data, geometry=gpd.points_from_xy(data[lng_col], data[lat_col]), crs=crs)
    data = data.to_crs(MONTREAL_CRS)
    delim_gdf = gpd.GeoDataFrame(geometry=[data.unary_union.convex_hull], crs=data.crs)
    rotation = rotation[0] if len(rotation) > 0 else 0

    # plot map
    #    +   +---+-----------+
    # A  |   |   |           |
    #    +   +---+-------+   |
    #    |   |   |       |   |
    #    |   |   |       |   |
    # B  |   |   |       |   |     B = dy
    #    |   |   |       |   |     E = dx
    #    |   |   |       |   |
    #    +   |   +-------+   |
    # C  |   |               |
    #    +   +---------------+
    #
    #        +---+-------+---+
    #          D     E     F

    A = 0.1 ;  B = 0.8;  C = 0.1
    D = 0.1 ;  E = 0.8;  F = 0.1

    compass_multiplier = 1
    if compass_rose:
        compass_multiplier = 2
        A *= compass_multiplier
        D *= compass_multiplier
        E -= 0.1
        B -= 0.1


    fig, bg_ax = plt.subplots(figsize=(10, 10), dpi=dpi)
    data_ax = bg_ax.inset_axes([D, C, E, B], zorder=100, frameon=False)
    rose_ax = bg_ax.inset_axes([0.0, B+C, D, A], zorder=100, frameon=False)

    #data.plot(marker='o', color='blue', markersize=5, alpha=0.7, zorder=2, ax=data_ax)
    
    #set the limits - the tile query uses ax.axis() so setting the limits let
    #us control "how much we see" on the plot
    #because we might want to rotate the fig, at this point we'll query twice the
    #space we need
    minx,  miny,  maxx,  maxy = delim_gdf.total_bounds
    ominx, ominy, omaxx, omaxy = minx, miny, maxx, maxy

    # if rotation, double the tiles querried
    if rotation !=0:
        dx = maxx-minx;         dy = maxy-miny
        minx -= dx
        miny -= dy
        maxx += dx
        maxy += dy
    dx = maxx-minx;         dy = maxy-miny
    data_ax.set_xlim(xmin=minx, xmax=maxx)
    data_ax.set_ylim(ymin=miny, ymax=maxy)

    #calculate the bg limits
    dx2 = dx / E * F;    dy2 = dy / B * C
    bg_ax.set_xlim(xmin=minx-compass_multiplier*dx2, xmax=maxx+dx2)
    bg_ax.set_ylim(ymin=miny-dy2, ymax=maxy+compass_multiplier*dy2)

    def _reproj_bb(left, right, bottom, top, s_crs, t_crs):
        n_l, n_b, n_r, n_t = transform_bounds(s_crs, t_crs, left, bottom, right, top)
        return n_l, n_r, n_b, n_t 

    left, right, bottom, top = _reproj_bb(ominx, omaxx, ominy, omaxy, data.crs.to_string(), {"init": "epsg:4326"})
    zoom = ctx.tile._calculate_zoom(left, bottom, right, top)

    #query the tile
    #TODO: flip the basemap query into a function that should save the tile to cache or load it from there if it already exists
    ctx.add_basemap(data_ax, crs=data.crs.to_string(), source=config.CURRENT_TILE, zoom=min(config.CURRENT_TILE['max_zoom'],zoom))
    ctx.add_basemap(bg_ax, crs=data.crs.to_string(), source=config.CURRENT_TILE, zoom=min(config.CURRENT_TILE['max_zoom'],zoom))

    #apply the rotation
    x,y = delim_gdf.unary_union.centroid.x, delim_gdf.unary_union.centroid.y
    trans1 = rotate_fig_elements(data_ax, rotation, x, y)
    trans2 = rotate_fig_elements(bg_ax, rotation, x, y)

    #add the rose des vents
    if compass_rose:
        roseVent = mpl.pyplot.imread(files('lapin.figures.assets').joinpath('gite-la-rose-des-vents.png'))
        rose_ax.imshow(roseVent)
        rose_ax.axis('off')

        # I don't know why but rotation is inversed for image. Else north will not be in the good place
        rotate_fig_elements(
            rose_ax, -rotation,
            np.asarray(rose_ax.get_xlim()).mean(),
            np.asarray(rose_ax.get_ylim()).mean()
            )

    # reset the limits to default values (rotation)
    # if rotation we need to compute rotated limits.
    #       For example: -------            -----
    #                    |     | rot(90) -> |   |
    #                    -------            |   |
    #                                       -----
    if rotation != 0:
        ominx, ominy, omaxx, omaxy = delim_gdf.buffer(fig_buffer).rotate(rotation, origin=(x,y)).bounds.values[0]#get_rotated_total_bounds(delim_gdf.geometry.iloc[0], rotation, x, y, buffer=3)
    odx = omaxx-ominx;         ody = omaxy-ominy
    odx2 = odx / E * F;  ody2 = ody / B * C

    data_ax.set_xlim(xmin=ominx, xmax=omaxx)
    data_ax.set_ylim(ymin=ominy, ymax=omaxy)
    bg_ax.set_xlim(xmin=ominx-compass_multiplier*odx2, xmax=omaxx+odx2)
    bg_ax.set_ylim(ymin=ominy-ody2, ymax=omaxy+compass_multiplier*ody2)

    data['geometry'] = data.rotate(rotation, origin=(x, y))
    data.plot(marker='o', color='blue', markersize=5, alpha=0.7, zorder=2, ax=data_ax)

    # remove axes
    data_ax.axis('off')
    bg_ax.get_xaxis().set_visible(False)
    bg_ax.get_yaxis().set_visible(False)
    rose_ax.axis('off')

    # savefig
    fig.savefig(path.replace(':', '-'), bbox_inches='tight', format="PNG", dpi=dpi)
    plt.close()

def _generic_plot_map(data, col, delim, savepath, numeric_cuts=None,
                      mc_k=None, base=1, num_colors=None,
                      num_cmap=colors.LAPIN_PALETTES['OCC_BLUES'](as_cmap=True),
                      base_cat_colors=config.BASIC_CAT_COLORS,
                      basemap=np.array([]), b_ext=np.array([]),
                      add_cat_prc=False, build_leg=True,
                      dpi=config.MAP_DPI, anotate=False,
                      fig_buffer=100, rotation=0, compass_rose=False,
                      normalized_val=True,
                      gpd_kwd={}):
    """ Plot data of column 'col' on a map.

    Parameters
    ----------
    data : geopandas.GeoDataFrame
        The compiled occupancy with geobase double road segment.
    col : str
        Name of the column to use for plotting.
    delim : shapely.geometry.Polygon or Multipolygon
        Delimitation of the plot.
    savepath : str
        Path with name where to save the picture.
    numeric_cuts : dict. Default None.
        Dictionnary of numeric cuts to bin the data. Keys are labels
        and values are numeric cuts.
    mc_k : int. Default None.
        Parameter 'k' of mapClassifier used to automaticaly automaticaly create
        a num_cuts variable.
    num_colors: dict. Default None.
        Assign color to each labels of the numeric_cuts.
    num_cmap: matplotlib.cmap. Default 'Blues'.
        If num_colors is None, the cmap to use to color numeric_cuts.
    basemap : numpy.ndarray. Default []
        Basemap image.
    b_ext : numpy.ndarray. Default []
        Basemap extention.
    add_cat_prc : bool. Default False.
        If True, add the values of num_cuts in the legend.
    build_leg : bool. Default True.
        Is the legend needed to be plot with the figure or not ?
    fig_buffer : float
        A distance in meters to add around the data. This is important so the
        lines don't clip on the side of the plot which makes them hard to see.
        Default 100.
    rotation : float
        The angle of rotation (in degrees) to use to rotate the map. Usefull to
        reduce the page footprint of a map. On most N-S roads, an angle close to
        -53 should allow to create an horizontal map.
    dpi : int
        The resolution of the output.

    anotate
    """
    #TODO: remove the basemap and b_ext keywords, they're not used anymore
    if not isinstance(rotation, numbers.Number) or isinstance(rotation, bool):
        raise ValueError('`rotate` must be of type int or float, received {rotation.__class__}')

    data = data.copy()
    base_cat_colors = copy.deepcopy(base_cat_colors)

    delim_gdf = gpd.GeoDataFrame(geometry=[delim], crs=DEFAULT_CRS)
    data = data.to_crs('epsg:4326')
    delim_gdf = delim_gdf.to_crs('epsg:4326')
    
    data = gpd.sjoin(data, delim_gdf, predicate='within',  how='inner')
    if data.empty:
        return numeric_cuts, num_colors, base_cat_colors

    data = data.to_crs(MONTREAL_CRS)
    delim_gdf = delim_gdf.to_crs(MONTREAL_CRS)
    delim_gdf = delim_gdf.buffer(2).to_frame('geometry')
    try:
        data = data.rename_geometry('geometry')
    except ValueError:
        pass

    # grab all numeric data
    data_num = data[[pd.api.types.is_number(x) and not pd.isna(x) for x in data[col]]].copy()
    if pd.api.types.is_numeric_dtype(data[col].dtype):
        data_num = data[[not pd.isna(x) for x in data[col]]].copy()

    if not numeric_cuts:
        numeric_cuts = _numerical_cuts(data_num[col], k=mc_k, base=base)

    if add_cat_prc:
        numeric_cuts = {k+' ({:.2f}%)':v for k,v in numeric_cuts.items()}

    labels=list(numeric_cuts.keys())
    data_num['category'] = pd.cut(data_num[col], [0] + list(numeric_cuts.values()),
                                 labels=labels, include_lowest=True)
    # complete the labels
    if add_cat_prc:
        replace = {labels[i]:labels[i].format((data_num['category'] == labels[i]).sum() / data_num['category'].shape[0] * 100) for i in range(len(labels))}
        data_num['category'] = data_num['category'].map(replace)
        labels=list(replace.values())

    # grab all categorical data
    data_cat = pd.DataFrame()
    if not pd.api.types.is_numeric_dtype(data[col].dtype):
        data_cat = data[[not (pd.api.types.is_number(x) or pd.isna(x) ) for x in data[col]]].copy()
        data_cat['category'] = data_cat[col].copy()

    # grab all nan
    data_na = data[[pd.isna(x) for x in data[col]]].copy()
    data_na['category'] = ['Sans données' for i in range(data_na[col].shape[0])]

    # bin them
    data = pd.concat([data_num, data_cat, data_na])

    if not num_colors:
        num_colors = _numeric_color(labels, num_cmap)

    data['category'] = data['category'].astype(str)
    base_cat_colors = { key: base_cat_colors[key] for key in data['category'].unique() if key in base_cat_colors.keys()}
    catColors = dict(base_cat_colors, **num_colors)
    data['color_cat'] = data['category'].map(catColors)

    #drop whites, we purposefully can't see them and it messes up the rotation bounds
    data = data[~data.color_cat.isin(['white'])]
    data = data.iloc[::-1]

    # plot map
    #    +   +---+-----------+
    # A  |   |   |           |
    #    +   +---+-------+   |
    #    |   |   |       |   |
    #    |   |   |       |   |
    # B  |   |   |       |   |     B = dy
    #    |   |   |       |   |     E = dx
    #    |   |   |       |   |
    #    +   |   +-------+   |
    # C  |   |               |
    #    +   +---------------+
    #
    #        +---+-------+---+
    #          D     E     F

    A = 0.1 ;  B = 0.8;  C = 0.1
    D = 0.1 ;  E = 0.8;  F = 0.1

    compass_multiplier = 1
    if compass_rose:
        compass_multiplier = 2
        A *= compass_multiplier
        #D *= compass_multiplier
        #E -= 0.1
        B -= 0.1


    fig, bg_ax = plt.subplots(figsize=(10, 10), dpi=dpi)
    data_ax = bg_ax.inset_axes([D, C, E, B], zorder=100, frameon=False)
    rose_ax = bg_ax.inset_axes([D, B+C, A, A], zorder=100, frameon=False)

    data.plot(
        #column='category',
        color=data['color_cat'],
        #categorical=True,
        figsize=(12, 10),
        linewidth=2*200/dpi,
        zorder=2,
        ax=data_ax,
        **gpd_kwd
    )
   # delim_gdf.plot(
   #     facecolor='none',
   #     edgecolor='#36454F',
   #     linewidth=200/dpi,
   #     linestyle='--',
   #     zorder=3,
   #     ax=data_ax,
   # )

    if anotate:
        texts = []
        x,y = delim_gdf.unary_union.centroid.x, delim_gdf.unary_union.centroid.y
        data_num = data_num.to_crs(data.crs)
        data_num.geometry = data_num.rotate(rotation, origin=(x,y))
        for _, row in data_num.iterrows():
            if not row['geometry']:
                continue
            texts.append(data_ax.text(
                *row['geometry'].centroid.coords[0],
                s= int(np.round(row[col]*100,0)) if normalized_val else int(row[col]),
                alpha=0.7,
                fontsize=8
            ))

        adjust_text(texts)

    if build_leg:
        # add a legend
        _build_legend(
            bg_ax,title='Légende', title_color=colors.LAPIN_COLORS.LEG_TXT,
            bbox_to_anchor=(0.5, -0.01), loc='upper center',
            lignes_kwords=[{'label':str(k), 'color':v} for k,v in catColors.items()],
            align_title='left', ncol=(len(catColors) // 4 + int(len(catColors) % 4 > 0)),
            facecolor=colors.LAPIN_COLORS.LEGEND_BG, labelcolor=colors.LAPIN_COLORS.LEG_TXT
            )

    #set the limits - the tile query uses ax.axis() so setting the limits let
    #us control "how much we see" on the plot
    #because we might want to rotate the fig, at this point we'll query twice the
    #space we need
    minx,  miny,  maxx,  maxy = delim_gdf.total_bounds
    ominx, ominy, omaxx, omaxy = minx, miny, maxx, maxy
    # if rotation, double the tiles querried
    if rotation !=0:
        dx = maxx-minx;         dy = maxy-miny
        minx -= dx
        miny -= dy
        maxx += dx
        maxy += dy
    dx = maxx-minx;         dy = maxy-miny
    data_ax.set_xlim(xmin=minx, xmax=maxx)
    data_ax.set_ylim(ymin=miny, ymax=maxy)

    #calculate the bg limits
    dx2 = dx / E * F;    dy2 = dy / B * C
    bg_ax.set_xlim(xmin=minx-dx2, xmax=maxx+dx2)
    bg_ax.set_ylim(ymin=miny-dy2, ymax=maxy+compass_multiplier*dy2)

    def _reproj_bb(left, right, bottom, top, s_crs, t_crs):
        n_l, n_b, n_r, n_t = transform_bounds(s_crs, t_crs, left, bottom, right, top)
        return n_l, n_r, n_b, n_t 

    left, right, bottom, top = _reproj_bb(ominx, omaxx, ominy, omaxy, data.crs.to_string(), {"init": "epsg:4326"})
    zoom = ctx.tile._calculate_zoom(left, bottom, right, top)

    #query the tile
    #TODO: flip the basemap query into a function that should save the tile to cache or load it from there if it already exists
    ctx.add_basemap(data_ax, crs=data.crs.to_string(), source=config.CURRENT_TILE, zoom=min(config.CURRENT_TILE['max_zoom'],zoom))
    ctx.add_basemap(bg_ax, crs=data.crs.to_string(), source=config.CURRENT_TILE, zoom=min(config.CURRENT_TILE['max_zoom'],zoom))

    #apply the rotation
    x,y = delim_gdf.unary_union.centroid.x, delim_gdf.unary_union.centroid.y
    trans1 = rotate_fig_elements(data_ax, rotation, x, y)
    trans2 = rotate_fig_elements(bg_ax, rotation, x, y)

    #add the rose des vents
    if compass_rose:
        roseVent = mpl.pyplot.imread(files('lapin.figures.assets').joinpath('gite-la-rose-des-vents.png'))
        rose_ax.imshow(roseVent)
        rose_ax.axis('off')

        # I don't know why but rotation is inversed for image. Else north will not be in the good place
        rotate_fig_elements(
            rose_ax, -rotation,
            np.asarray(rose_ax.get_xlim()).mean(),
            np.asarray(rose_ax.get_ylim()).mean()
            )

    # reset the limits to default values (rotation)
    # if rotation we need to compute rotated limits.
    #       For example: -------            -----
    #                    |     | rot(90) -> |   |
    #                    -------            |   |
    #                                       -----
    if rotation != 0:
        ominx, ominy, omaxx, omaxy = delim_gdf.buffer(fig_buffer).rotate(rotation, origin=(x,y)).bounds.values[0] #get_rotated_total_bounds(delim_gdf.geometry.iloc[0], rotation, x, y, buffer=fig_buffer)
    odx = omaxx-ominx;         ody = omaxy-ominy
    odx2 = odx / E * F;  ody2 = ody / B * C

    data_ax.set_xlim(xmin=ominx, xmax=omaxx)
    data_ax.set_ylim(ymin=ominy, ymax=omaxy)
    bg_ax.set_xlim(xmin=ominx-odx2, xmax=omaxx+odx2)
    bg_ax.set_ylim(ymin=ominy-ody2, ymax=omaxy+compass_multiplier*ody2)

    # remove axes
    data_ax.axis('off')
    bg_ax.get_xaxis().set_visible(False)
    bg_ax.get_yaxis().set_visible(False)
    rose_ax.axis('off')

    # savefig
    fig.savefig(savepath.replace(':', '-'), bbox_inches='tight', format="PNG", dpi=dpi)
    plt.close()

    return numeric_cuts, num_colors, base_cat_colors

def _plot_leg(numeric_cuts, num_colors, save_path,
              base_cat_colors=config.BASIC_CAT_COLORS, dpi=config.LEG_DPI):
    """ Plot a legend in a separate figure.

    Parameters
    ----------
    numeric_cuts : dict.
        Dictionnary of numeric cuts to bin the data. Keys are labels
        and values are numeric cuts.
    num_colors : dict.
        Assignation colors to each label of the numeric_cuts.
    savepath : str.
        Path where to save the legend.
    base_cat_colors : dict.
        Base colors for legend.
    """

    # plot map
    fig, ax = plt.subplots(dpi=dpi)

    ax.scatter(x=[0,1], y=[1,0])

    # labels
    labels=list(numeric_cuts.keys())

    # assign colors
    catColors = dict(num_colors, **base_cat_colors)

    # add a legend
    leg = _build_legend(ax, title='Légende', title_color=colors.LAPIN_COLORS.LEG_TXT,
                      bbox_to_anchor=(0.5, -0.01), loc='upper center',
                      lignes_kwords=[{'label':str(k), 'color':v} for k,v in catColors.items()],
                      align_title='left', ncol=(len(catColors) // 4 + int(len(catColors) % 4 > 0)),
                      facecolor=colors.LAPIN_COLORS.LEGEND_BG, labelcolor=colors.LAPIN_COLORS.LEG_TXT
                      )

    fig.canvas.draw()
    bbox = leg.get_window_extent()
    bbox = bbox.transformed(fig.dpi_scale_trans.inverted())

    # remove axes
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    fig.savefig(save_path.replace(':', '-'), bbox_inches=bbox, format="PNG", dpi=dpi)
    plt.close()

    return 0


##############
### Fig Utils
##############
def suplabel(axis,label,label_prop=None,
             labelpad=5,
             ha='center',va='center'):
    ''' Add super ylabel or xlabel to the figure
    Similar to matplotlib.suptitle
    axis       - string: "x" or "y"
    label      - string
    label_prop - keyword dictionary for Text
    labelpad   - padding from the axis (default: 5)
    ha         - horizontal alignment (default: "center")
    va         - vertical alignment (default: "center")

    taken from https://stackoverflow.com/questions/6963035/pyplot-axes-labels-for-subplots
    '''
    fig = pylab.gcf()
    ax = pylab.gca() #attach it to an ax so tighlayout works
    xmin = []
    ymin = []
    for ax in fig.axes:
        xmin.append(ax.get_position().xmin)
        ymin.append(ax.get_position().ymin)
    xmin,ymin = min(xmin),min(ymin)
    dpi = fig.dpi
    if axis.lower() == "y":
        rotation=90.
        x = xmin-float(labelpad)/dpi
        y = 0.5
    elif axis.lower() == 'x':
        rotation = 0.
        x = 0.5
        y = ymin - float(labelpad)/dpi
    else:
        raise Exception("Unexpected axis: x or y")
    if label_prop is None:
        label_prop = dict()
    fig.text(x,y,label,rotation=rotation,
           transform=fig.transFigure,
           ha=ha,va=va,
           **label_prop)

def set_shared_ylabel(a, ylabel, labelpad = 0.01):
    """Set a y label shared by multiple axes
    Parameters
    ----------
    a: list of axes
    ylabel: string
    labelpad: float
        Sets the padding between ticklabels and axis label"""

    f = a[0].get_figure()
    f.canvas.draw() #sets f.canvas.renderer needed below

    # get the center position for all plots
    top = a[0].get_position().y1
    bottom = a[-1].get_position().y0

    # get the coordinates of the left side of the tick labels
    x0 = 1
    for at in a:
        at.set_ylabel('') # just to make sure we don't end up with multiple labels
        bboxes, _ = at.yaxis.get_ticklabel_extents(f.canvas.renderer)
        bboxes = bboxes.inverse_transformed(f.transFigure)
        xt = bboxes.x0
        if xt < x0:
            x0 = xt
    tick_label_left = x0

    # set position of label
    a[-1].set_ylabel(ylabel)
    a[-1].yaxis.set_label_coords(tick_label_left - labelpad,(bottom + top)/2, transform=f.transFigure)

##############
### Legend Utils
##############
def _make_legend_line(ldict):
    #pop those so we don't conflict with the dict unpacking
    color=ldict.pop('color', None)
    label=ldict.pop('label', None)
    #create the patch
    return mlines.Line2D([], [], color=color, label=label, **ldict)

def _make_legend_point(pdict):
    #pop those so we don't conflict with the dict unpacking
    markerfacecolor=pdict.pop('markerfacecolor', None)
    markeredgecolor=pdict.pop('markeredgecolor', None)
    color=pdict.pop('color', None)
    label=pdict.pop('label', None)
    marker=pdict.pop('marker', '.')
    #decide which color to use. If both are None then screw the user
    mcolor = markerfacecolor if markerfacecolor is not None else color
    ecolor = markeredgecolor if markeredgecolor is not None else color
    #create the patch
    return mlines.Line2D([], [], color=None, markerfacecolor=mcolor,
                         markeredgecolor=ecolor, linewidth=0, marker=marker,
                         label=label, **pdict)

def _make_legend_boxpatch(kdict):
    #pop those so we don't conflict with the dict unpacking
    color=kdict.pop('color', None)
    label=kdict.pop('label', None)
    boxstyle=kdict.pop('boxstyle', mpatches.BoxStyle("Round", pad=0.02))
    #create the patch
    return mpatches.FancyBboxPatch([0,0], 0.1, 0.1, color=color,
                                   label=label, boxstyle=boxstyle,
                                   **kdict)

def _build_legend(ax, title='Légende', bbox_to_anchor=(1.05, 1), loc='upper left',
                  title_color='black', lignes_kwords=[], points_kwords=[], kdes_kwords=[],
                  label_order=[], align_title='left', **kwargs
                  ):
    """Build a legend to be attached to a map figure.

    Parameters
    ----------
    ax : matplotlib.axes
        The axe to attach the legend to.

    title : str, optional
        The tile of the legend box.

        Default : 'Légende'

    bbox_to_anchor : tuple of floats, optional
        Box that is used to position the legend in conjunction with loc. See
        matplotlib.pyplot.legend for more informations.

        Default : (1.05, 1)

    loc : str, optional
        Location of the legend. See matplotlib.pyplot.legend for more informations.

        Default : 'upper left'

    title_color : str, optional
        The color of the legend title.

        Default : 'black'

    lignes_kwords : list of dicts, optional
        A list containing a dictionnary for every line entry to add to the legend.
        The dictionnary themselves must contain keywords compatible with
        matplotlib.lines.Line2D. Be sure to provide at least values for 'color'
        and 'label' otherwise the legend will feel really empty.

        Default : []

    points_kwords : list of dicts, optional
        A list containing a dictionnary for every point entry to add to the legend.
        The dictionnary themselves must contain keywords compatible with
        matplotlib.lines.Line2D. Be sure to provide at least values for 'color'
        and 'label' otherwise the legend will feel really empty.

        Default : []

    kdes_kwords : list of dicts, optional
        A list containing a dictionnary for every kde entry to add to the legend.
        The dictionnary themselves must contain keywords compatible with
        matplotlib.lines.Line2D. Be sure to provide at least values for 'color'
        and 'label' otherwise the legend will feel really empty.

        Default : []

    label_order : list of str, optional
        List of labels that should be put on top of the legend. The oder of the
        list is respected. Labels not part of this list are added in the
        dictionnaries's key order, starting with lines, then points and finally
        kdes.

        Default : []

    align_title : {'left', 'center', 'right'}, optional
        Force the alignement of the legend's title.

        Default : 'left'

    kwargs : dict, optional
        These parameters are passed to matplotlib.pyplot.legend

    Returns
    -------
    None

    Notes
    -----
    To merge multiple objects in the same legend, the keyword "multiple" can be
    used in either dictionnaries. The label is then used to group them as a
    single entity when building the legend patches. These objects don't need to
    be of the same type, tought combining them may require a certain order to
    give interesting results.

    """
    sorted_handles={}
    unsorted_handles=[]
    unsorted_handles_labels=[]

    memory={}
    #handle kde like patches
    for kdict in kdes_kwords:
        if kdict.pop("multiple", False):
            label=kdict.pop("label", None)
            if not label in memory.keys():
                memory[label] = []
            #create the patch with no label and save it to memory
            memory[label].append(_make_legend_boxpatch(kdict))

        else:
            #create the patch
            kde_patch = _make_legend_boxpatch(kdict)
            #add it to the correct list
            label = kde_patch.get_label()
            if label in label_order and label is not None:
                sorted_handles[label] = kde_patch
            else:
                unsorted_handles.append(kde_patch)
                unsorted_handles_labels.append(label)

    #handle lines
    for ldict in lignes_kwords:
        if ldict.pop("multiple", False):
            label=ldict.pop("label", None)
            if not label in memory.keys():
                memory[label] = []
            #create the patch with no label and save it to memory
            memory[label].append(_make_legend_line(ldict))

        else:
            #create the patch
            ligne_patch = _make_legend_line(ldict)
            #add it to the correct list
            label = ligne_patch.get_label()
            if label in label_order and label is not None:
                sorted_handles[label] = ligne_patch
            else:
                unsorted_handles.append(ligne_patch)
                unsorted_handles_labels.append(label)

    #handle points
    for pdict in points_kwords:
        if pdict.pop("multiple", False):
            label=pdict.pop("label", None)
            if not label in memory.keys():
                memory[label] = []
            #create the patch with no label and save it to memory
            memory[label].append(_make_legend_point(pdict))

        else:
            #create the patch
            point_patch = _make_legend_point(pdict)
            #add it to the correct list
            label = point_patch.get_label()

            if label in label_order and label is not None:
                sorted_handles[label] = point_patch
            else:
                unsorted_handles.append(point_patch)
                unsorted_handles_labels.append(label)

    #handle memorized patches
    if len(memory.keys()) > 0:
        for key in memory.keys():
            if key in label_order and key is not None:
                sorted_handles[key] = tuple(memory[key])
            else:
                unsorted_handles.append(memory[key])
                unsorted_handles_labels.append(key)

    #sort the handles' order
    handles = [sorted_handles[key] for key in label_order] + unsorted_handles
    labels = label_order + unsorted_handles_labels

    #generate the legend
    leg = ax.legend(handles, labels, loc=loc, bbox_to_anchor=bbox_to_anchor,
                    fancybox=True, title=title,
                    handler_map={tuple: mpl.legend_handler.HandlerTuple(ndivide=None)}, **kwargs)

    leg._legend_box.align = align_title

    plt.setp(leg.get_title(), color=title_color)

    return leg

def analysis_zone_map(
        delims, savepath='cache/', split_delims=False, add_geom=None,
        rotation=None, fig_buffer=None, map_dpi=config.MAP_DPI,
        leg_dpi=config.LEG_DPI):
    #TODO: this function needs to copie the calls to the ctx.basemap method
    #      and annotate the names of the sectors on the map
    #
    #      add_geom is used to add custom geometries to show some features
    #      relevant to the study zone
    #
    #      if split_delim: generate different figures for each part of the
    #      delim key list
    """ Plot a basemap of the analysis zone.

    Parameters
    ----------
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str
        Where to save the images. In total there will be n_cols x n_delims figs.
    """
    rotation = xform_list_entre_to_dict(rotation, list(delims.keys()), default=0, valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, list(delims.keys()), default=100, valueVarName='fig_buffer')

    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        for col in cols:
            path = os.path.join(savepath, f"taux_occupation_{zone}_colonne_{col}.png")
            n_cuts, n_colors, base_colors = base._generic_plot_map(
                occ_df, col, delim, path,
                numeric_cuts=config.OCC_NUM_CUTS,
                num_colors=config.OCC_COLORS,
                base_cat_colors=config.BASIC_CAT_COLORS,
                basemap=basemap, b_ext=b_ext,
                add_cat_prc=add_cat_prc, build_leg=build_leg,
                anotate=anotate, dpi=map_dpi,
                rotation=rotation[zone],
                fig_buffer=fig_buffer[zone]
            )
            # legend
            os.makedirs(os.path.join(savepath, 'legends'), exist_ok=True)
            leg_path = os.path.join(os.path.join(savepath, "legends"), f"taux_occupation_{zone}_colonne_{col}.png")
            base._plot_leg(n_cuts, n_colors, leg_path, base_cat_colors=base_colors, dpi=leg_dpi)

##############
### Maps Utils
##############
def _plot_linestrings_linewidths_on_values(ax, geoms, values=None, **kwargs):
    """
    Plots a collection of LineString and MultiLineString geometries to `ax`
    This code was adapted from geopandas.plotting.plot_linestring_collection
    since geopandas only aims to match colors with values.
    Parameters
    ----------
    ax : matplotlib.axes.Axes
        where shapes will be plotted
    geoms : a sequence of `N` LineStrings and/or MultiLineStrings (can be
            mixed)
    values : a sequence of `N` values, optional
        Values will be mapped to linewidths using vmin/vmax/cmap. They should
        have 1:1 correspondence with the geometries (not their components).
        Default : None
    kwargs : dict, optional
        These paramters are passed to matplotlib.LineCollection when tracing the
        segments.

    Returns
    -------
    collection : matplotlib.collections.
        The collection of lines that were plotted
    """
    from matplotlib.collections import LineCollection

    geoms, multiindex = gpd.plotting._flatten_multi_geoms(geoms, range(len(geoms)))

    if values is not None:
        values = np.take(values, multiindex)

    # LineCollection does not accept some kwargs.
    if "markersize" in kwargs:
        del kwargs["markersize"]

    segments = [np.array(linestring)[:, :2] for linestring in geoms]
    collection = LineCollection(segments, **kwargs)

    if values is not None:
        collection.set_linewidths(np.asarray(values))

    ax.add_collection(collection)

    return collection

def _get_single_extents(gdf, force_square=False):
    """A utility wrapper around seaborn's kdeplot which does the necessary
    geometric transformations before plotting.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        The fram to calculate the extent on.

    Returns
    -------
    bounds : list2D of int
        The extents, as [[minx, maxx], [miny, maxy]]
    """
    bounds = gdf.geometry.bounds

    xspan = bounds.maxx.max() - bounds.minx.min()
    yspan = bounds.maxy.max() - bounds.miny.min()

    if not force_square or xspan == yspan:
        return [bounds.minx.min(), bounds.maxx.max(),
                bounds.miny.min(), bounds.maxy.max()]

    if xspan > yspan:
        ymid = (bounds.maxy.max() + bounds.miny.min()) / 2

        return [bounds.minx.min(), bounds.maxx.max(),
                ymid - xspan/2,    ymid + xspan/2]

    xmid = (bounds.maxx.max() + bounds.minx.min()) / 2

    return [xmid - yspan/2,    xmid + yspan/2,
            bounds.miny.min(), bounds.maxy.max()]

def _get_extents(*gdfs, force_square=False):

    if not isinstance(gdfs, list):
        gdfs = [gdfs]

    boxes=[]
    for gdf in gdfs:
        if isinstance(gdf, (gpd.geodataframe.GeoDataFrame, gpd.geoseries.GeoSeries)):
            minx, maxx, miny, maxy = _get_single_extents(gdf, force_square=force_square)
            boxes.append(shapely.geometry.box(minx, miny, maxx, maxy))

    return _get_single_extents(gpd.GeoSeries(boxes), force_square=force_square)

def _harmonize_crs(*gdfs):

    if not isinstance(gdfs, list):
        return gdfs, gdfs.crs

    crs = gdfs[0].crs
    for i in range(1, len(gdfs)):
        gdfs[i] = gdfs[i].to_crs(crs)

    return gdfs, crs

def create_extent_gdf(*gdfs, force_square=False):

    gdfs, crs = _harmonize_crs(gdfs)
    bbox = _get_extents(gdfs, force_square=force_square)

    p1 = shapely.geometry.Point(bbox[0], bbox[3])
    p2 = shapely.geometry.Point(bbox[2], bbox[3])
    p3 = shapely.geometry.Point(bbox[2], bbox[1])
    p4 = shapely.geometry.Point(bbox[0], bbox[1])

    np1 = (p1.coords.xy[0][0], p1.coords.xy[1][0])
    np2 = (p2.coords.xy[0][0], p2.coords.xy[1][0])
    np3 = (p3.coords.xy[0][0], p3.coords.xy[1][0])
    np4 = (p4.coords.xy[0][0], p4.coords.xy[1][0])

    bb_polygon = shapely.geometry.Polygon([np1, np2, np3, np4])

    bounds_shape = gpd.GeoDataFrame(gpd.GeoSeries(bb_polygon), columns=['geometry'], crs=crs)

    return bounds_shape, bbox

def creer_fond_de_carte(data,
                       hydro_path,
                       road_path,
                       background_color='#ffffff',
                       hydro_color='#lightgray',
                       road_color='#36454f',
                       figsize=(10,10), dpi=config.MAP_DPI,
                       hydro_order=1, road_order=2):

    bounds, bbox = create_extent_gdf(data)

    f, ax = plt.subplots(figsize=figsize, dpi=dpi)

    # hydro
    gpd.clip(gpd.read_file(hydro_path).to_crs(MONTREAL_CRS), bounds)\
       .plot(
            color=hydro_color,
            ax=ax,
            zorder=hydro_order
    )
    # road
    gpd.clip(gpd.read_file(road_path).to_crs(MONTREAL_CRS), bounds)\
       .plot(
            color=road_color,
            ax=ax,
            alpha=0.33,
            zorder=road_order
    )

    ax.set_xlim(xmin=bbox[0], xmax=bbox[2])
    ax.set_ylim(ymin=bbox[1], ymax=bbox[3])

    ax.set_xticks([])
    ax.set_yticks([])

    ax.set_facecolor(background_color)

    return f, ax

##############
### Generic figs
##############
def plot_stacked_charge_graphs(charges,
                               groupnames,
                               x=None,
                               colormap=None,   #THIS MUST CONTAIN THE EXACT NUMBER OF COLORS!
                               ticklabels=None,
                               title=None,
                               xlabel=None,
                               ylabel=None,
                               ax=None,
                               legend_kwargs=False,
                               return_fig=False,
                               return_handles=False,
                               figsize=(12.65, 9.49)
                               ):
    """This is a base canevas for plotting "provenance" load graphs.

    These graphs being in need of complicated legend objects, this function is
    only a frame and does not provide the full capabilities found in it's API
    equivalent functions.

    Parameters
    ----------
    charges : 2dlist
        Number of people onboard for evey item in `ticklabels`. The second
        dimension of the 2dlist should be consistent with the dimension of
        `groupnames`.

    groupnames : list of str
        The name of the different surfaces.

    x : 1dlist, optional
        Axes on top of which data is drawn.

        Default : None

    colormap : list of matplotlib.pyplot.colormap or None, optional
        The colors to assign to the surfaces. This should be the same dimension
        as `groupnames`.  If None, uses matplotlib default colorcycle.

        Default : None

    ticklabels : list of str or None, optional
        The stop labels to assign on the x-axis of the plot. If None, the default
        matplotlib ticklabels are left intact, which means ``range(len(charges[0]))``.

        Default : None

    title : str or None, optional
        The graph title.
        Default : None

    legend_kwargs : dict or None, optional
        If a dict is provided, triggers the creation of a legend via matplotlib.pyplot.legend
        using the options provided. An empty dict will use the default matplotlib
        settings for a legend

        Default : False

    return_fig : bool, optional
        If True, the returned tuple starts with a figure maplotlib.pyplot.figure
        object. (ie: fig, ax, ...)
        Default : False

    return_handles : bool, optional
        If true, the returned tuple ends with a maplotlib.pyplot.PolyCollection
        objects containing handles to the surfaces of the stackplot.
        (ie: ..., ax, handles)

        Default : False
    Returns
    -------
    ax : maplotlib.pyplot.axes.Axes

    """
    #produce the fig

    with sns.axes_style("darkgrid"):
        fig, ax = plt.subplots(figsize=figsize)

        if x is not None:
            handle = ax.stackplot(x, charges, labels=groupnames, colors=colormap)
        else:
            handle = ax.stackplot(range(len(charges[0])), *charges, labels=groupnames, colors=colormap)

        if xlabel is not None:
            ax.set_xlabel(xlabel, size=14)

        if ylabel is not None:
            ax.set_ylabel(ylabel, size=14)

        if title is not None:
            ax.set_title(title, size=14)

        if ticklabels is not None:
            ax.set_xticks(range(len(ticklabels)))
            ax.set_xticklabels(ticklabels, rotation=90, ha='center')

        if legend_kwargs is not None:
            ax.legend(**legend_kwargs)

        #ax.grid(color='grey', linestyle='dashed')
        ax.set_axisbelow(True)

    out=[]
    if return_fig:
        out.append(fig)
    out.append(ax)
    if return_handles:
        out.append(handle)

    return out