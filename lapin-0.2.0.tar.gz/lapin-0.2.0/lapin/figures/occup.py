# -*- coding: utf-8 -*-
"""
Created on Wed Jun  9 10:12:56 2021

@author: lgauthier
@author: alaurent
"""
import os

import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as ctx

from . import base
from . import colors
from . import config
from ..analysis import constants
from ..analysis import utils
from ..tools.geohelper import MONTREAL_CRS
from ..tools.utils import xform_list_entre_to_dict


def occupancy_map(occ_df, cols, delims, savepath='cache/', basename='', add_cat_prc=False, build_leg=True, anotate=False,
                  rotation=None, fig_buffer=None, compass_rose=False, map_dpi=config.MAP_DPI, leg_dpi=config.LEG_DPI):
    """ Plot all occupancy wanted and save it.

    Parameters
    ----------
    occ_df : geopandas.GeoDataFrame
        The compiled occupancy with geobase double road segment.
    cols : str
        Name of all the columns to use for plotting. Each columns will be a different figure.
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str
        Where to save the images. In total there will be n_cols x n_delims figs.
    """
    occ_df = occ_df.copy()
    rotation = xform_list_entre_to_dict(rotation, list(delims.keys()), default=0, valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, list(delims.keys()), default=100, valueVarName='fig_buffer')

    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        for col in cols:
            path = os.path.join(savepath, f"{basename}taux_occupation_{zone}_colonne_{col}.png")
            # remove no data 
            occ_col = occ_df
            n_cuts, n_colors, base_colors = base._generic_plot_map(
                occ_col,
                col, 
                delim, 
                path,
                numeric_cuts=config.OCC_NUM_CUTS,
                num_colors=config.OCC_COLORS,
                base_cat_colors=config.BASIC_CAT_COLORS,
                basemap=basemap, 
                b_ext=b_ext,
                add_cat_prc=add_cat_prc, 
                build_leg=build_leg,
                anotate=anotate, 
                dpi=map_dpi,
                rotation=rotation[zone],
                fig_buffer=fig_buffer[zone],
                compass_rose=compass_rose
            )
            # legend
            os.makedirs(os.path.join(savepath, 'legends'), exist_ok=True)
            leg_path = os.path.join(os.path.join(savepath, "legends"), f"{basename}taux_occupation_{zone}_colonne_{col}.png")
            base._plot_leg(n_cuts, n_colors, leg_path, base_cat_colors=base_colors, dpi=leg_dpi)


def compared_occupancy_map(occ1, occ2, cols, seg_gis, delims, savepath='cache/', build_leg=True,
                           basename='', desc='', rotation=None, fig_buffer=None,
                           map_dpi=config.MAP_DPI, leg_dpi=config.LEG_DPI, **kwargs):
    """ Plot all occupancy comparison between two occupancy results on columns
    cols. Compared columns need to have the same name on both dataframe.

    Parameters
    ----------
    occ1 : pd.DataFrame
        The first compiled occupancy on cols.
    occ2 : geopandas.GeoDataFrame
        The second compiled occupancy on cols.
    cols : str
        Name of all the columns to use for plotting. Each columns will be a different figure.
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str (Default 'cache/')
        Where to save the images. In total there will be n_cols x n_delims figs.
    """
    occ1 = occ1.copy()
    occ2 = occ2.copy()

    rotation = xform_list_entre_to_dict(rotation, list(delims.keys()), default=0, valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, list(delims.keys()), default=100, valueVarName='fig_buffer')

    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        for col in cols:
            path = os.path.join(savepath, f"{basename}comparaison_taux_occupation_{desc}_zone_{zone}_colonne_{col}.png")
            
            # get compared result for occ1 and occ2
            occ1_, occ2_, compared = utils.compare_two_lapi_results(occ1, occ2, seg_gis, metric_name=col)
            # as value are normalized and pd.cut does not allow negative value, we transform to positiv only values
            occ1_['compared'] = np.clip(compared +1, 0, 2)
            if occ1_.empty:
                continue

            n_cuts, n_colors, base_colors = base._generic_plot_map(
                occ1_, 'compared', delim, path,
                numeric_cuts=config.OCC_RELATIV_CUTS,
                num_colors=config.OCC_RELATIV_COLORS,
                base_cat_colors=config.RELATIV_CAT_COLORS,
                basemap=basemap, b_ext=b_ext,
                add_cat_prc=False, build_leg=build_leg,
                rotation=rotation[zone],
                fig_buffer=fig_buffer[zone],
                dpi=map_dpi, **kwargs
            )
            # legend
            os.makedirs(os.path.join(savepath, 'legends'), exist_ok=True)
            leg_path = os.path.join(savepath, f'legends/{basename}comparaison_taux_occupation_{desc}_zone_{zone}_colonne_{col}.png')
            base._plot_leg(n_cuts, n_colors, leg_path, base_cat_colors=base_colors, dpi=leg_dpi)


def occupancy_relative_map(occ_h, occ_ts, cols, delims, savepath='cache/', basename='', build_leg=True,
                           rotation=None, fig_buffer=None, compass_rose=False, map_dpi=config.MAP_DPI, leg_dpi=config.LEG_DPI, **kwargs):
    """ Plot all relative hour occupancy compared to timeslot occupancy.

    Parameters
    ----------
    occ_h : geopandas.GeoDataFrame
        The compiled occupancy by hour with geobase double road segment.
    occ_ts : geopandas.GeoDataFrame
        The compiled occupancy by timeslot geobase double road segment.
    cols : str
        Name of all the columns to use for plotting. Each columns will be a different figure.
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str
        Where to save the images. In total there will be n_cols x n_delims figs.
    """

    occ_h = occ_h.copy()
    occ_ts = occ_ts.copy()

    rotation = xform_list_entre_to_dict(rotation, list(delims.keys()), default=0, valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, list(delims.keys()), default=100, valueVarName='fig_buffer')

    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        for col in cols:
            path = os.path.join(savepath, f"{basename}taux_occupation_relative_{zone}_colonne_{col}.png")

            def compare_occ(val1, val2):
                if pd.isna(val1) and pd.isna(val2):
                    return np.nan
                if not pd.api.types.is_number(val1) and val1 == val2:
                    return val1
                if not pd.api.types.is_number(val1) or pd.isna(val1):
                    val1 = 0
                if not pd.api.types.is_number(val2) or pd.isna(val2):
                    val2 = 0
                return np.clip((val1 - val2) +1, 0, 2)

            occ_mean = occ_ts.merge(occ_h, on=['segment', 'side_of_street'], how='right').mean_occ.copy()
            # occ_h[col] = np.vectorize(compare_occ)(occ_h[col].values, occ_mean.values)
            occ_h[col] = list(map(compare_occ, occ_h[col].values, occ_mean.values))

            n_cuts, n_colors, base_colors = base._generic_plot_map(
                occ_h, col, delim, path,
                numeric_cuts=config.OCC_RELATIV_CUTS,
                num_colors=config.OCC_RELATIV_COLORS,
                base_cat_colors=config.RELATIV_CAT_COLORS,
                basemap=basemap, b_ext=b_ext,
                add_cat_prc=False, build_leg=build_leg,
                rotation=rotation[zone],
                fig_buffer=fig_buffer[zone],
                compass_rose=compass_rose,
                dpi=map_dpi, **kwargs
            )
            # legend
            os.makedirs(os.path.join(savepath, 'legends'), exist_ok=True)
            leg_path = os.path.join(savepath, f'legends/{basename}taux_occupation_relative_{zone}_colonne_{col}.png')
            base._plot_leg(n_cuts, n_colors, leg_path, base_cat_colors=base_colors, dpi=leg_dpi)

def segment_capacity_map(seg_info, seg_gis, delims,
                         save_path, basename='', restrictions=False,
                         build_leg=True, normalized=False,
                         rotation=None, fig_buffer=None,
                         map_dpi=config.MAP_DPI, leg_dpi=config.LEG_DPI,
                         anotate=False, save_geojson=False,
                         **kwargs):
    """ Plot parking capacity of segment and save it.

    Parameters
    ----------
    seg_info : pandas.DataFrame
        The information capacity about segements.
    seg_gis : geopandas.GeoDataFrame
        The geographic information about segments.
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str
        Where to save the images. In total there will be n_cols x n_delims figs.
    """
    seg_info = seg_info.copy()
    seg_gis = seg_gis.copy()

    # 1 - get parameters for map
    rotation = xform_list_entre_to_dict(rotation,
                                        list(delims.keys()), 
                                        default=0, 
                                        valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, 
                                          list(delims.keys()), 
                                          default=100, 
                                          valueVarName='fig_buffer')
    # 2 - construct GeoDataFrame
    seg_info['COTE'] = seg_info.side_of_street.map({-1:'Gauche', 1:"Droite"})
    seg_info = seg_info.merge(seg_gis[['ID_TRC', 'COTE', 'geometry']],
                              right_on=['ID_TRC', 'COTE'],
                              left_on=['segment', 'COTE'],
                              how='right')\
                       .drop(columns=['ID_TRC'])
    seg_info = gpd.GeoDataFrame(seg_info, geometry='geometry')

    # 3 - retrieve number of parking spot on each segment
    long_troncon = seg_info.to_crs(MONTREAL_CRS).geometry.length.values
    seg_info.loc[~seg_info[constants.CAP_N_VEH].isna(), 'places'] = (
        (seg_info[constants.CAP_DELIM_SPACE] + seg_info[constants.CAP_SPACE]) / long_troncon 
        if normalized else seg_info[constants.CAP_N_VEH]
    )
    seg_info.loc[seg_info[constants.CAP_N_VEH].isna(), 'places'] = np.nan

    # 4 - construct restrictions on segments where there always a restriction
    mask_restric = (~seg_info['restrictions'].isna() &
                    seg_info.res_days.isna() & 
                    seg_info.res_hour_from.isna())
    if restrictions:
        seg_info.loc[mask_restric, 'places'] = seg_info.loc[mask_restric, 'restrictions']

    # 5 - Plot
    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        path = os.path.join(save_path, f"{basename}segments_capacity_secteur_{zone}.png")
        if normalized:
            path = os.path.join(save_path, 
                                f"{basename}segments_capacity_secteur_{zone}_normalized.png")

        n_cuts, n_colors, base_colors = base._generic_plot_map(
            seg_info, 
            'places', 
            delim, 
            path,
            numeric_cuts=config.CAPA_NORM_NUM_CUTS if normalized else config.CAPA_NUM_CUTS, #None,
            num_colors=config.CAPA_NORM_COLORS if normalized else None,#config.CAPA_COLORS,#None,
            num_cmap=colors.LAPIN_PALETTES['CAPA'](as_cmap=True),
            mc_k=4, # TODO shoot in config
            base_cat_colors=config.BASIC_CAT_COLORS,
            basemap=basemap, 
            b_ext=b_ext,
            add_cat_prc=False, 
            build_leg=build_leg,
            anotate=anotate,
            rotation=rotation[zone],
            fig_buffer=fig_buffer[zone],
            dpi=map_dpi,
            normalized_val=normalized,
            **kwargs
        )

        # legend
        os.makedirs(os.path.join(save_path, 'legends'), exist_ok=True)
        leg_path = os.path.join(
            save_path, 
            f'legends/{basename}segments_capacity_secteur_{zone}.png'
        )
        if normalized:
            leg_path = os.path.join(
                save_path, 
                f'legends/{basename}segments_capacity_secteur_{zone}_normalized.png'
            )
        base._plot_leg(
            n_cuts,
            n_colors, 
            leg_path, 
            base_cat_colors=base_colors, 
            dpi=leg_dpi
        )
    
    if save_geojson:
        os.makedirs(os.path.join(save_path, 'data'), exist_ok=True)
        print(os.path.join(save_path, f'data/{basename}segments_capacity.geojson'))
        print(seg_info.shape[0])
        seg_info.to_file(
            os.path.join(save_path, f'data/{basename}segments_capacity.geojson'.replace(':', '-')),
            index=False, 
            driver='GeoJSON'
        )

def plot_capacity_leg(save_path, leg_dpi=config.LEG_DPI):
    base._plot_leg(config.CAPA_NUM_CUTS, config.CAPA_COLORS, save_path,
                   base_cat_colors=config.BASIC_CAT_COLORS, dpi=leg_dpi)

def plot_occ_leg(save_path, leg_dpi=config.LEG_DPI):
    base._plot_leg(config.OCC_NUM_CUTS, config.OCC_COLORS, save_path,
                   base_cat_colors=config.BASIC_CAT_COLORS, dpi=leg_dpi)

def plot_occ_relativ_leg(save_path, leg_dpi=config.LEG_DPI):
    base._plot_leg(config.OCC_RELATIV_CUTS, config.OCC_RELATIV_COLORS, save_path,
                   base_cat_colors=config.RELATIV_CAT_COLORS, dpi=leg_dpi)