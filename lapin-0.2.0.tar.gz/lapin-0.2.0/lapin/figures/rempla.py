# -*- coding: utf-8 -*-
"""
Created on Wed Jun  9 10:12:27 2021

@author: lgauthier
"""
import os

import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as ctx
import seaborn as sns
import scipy
from statsmodels.stats.weightstats import DescrStatsW


from . import base
from . import colors
from . import config
from ..tools.utils import xform_list_entre_to_dict

def remplacement_map(park_time_street, cols, delims, savepath='cache/',
                     fig_name_base='', add_cat_prc=False, build_leg=True,
                     rotation=None, fig_buffer=None,
                     map_dpi=config.MAP_DPI, leg_dpi=config.LEG_DPI):
    """ Plot all park_timeupancy wanted and save it.

    Parameters
    ----------
    park_time : geopandas.GeoDataFrame
        The compiled park_timeupancy with geobase double road segment.
    cols : str
        Name of all the columns to use for plotting. Each columns will be a different figure.
    delim : dict
        Of the form {name:geometry} with geometry a shapely.geometry.Multipolygon
        or shapely.geometry.Polygon. These geometry are delimitations of the
        different plots to be produced, each delim will generate a figure name
        using the key's value.
    savepath : str
        Where to save the images. In total there will be n_cols x n_delims figs.
    """

    park_time_street = park_time_street.copy()
    rotation = xform_list_entre_to_dict(rotation, list(delims.keys()), default=0, valueVarName='rotation')
    fig_buffer = xform_list_entre_to_dict(fig_buffer, list(delims.keys()), default=100, valueVarName='fig_buffer')

    for zone, delim in delims.items():
        basemap, b_ext = base.get_tile(config.CURRENT_TILE, *delim.bounds)
        for col in cols:
            path = os.path.join(savepath, f"{fig_name_base}_taux_park_time_{zone}_colonne_{col}.png")
            park_time_street[col] = park_time_street[col].apply(lambda x:  x/3600 if pd.api.types.is_number(x) else x)
            n_cuts, n_colors, base_colors = base._generic_plot_map(park_time_street, col, delim, path,
                                                                   numeric_cuts=config.REMPLA_NUM_CUTS,
                                                                   num_colors=config.REMPLA_COLORS,
                                                                   base_cat_colors=config.RELATIV_CAT_COLORS,
                                                                   basemap=basemap, b_ext=b_ext,
                                                                   add_cat_prc=add_cat_prc, build_leg=build_leg,
                                                                   rotation=rotation[zone],
                                                                   fig_buffer=fig_buffer[zone],
                                                                   dpi=map_dpi)
            # legend
            os.makedirs(os.path.join(savepath, 'legends'), exist_ok=True)
            leg_path = os.path.join(savepath, f'legends/{fig_name_base}_taux_park_time_{zone}_colonne_{col}.png')
            base._plot_leg(n_cuts, n_colors, leg_path, base_cat_colors=base_colors, dpi=leg_dpi)

def plot_rempl_leg(save_path, leg_dpi=config.LEG_DPI):
    """
    Plot the legend of the _plot_remplacement_map func.

    Arguments
    ---------
    save_path : string
        Where to save the figure.
    """
    base._plot_leg(config.REMPLA_NUM_CUTS, config.REMPLA_COLORS, save_path,
                   base_cat_colors=config.BASIC_CAT_COLORS, dpi=leg_dpi)

def plot_cat_park_distrib(park_time, savepath, fig_base_name='', fig_dpi=config.FIG_DPI):
    """
    Plot the distribution of the parking time as an horizontal histogram.

    Arguments
    ---------
    park_time : pandas.DataFrame
        Output of analyse.rempla._park_time_distribution
    save_path : string
        Where to save the figure
    fig_base_name : string. Default is ''.
        String to further describe the picture in the savename.

    TODO :
    1. Make more generic ? Or melt analyse.rempla.park_time_distribution
    with this func ?
    """
    park_time = park_time.copy()
    park_time.rename(columns={'nb_lap': 'Pourcentage', 'category':"Type d'utilisation"}, inplace=True)

    # make figure
    f, ax = plt.subplots(figsize=(10, 10))
    g = sns.barplot(data=park_time,
               x='Pourcentage',
               y='Type d\'utilisation',
               orientation='horizontal',
               order=['Très court', 'Court', 'Moyen', 'Long'],
               palette=colors.LAPIN_PALETTES['OCC_BLUES'](),
               ax=ax)

    # Annotate
    for p in ax.patches:
        ax.annotate(format(p.get_width(), '.0f'), (p.get_width(), p.get_y() + p.get_height() / 2.), ha = 'center', va = 'center', xytext = (10, 12), textcoords = 'offset points')

    f.savefig(os.path.join(savepath, f'{fig_base_name}_distribution_parking_time.png'), bbox_inches='tight', dpi=fig_dpi)
    plt.close()


def plot_cat_park_time(cat_park_time, savepath, fig_base_name='', fig_dpi=config.FIG_DPI):
    """
    Plot the type usage of parking slot as an horizontal histogram. Display
    innoccupied slot percentage too.

    Arguments
    ---------
    cat_park_time : pandas.DataFrame
        Output of analyse.rempla.categorize_parking_usage
    save_path : string
        Where to save the figure
    fig_base_name : string. Default is ''.
        String to further describe the picture in the savename.

    TODO :
    1. Make more generic ? Or melt analyse.rempla.park_time_distribution
    with this func ?
    """

    cat_park_time = cat_park_time.copy()

    cat_cols = [col for col in cat_park_time.columns if col not in ['segment', 'side_of_street', 'weight']]

    # transform data to fit usage
    park_time_dist = cat_park_time.melt(
        ['segment', 'side_of_street', 'weight'],
        value_vars=cat_cols,
        var_name='Type d\'occupation',
        value_name='Pourcentage'
    )
    park_time_dist['Pourcentage'] *= 100

    def weighted_average(df, data_col, weight_col, by_col, res_col='mean', confidence=0.95):
        df['_data_times_weight'] = df[data_col]*df[weight_col]
        df['_weight_where_notnull'] = df[weight_col]*pd.notnull(df[data_col])
        g = df.groupby(by_col)
        result = pd.DataFrame(index=df[by_col].unique())
        result.index.names = [by_col]
        for idx, data in g:
            weighted_stats = DescrStatsW(data[data_col], weights=data[weight_col], ddof=0)
            result.loc[idx, res_col] = weighted_stats.mean
            result.loc[idx, 'ci'] =  weighted_stats.std_mean * scipy.stats.t.ppf((1 + confidence) / 2., data.shape[0]-1)
            result.loc[idx, 'std'] = weighted_stats.std
        del df['_data_times_weight'], df['_weight_where_notnull']
        return result

    park_time_dist = weighted_average(park_time_dist, 'Pourcentage', 'weight', 'Type d\'occupation', 'Pourcentage')
    park_time_dist = park_time_dist.reset_index()

    # error
    yerr = [-park_time_dist['ci'], park_time_dist['ci']]

    # create figure
    f, ax = plt.subplots(figsize=(10, 10))

    g = sns.barplot(
        data=park_time_dist,
        x="Pourcentage",
        y="Type d'occupation",
        #hue="Type d'occupation",
        order=cat_cols,#['Places inocupées','Places très courte durée',
              # 'Places courte durée', 'Places moyenne durée',
              #'Places longue durée'],
        orient='h',
        palette='Blues',
        dodge=False,
        xerr=park_time_dist['ci'],
        ax=ax
    )
    if g.legend_:
        g.legend.remove()
    # Annotate
    for p in ax.patches:
        ax.annotate(format(p.get_width(), '.0f'), (p.get_width(), p.get_y() + p.get_height() / 2.), ha = 'center', va = 'center', xytext = (10, 12), textcoords = 'offset points')


    f.savefig(os.path.join(savepath, f'{fig_base_name}categorisation_parking_time.png'), bbox_inches='tight', dpi=fig_dpi)
    plt.close()

def park_time_provenance(park_time_dist, savepath, fig_base_name, fig_dpi=config.FIG_DPI):
    """
    Plot the parking time by provenance as an horizontal histogram. Display
    innoccupied slot percentage too.

    Arguments
    ---------
    cat_park_time : pandas.DataFrame
        Output of analyse.rempla.parking_time_by_provenance
    save_path : string
        Where to save the figure
    fig_base_name : string. Default is ''.
        String to further describe the picture in the savename.

    TODO :
    1. Make more generic ? Or melt analyse.rempla.park_time_distribution
    with this func ?
    """
    park_time_dist = park_time_dist.copy()
    park_time_dist.rename(columns={'dist_class': 'Distance', 'category':'Type de stationnement'}, inplace=True)

    # Figures
    pal = sns.cubehelix_palette(10, rot=-.25, light=0.4)
    g = sns.FacetGrid(park_time_dist, col="Distance", hue="Type de stationnement", aspect=1,
                      height=3, palette=colors.LAPIN_PALETTES['OCC_BLUES'](),
                      col_wrap=3, legend_out=True)

    g.map(sns.barplot,
        "Pourcentage d'immobilisation totale",
        "Type de stationnement",
        alpha=1,
        ci=95,
        capsize=0.2,
        order=['Très court', 'Court', 'Moyen', 'Long'],
        orient='h',
    )
    # Annotate
    for ax in g.axes.ravel():
        ax.set_xlabel("")
        ax.set_ylabel("")
        for p in ax.patches:
            ax.annotate(format(p.get_width(), '.0f'), (p.get_width(), p.get_y() + p.get_height() / 2.), ha = 'center', va = 'center', xytext = (10, 12), textcoords = 'offset points')

    #plt.xlabel("Pourcentage d'immobilisation totale")
    #plt.ylabel("Type de stationnement")

    g.savefig(os.path.join(savepath, f'{fig_base_name}distance_parking_time.png'), dpi=fig_dpi)
    plt.close()