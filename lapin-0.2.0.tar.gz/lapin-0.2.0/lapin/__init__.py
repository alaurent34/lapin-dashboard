import os
os.environ['USE_PYGEOS'] = '1'
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import geopandas

from lapin import (
    analysis,
    enhancement,
    figures,
    tools,
    transactions)