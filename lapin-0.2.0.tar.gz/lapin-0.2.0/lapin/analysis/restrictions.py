"""
Engine for restrictions

@author: alaurent
@author: lgauthier
"""
import os
import datetime
import pandas as pd
import numpy as np

from . import constants
from .utils import parse_days
from ..tools.ctime import Ctime

def _is_on_segment(seg_beg, seg_end, position):
    """ Check if position on segment.

    Parameters
    ----------
    seg_beg : float
        Start position of the segment regulation on the road.
    seg_end : float
        End position of the segment regulation on the road.
    position : float
        Position we want to check.

    Returns
    -------
    b : boolean 
        True if position on segment, False otherwise

    Example
    -------

     beg   pos   end
    --|-----@-----|-----   -> Return True 

     beg         end pos
    --|-----------|---@-   -> Return False
    
    """
    return seg_beg <= position <= seg_end

def _is_on_hour_interval(hour_from, hour_to, datetime):
    """ Check if datetime of the collected point is on the interval of
    the regulation.

    Parameters
    ----------
    hour_from : string
        Starting hour interval in string format e.g.: "00:00"
    hour_to : string
        Ending hour interval in string format e.g.: "15:00"
    datetime : datetime.datetime
        Time to check. 

    Returns
    -------
    b : boolean
        True if datime between interval, False otherwise.
    """
    if pd.isna(hour_from) and pd.isna(hour_to):
        return True
    else:
        hour_from = Ctime.from_string(hour_from)
        hour_to = Ctime.from_string(hour_to)
        time = Ctime.from_declared_times(hours=datetime.hour, minutes=datetime.minute, seconds=datetime.second)

        return hour_from <= time <= hour_to

def _is_on_day_interval(days, datetime):
    """ Check if datetime of the collected point is on the day 
    interval.

    Parameters
    ----------
    days : string
        Day of regulation, it's exprimed as the first three letter 
        of french days and "+" and "-" operator. 

        Example : "lun-jeu" means from monday (lundi) to thursday (jeudi).
                  "lun+jeu" means monday (lundi) and thursday (jeudi).
    datetime : datetime.datetime
       Date to check 

    Returns
    -------
    b : boolean
        True if datetime in days, False otherwise.
    """
    if pd.isna(days):
        return True
    else:
        return datetime.dayofweek in parse_days(days)

def _is_restriction(row, ignore_hours=False, ignore_days=False, ignore_pos=True,
                    all_road=False, time_col='datetime'):
    ''' Check if point captured hit a regulation present on the segment. At this level,
    only one regulation is tested on the point, as this function is part of a loop. 
    Information is provided in form of a DataFrame row.
    
    TODO: Implement an objet called restriction to force the restriction format.
    Do not pass the row as a dataframe, instead pass the row of the collected 
    point along with the restriction object.

    Parameters
    ----------
    row : pandas.Serie
        Row containing point with datetime and linear referencing along with regulation
        information.
    ignore_hours : boolean (Default: False)
        True to bypass hour restricition on the regulation, False otherwise.
    ignore_days : boolean (Default: False)
        True to bypass days restriction on the regulation, False otherwise.
    ignore_pos : boolean (Default: False)
        True to bypass position regulation on the segment, False otherwise.
    all_road : boolean (Default: False)
        True to ignore all regulation whose length are inferiour to the street segment
        length.
    time_col : string (Default: 'datetime')
       Column name of the timestemp corresponding to the moment where the data
       was recolted.

    Returns
    -------
    b : boolean
        True if point hit the regulation, False otherwise.

    Example
    -------
    1. Row without regulation
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | occ   |
            ...|:---------------|----------------:|--------------:|:------|
            ...| NaN            | NaN             | NaN           | 0.43  |
        >>> parse_restriction(row) ---> return 0.43
    2. Row with regulation not in vigor
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | res_days   | occ   |
            ...|:---------------|----------------:|--------------:|:-----------|:------|
            ...| travaux        | NaN             | NaN           | lun-mar    | 0.43  |
        >>> parse_restriction(row) ---> return 0.43
    3. Row with regulation in vigor
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | res_days   | occ   |
            ...|:---------------|----------------:|--------------:|:-----------|:------|
            ...| travaux        | NaN             | NaN           | NaN        | 0.43  |
        >>> parse_restriction(row) ---> return 'travaux'
    '''

    # Usefull var
    row = row.copy()
    days = row[constants.CAP_RES_DAYS]
    hour_from = row[constants.CAP_RES_HOUR_FROM]
    hour_to = row[constants.CAP_RES_HOUR_TO]
    beg = row[constants.CAP_START_RES]
    end = row[constants.CAP_END_RES]

    # No restriction for this segment
    if pd.isna(row[constants.CAP_RESTRICTIONS]):
        return False
    
    restrict = True

    # Check if there is a restriction based on days or hours
    if not ignore_days or not ignore_hours:
        date = row[time_col]
        restrict = _is_on_day_interval(days, date) and _is_on_hour_interval(hour_from, hour_to, date)

    # Take care of the position case
    if not ignore_pos and not all_road:
        pos = row[constants.POINT_ON_STREET]
        restrict = restrict and _is_on_segment(beg, end, pos)

    # Take care of ignore_days and ingore hours
    if ignore_days:
        restrict = restrict and pd.isna(days)
    if ignore_hours:
        restrict = restrict and pd.isna(hour_from) and pd.isna(hour_to)

    # Entretien are only valid during the summer period
    #if row[constants.CAP_RES_TYPE] in (['Entretien', 'Entretien ']):
    #    restrict = restrict and (4 <= row[constants.DATETIME].month < 12) 

    return restrict

class RestrictionHandler(object):
    """RestrictionHanfler is a class used to preprocess and store parking
    restriction dataset. It enable the computation of capacity and restriction 
    checking over LAPI data.

    Parameters
    ----------
    seg_info : pandas.DataFrame
        DataFrame of all parking regulations. Must follow a specific model. See example 
        of regulation file in 'data/example/stationnement_par_segment.xlsx'
    priority : list (Default: ['Travaux', 'Non arrets', 'Arret de bus', 'Saillie',
                               'Non parcourue', 'Piétonnisation', 'Terre-plein intérieur',
                               'Centre intersection', 'Interdiction', 'Livraison', 'Taxi',
                               'Urgence','STM', 'Parking Parallele', 'Entretien', 'Entretien '])
        Priority list of restriction.
    segment : string (Default: 'segment')
        Column name of road segment information.
    side_of_street : string (Default: 'side_of_street')
        Column name of road segment side of street information.
    start_res : string (Default: 'deb')
        Column name of the starting point of a regulation information.
    end_res : string (Default: 'fin')
        Column name of the ending point of a regulation information.
    res : string (Default: 'restrictions')
        Column name of restriction information.
    res_hour_from : string (Default: 'res_hour_from')
        Column name of the start of the time interval for a regulation.
    res_hour_to : string (Default: 'res_hour_to')
        Column name of the end of the time interval for a regulation.
    res_days : string (Default: 'res_days')
        Column name of the days for which a regulation is active.
    capacity_space : string (Default: 'longueur_non_marquée')
        Column name of the capacity covered by a regulation (in meter).
    capacity_n_veh : string (Default: 'nb_places_total')
        Column name of the capacity covered by a regulation (in vehicule).

    Returns
    -------
    RetrictionHandler : RestrictionHandler
        The restriction handler of the zone studied.
    """
    def __init__(self, seg_info, priority=constants.CAP_PRIORITY, 
                 segment=constants.SEGMENT,
                 side_of_street=constants.SIDE_OF_STREET,
                 start_res=constants.CAP_START_RES,
                 end_res=constants.CAP_END_RES,
                 res=constants.CAP_RESTRICTIONS,
                 res_hour_from=constants.CAP_RES_HOUR_FROM,
                 res_hour_to=constants.CAP_RES_HOUR_TO,
                 res_days=constants.CAP_RES_DAYS,
                 capacity_space=constants.CAP_SPACE,
                 capacity_n_veh=constants.CAP_N_VEH,
                 cache_path=constants.CAP_CACHE_PATH):

        self.seg_info = seg_info[~seg_info[constants.CAP_RES_TYPE].isin(['Base', 'base'])].copy()
        self.seg_base = seg_info[seg_info[constants.CAP_RES_TYPE].isin(['Base', 'base'])].copy()

        # Create an index
        # make sur to have a sequential index
        if 'restrict_id' not in self.seg_info:
            self.seg_info = self.seg_info.reset_index().drop(columns='index')
            self.seg_info.reset_index(inplace=True)
            self.seg_info.rename(columns={'index':'restrict_id'}, inplace=True)
        if 'restrict_id' in self.seg_base:
            self.seg_base.drop(columns='retrict_id', inplace=True)

        dict_priority = {}
        for i, item in enumerate(priority):
            dict_priority[item] = i
        self._priority = dict_priority

        # Rename columns
        self.seg_info.rename(columns={
            segment:constants.SEGMENT,
            side_of_street:constants.SIDE_OF_STREET,
            start_res:constants.CAP_START_RES,
            end_res:constants.CAP_END_RES,
            res:constants.CAP_RESTRICTIONS,
            res_hour_from:constants.CAP_RES_HOUR_FROM,
            res_hour_to:constants.CAP_RES_HOUR_TO,
            res_days:constants.CAP_RES_DAYS,
            capacity_space:constants.CAP_SPACE,
            capacity_n_veh:constants.CAP_N_VEH,
        }, inplace=True)

        # Set priority
        self.seg_info['priority'] = self.seg_info[constants.CAP_RES_TYPE].map(self._priority)
        self.cache_path = cache_path
        os.makedirs(cache_path, exist_ok=True)

        #Smooth inconsistancy
        self._clean()

    def _entretien_handle(self):
        """ Remove street cleaning regulation if we're in winter.

        """
        today = datetime.datetime.today().month

        active_entretien = 4 < today < 12

        if not active_entretien:
            self.seg_info = self.seg_info[self.seg_info[constants.CAP_RES_TYPE] != 'Entretien']

    def _clean(self):
        """ Check for inconsistancy in regulation data and correct it on the fly.
        """

        seg_info = self.seg_info.copy()

        # remove white space
        seg_info[constants.CAP_RESTRICTIONS] = seg_info[constants.CAP_RESTRICTIONS].replace(r'^\s*$', np.nan, regex=True)
        self.seg_base[constants.CAP_RESTRICTIONS] = self.seg_base[constants.CAP_RESTRICTIONS].replace(r'^\s*$', np.nan, regex=True)

        # change lun-dim/dim-sam representation to nan
        seg_info.loc[
            (seg_info[constants.CAP_RES_DAYS] == 'lun-dim') |\
                (seg_info[constants.CAP_RES_DAYS] == 'dim-sam'),
            constants.CAP_RES_DAYS
        ] = np.nan

        # harmonize hours
        max_hour = Ctime.from_string('23:59:00')
        min_hour = Ctime.from_string('00:00:00')
        for idx, row in seg_info.iterrows():
            if isinstance(row[constants.CAP_RES_HOUR_FROM], datetime.time):
                hour_from = Ctime.from_datetime(row[constants.CAP_RES_HOUR_FROM]) if str(row[constants.CAP_RES_HOUR_FROM]) != 'nan' else min_hour
                hour_to = Ctime.from_datetime(row[constants.CAP_RES_HOUR_TO]) if str(row[constants.CAP_RES_HOUR_TO]) != 'nan' else max_hour
            else:
                hour_from = Ctime.from_string(row[constants.CAP_RES_HOUR_FROM]) if str(row[constants.CAP_RES_HOUR_FROM]) != 'nan' else min_hour
                hour_to = Ctime.from_string(row[constants.CAP_RES_HOUR_TO]) if str(row[constants.CAP_RES_HOUR_TO]) != 'nan' else max_hour
            
            seg_info.loc[idx, constants.CAP_RES_HOUR_FROM] = hour_from.__str__()
            seg_info.loc[idx, constants.CAP_RES_HOUR_TO] = hour_to.__str__()

            if hour_from <= min_hour and hour_to >= max_hour:
                seg_info.loc[idx, constants.CAP_RES_HOUR_FROM] = np.nan
                seg_info.loc[idx, constants.CAP_RES_HOUR_TO] = np.nan


        self.seg_info = seg_info

    def _is_max_len(self, reg_id):
        """ Check if regulation pointed by reg_id cover the total lengh of the
        road segment.

        Parameters
        ----------
        reg_id : int
            Identifier of the regulation to check.

        Returns
        -------
        b : boolean
            True if regulation cover the whole segment, else False.
        """

        # get info on restriction
        segment = self.seg_info.loc[reg_id, constants.SEGMENT]
        side_of_street = self.seg_info.loc[reg_id, constants.SIDE_OF_STREET]
        mask = (self.seg_base[constants.SEGMENT] == segment) & (self.seg_base[constants.SIDE_OF_STREET] == side_of_street)

        # compute length of restriction
        len_reg = self.seg_info.loc[reg_id, constants.CAP_END_RES] - \
                  self.seg_info.loc[reg_id, constants.CAP_START_RES]
        len_seg = self.seg_base.loc[mask, constants.CAP_END_RES].values[0] - \
                  self.seg_base.loc[mask, constants.CAP_START_RES].values[0]

        return len_reg == len_seg

    def _priority_reg(self, reg_ids):
        """ Sort the list of regulations by priority.

        Parameters
        ----------
        reg_ids : list of int
            List of regulations ids to sort by priority.

        Returns
        -------
        sorted_reg_ids : list of int
            Sorted regulation ids.
        """
        type_reg = self.seg_info[self.seg_info['restrict_id'].isin(reg_ids)][['restrict_id', 'res_type']].set_index('res_type').to_dict()['restrict_id']
        type_reg_sort = sorted(type_reg, key=lambda x: self._priority[x] if x in self._priority.keys() else np.inf)

        return type_reg[type_reg_sort[0]]

    def apply_restriction(self, data, index=['segment', 'side_of_street'], ignore_hours=False,
                         ignore_days=False, time_col='time'):
        """ Apply restrictions on all point collected on the curbside. Compute the
        capacity of the segment at the same time.

        Paramaters
        ----------
        data : pandas.DataFrame
            Data for collected points on the curbside.
        index : list of string (Default: ['segment', 'side_of_street'])
            Index of curbside of the data.
        ignore_hours : boolean (Default: False)
            True to bypass hour restricition on the regulation, False otherwise.
        ignore_days : boolean (Default: False)
            True to bypass days restriction on the regulation, False otherwise.
        time_col : string (Default: 'time')
           Column name of the timestemp corresponding to the moment where the data
           was recolted.

        Returns
        -------
        data_restrict : pandas.DataFrame
            Data of point with restriction associated when collected. 
        """
        
        data = data.copy()

        # Check is we take into account the position of the vehicule
        handle_pos = False
        if constants.POINT_ON_STREET in data.columns:
            handle_pos = True

        # Merge data with segment restriction
        data = data.merge(self.seg_info.copy(), on=[constants.SEGMENT, constants.SIDE_OF_STREET], how='left') 

        # iterate over each item to know it's regulation
        grouped = data.groupby(index)
        segments_reg = []
        for _, seg_reg in grouped:
            regs = []
            # for all restrictions
            for _, row in seg_reg.iterrows():
                if pd.isna(row['restrict_id']):
                    continue
                # if there is a restriction on this segments, save it
                all_road = self._is_max_len(row['restrict_id'])
                if _is_restriction(row, ignore_hours, ignore_days, ignore_pos=not handle_pos, time_col=time_col, all_road=all_road):
                    regs.append(row['restrict_id'])

            # Get restriction in action
            ## if we dont handle position we filter non lenghtwise regulation
            
            if not handle_pos: 
                regs = [reg_id for reg_id in regs if self._is_max_len(reg_id)]

            # get default regulation on segment
            base = self.seg_base.loc[
                self.seg_base[constants.SEGMENT].isin(seg_reg[constants.SEGMENT]) &
                self.seg_base[constants.SIDE_OF_STREET].isin(seg_reg[constants.SIDE_OF_STREET])
            ]
            if base.empty:
                #print(f'INFO - Segment <{seg_reg[constants.SEGMENT].iloc[0]}, {seg_reg[constants.SIDE_OF_STREET].iloc[0]}> not in segment Base regulations.')
                continue

            restriction = self.seg_info.loc[self._priority_reg(regs), constants.CAP_RESTRICTIONS] if regs else base[constants.CAP_RESTRICTIONS].iloc[0]
            res_type = self.seg_info.loc[self._priority_reg(regs), constants.CAP_RES_TYPE] if regs else np.nan
            restrict_id = regs[0] if regs else np.nan

            # capacity of the segment at this time
            cap_row = self.get_segment_capacity(
                row[constants.SEGMENT],
                row[constants.SIDE_OF_STREET],
                row[time_col],
                ignore_hours=ignore_hours,
                ignore_days=ignore_days) 

            # Update restriction info
            new_row = row.copy()
            cols_delete = self.seg_info.columns.to_list()
            cols_delete = [col for col in cols_delete if col not in [constants.SEGMENT,
                                                                     constants.SIDE_OF_STREET,
                                                                     constants.CAP_RES_HOUR_FROM,
                                                                     constants.CAP_RES_HOUR_TO,
                                                                     constants.CAP_RES_DAYS,
                                                                     'restrict_id']]
            new_row.drop(index=cols_delete, inplace=True)
            new_row['restrict_id'] = restrict_id
            new_row[constants.CAP_IS_RESTRICT] = str(restriction) != 'nan'
            new_row[[constants.CAP_RES_HOUR_FROM, constants.CAP_RES_HOUR_TO, constants.CAP_RES_DAYS]] = np.nan
            new_row[constants.CAP_RESTRICTIONS] = restriction
            new_row[constants.CAP_RES_TYPE] = res_type
            new_row['seg_restrict'] = cap_row[constants.CAP_RESTRICTIONS]
            new_row[constants.CAP_SPACE] = cap_row[constants.CAP_SPACE]
            new_row[constants.CAP_N_VEH] = cap_row[constants.CAP_N_VEH]
            new_row[constants.CAP_N_DELIM_S] = cap_row[constants.CAP_N_DELIM_S]
            new_row[constants.CAP_N_UNDELIM_S] = cap_row[constants.CAP_N_UNDELIM_S]

            segments_reg.append(new_row)

        return pd.DataFrame(segments_reg)

    def get_segment_capacity(self, seg_id, side_of_street, date, ignore_days=False, ignore_hours=False):
        """ Get the capacity of curb segment when all active restrictions are handled. 

        Paramaters
        ----------
        seg_id: int
            The identifier of the curb segment in the database.
        side_of_street: enum -1 or 1.
            The side of the curb we want to compute capacity.
        date: datetime
            The temporal instant when to querry the capacity.
        ignore_days: boolean (Default: False)
            Ignore day-based regulations ? 
        ignore_hours: boolean (Default: False)
            Ignore hour-based regulations ? 

        Returns
        -------
        row_updated: pandas.Serie
            A pandas Serie for the segment seg_id with relative capacity fields updated.
        """
        
        ### 0 - Retrieve information of segments
        mask = (self.seg_info[constants.SEGMENT] == seg_id) & \
            (self.seg_info[constants.SIDE_OF_STREET] == side_of_street)
        mask_base = (self.seg_base[constants.SEGMENT] == seg_id) & \
            (self.seg_base[constants.SIDE_OF_STREET] == side_of_street)

        seg_info = self.seg_info.loc[mask].copy()
        seg_info['datetime'] = date

        base = self.seg_base.loc[mask_base]

        ### 1 - Filter regulations by time and days
        times_and_days_filtered_regs = []
        for _, row in seg_info.iterrows():
            # if there is a restriction on this segments, save it
            if _is_restriction(row, ignore_hours=ignore_hours, ignore_days=ignore_days, ignore_pos=True, time_col='datetime'):
                times_and_days_filtered_regs.append(row['restrict_id'])

        if seg_info.empty:
            row = base.iloc[0]

        regs_total = [reg_id for reg_id in times_and_days_filtered_regs if self._is_max_len(reg_id)]
        regs_partial = [reg_id for reg_id in times_and_days_filtered_regs if not self._is_max_len(reg_id)] 

        ### 2 - Filter by priority and positions
        cap_veh_delim = base[constants.CAP_N_DELIM_S].values[0]
        cap_veh = base[constants.CAP_N_VEH].values[0]
        cap_len = base[constants.CAP_SPACE].values[0]
        seg_info = self.seg_info.loc[
            mask &
            self.seg_info['restrict_id'].isin(regs_partial+regs_total)
        ].copy()

        # Sort regulation priority
        seg_info = seg_info.sort_values('priority')

        # Substract capacity of active regulations from the base.
        filtered_seg_info = []
        cap_veh_delim_to_substract = []
        cap_veh_to_substract = []
        cap_len_to_substract = []
        for _, row in seg_info.iterrows():
            start = row[constants.CAP_START_RES]
            end = row[constants.CAP_END_RES]

            cap_delim_veh_removed = row[constants.CAP_N_DELIM_S]
            cap_not_delim_veh_removed = row[constants.CAP_N_UNDELIM_S]
            cap_tot_veh_removed = row[constants.CAP_N_VEH]
            cap_len_removed = row[constants.CAP_SPACE]
            for filtered_row in filtered_seg_info:
                # Current regulation does not overlap already applied reg.
                if end <= filtered_row[constants.CAP_START_RES] or \
                    start >= filtered_row[constants.CAP_END_RES]:
                    continue
                # Current regulation entirly contains another reg with higher priority.
                elif start < filtered_row[constants.CAP_START_RES] and \
                    end > filtered_row[constants.CAP_END_RES]:
                    cap_delim_veh_removed -= filtered_row[constants.CAP_N_DELIM_S]
                    cap_not_delim_veh_removed -= filtered_row[constants.CAP_N_UNDELIM_S]
                    cap_tot_veh_removed = cap_delim_veh_removed + cap_not_delim_veh_removed
                    cap_len_removed -= filtered_row[constants.CAP_SPACE]
                # Current regulation overlap the start of another reg with higher priority.
                elif start < filtered_row[constants.CAP_START_RES]:
                    percentage_rm = (end - filtered_row[constants.CAP_START_RES]) / \
                                    (end-start)
                    cap_delim_veh_removed -= filtered_row[constants.CAP_N_DELIM_S]
                    cap_not_delim_veh_removed -= filtered_row[constants.CAP_N_UNDELIM_S]
                    cap_tot_veh_removed = cap_delim_veh_removed + cap_not_delim_veh_removed
                    cap_len_removed -= cap_len_removed * percentage_rm
                # Current regulation overlap the end of another reg with higher priority.
                elif end > filtered_row[constants.CAP_END_RES]:
                    percentage_rm = (filtered_row[constants.CAP_END_RES] - start) / \
                                    (end-start)
                    cap_delim_veh_removed -= filtered_row[constants.CAP_N_DELIM_S]
                    cap_not_delim_veh_removed -= filtered_row[constants.CAP_N_UNDELIM_S]
                    cap_tot_veh_removed = cap_delim_veh_removed + cap_not_delim_veh_removed
                    cap_len_removed -= cap_len_removed * percentage_rm
                # Current regulation is contained in another reg with higher priority
                else:
                    cap_len_removed = 0
                    cap_delim_veh_removed = 0
                    cap_tot_veh_removed = 0

            filtered_seg_info.append(row)
            cap_len_to_substract.append(cap_len_removed)
            cap_veh_to_substract.append(cap_tot_veh_removed)
            cap_veh_delim_to_substract.append(cap_delim_veh_removed)

        # update seg capacity
        cap_len -= sum(cap_len_to_substract)
        cap_veh -= sum(cap_veh_to_substract)
        cap_veh_delim -= sum(cap_veh_delim_to_substract)

        ### 3 - Create segment capacity
        # Get restriction
        restriction = self.seg_info.loc[self._priority_reg(regs_total), constants.CAP_RESTRICTIONS] if regs_total else base[constants.CAP_RESTRICTIONS].iloc[0]
        restriction_type = self.seg_info.loc[self._priority_reg(regs_total), constants.CAP_RES_TYPE] if regs_total else base[constants.CAP_RES_TYPE].iloc[0]
        restrict_id = self._priority_reg(regs_total) if regs_total else np.nan

        new_row = row.copy()
        new_row[constants.CAP_SPACE] = cap_len
        new_row[constants.CAP_N_VEH] = cap_veh
        new_row[constants.CAP_N_DELIM_S] = cap_veh_delim
        new_row[constants.CAP_N_UNDELIM_S] = cap_veh - cap_veh_delim
        new_row['restrict_id'] = restrict_id
        new_row[constants.CAP_IS_RESTRICT] = str(restriction) != 'nan'
        new_row[constants.CAP_RES_HOUR_FROM] = self.seg_info.loc[self._priority_reg(regs_total), constants.CAP_RES_HOUR_FROM] if regs_total else np.nan 
        new_row[constants.CAP_RES_HOUR_TO] = self.seg_info.loc[self._priority_reg(regs_total), constants.CAP_RES_HOUR_TO] if regs_total else np.nan 
        new_row[constants.CAP_RES_DAYS] = self.seg_info.loc[self._priority_reg(regs_total), constants.CAP_RES_DAYS] if regs_total else np.nan 
        new_row[constants.CAP_RESTRICTIONS] = restriction
        new_row[constants.CAP_RES_TYPE] = restriction_type

        return new_row

    def _capacity(self, time_value, ignore_hours=True, ignore_days=True):
        """ Compute total capacity of the segment database contains in the object.

        Parameters
        ----------
        time_value: datetime
            The temporal instant when to querry the capacity.
        ignore_days: boolean (Default: False)
            Ignore day-based regulations ? 
        ignore_hours: boolean (Default: False)
            Ignore hour-based regulations ? 

        Returns
        -------
        cap_data: pandas.DataFrame
            The dataframe of all segments capacity computed.
        """

        try : 
            capacity = pd.read_csv(os.path.join(
                self.cache_path, 
                f'{time_value}_ign_d={ignore_days}_ign_h={ignore_hours}.csv'.replace(':', '-')\
                                                                            .replace(' ', '_')
            ))
        except FileNotFoundError:
            seg_info = self.seg_info.copy() 
            seg_info['datetime'] = time_value#pd.to_datetime(time_value)

            grouped = seg_info.groupby([constants.SEGMENT, constants.SIDE_OF_STREET])
            segments_reg = []
            for seg_info, seg_cap in grouped:
                # for all restrictions
                new_row = self.get_segment_capacity(seg_info[0], seg_info[1], time_value, ignore_days=ignore_days, ignore_hours=ignore_hours)

                segments_reg.append(new_row)

            cap = pd.DataFrame(segments_reg)
            # add segments without restrictions
            base_add = self.seg_base.copy().join(
                self.seg_info.copy().set_index([constants.SEGMENT, constants.SIDE_OF_STREET])[['restrict_id']],
                on=[constants.SEGMENT, constants.SIDE_OF_STREET],
                how='left')
            base_add = base_add[base_add['restrict_id'].isna()] 

            capacity = pd.concat([cap, base_add])
            capacity.to_csv(
                os.path.join(
                    self.cache_path, 
                    f'{time_value}_ign_d={ignore_days}_ign_h={ignore_hours}.csv'.replace(':', '-')\
                                                                                .replace(' ', '_')
                ),
                index=False
            )

        return capacity

    def get_capacity(self, time_value=None, time_period=None):
        """ Compute the capacity available on the streets for the time_period 
        describe in the time_value.

        Parameters
        ----------
        time_value: string or tuple.
            The timestamp when to querry the capacity. See example for format.
        time_period: enum (Default: None)
            Information to extract form time value to compute capacity. Values must
            be chosen between : None, `hour`, `day`, `dh`, `all`.

        Returns
        -------
        cap_data: pandas.DataFrame
            The dataframe of all segments capacity computed.

        Example
        -------

        1. get_capacity(('lun', '2019-01-01 10:00:00'), 'dh') -> compute the parking capacity on 
            street by removing all regulations that applies on Monday at 10am.

        2. get_capacity('lun', 'day') -> compute the parking capacity on 
            street by removing all regulations that applies on Monday at any hour of the day.

        3. get_capacity('2019-01-01 10:00:00', 'day') -> compute the parking capacity on 
            street by removing all regulations that applies on all days at 10am.

        4. get_capacity() -> compute the parking capacity on street by removing all 
            regulations that applies at all times.
        """
        
        if time_period == 'hour':
            date = pd.to_datetime(time_value)
            ignore_days=True
            ignore_hours=False
        elif time_period == 'day':
            date = pd.to_datetime('today') 
            date += datetime.timedelta(days = (parse_days(time_value)[0] - date.weekday()) % 7)
            ignore_hours=True
            ignore_days=False
        elif time_period == 'dh':
            date = pd.to_datetime(time_value[1])
            date += datetime.timedelta(days = (parse_days(time_value[0])[0] - date.weekday()) % 7)
            ignore_hours=False
            ignore_days=False
        elif time_period == 'all':
            date = pd.to_datetime('today')
            ignore_hours=True
            ignore_days=True
        else:
            date = pd.to_datetime(time_value)
            ignore_hours=False
            ignore_days=False

        return self._capacity(
            date,
            ignore_hours=ignore_hours, 
            ignore_days=ignore_days
            )
