# -*- coding: utf-8 -*-
"""
Created on Wed Jun  9 10:12:56 2021

@author: lgauthier
@author: alaurent
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely.wkt as wkt

from . import constants
from .utils import parse_restrictions
from .utils import restriction_aggfunc
from .utils import enforce_restrictions
from .utils import expand_network
from .utils import update_capacity
from ..tools.ctime import Ctime
from ..tools.utils import checkraise, IncompleteDataError
from ..tools.geohelper import DEFAULT_CRS

def compile_occupancy(enhLapi, occup_on='meter', veh_size=5.5):
    """
    Compile the occupancy on each side of street segments. The data must first
    be matched on the streets using the enhancement process.

    Parameters
    ----------
    enhLapi : pandas.DataFrame
        The sighting data, must have been ran through the enhancement process
        beforehand.
    segInfo : pandas.DataFrame
        The network data, containing the number of spaces in the network (either
        in meters with a column named 'Espace_stationnement (m)' or in car spaces
        with a column named 'nb_places') and restrictions to those places compiled
        with columns named 'restrictions', 'res_hour_from', 'res_hour_to', and
        'res_days'. See :py:func:`analysis.occup.parse_restrictions` for a description
        of those columns.
    occup_on : str, optional
        The method to use to calculate the occupancy. The choices are 'meter' to
        calculate directly from the footprint of the sighted vehicules vs the
        availaible space or 'veh' to transform the available space in
        car-equivalent spaces and compare on a car vs acr-equiv. basis.
        Default 'meter'.

    Raises
    ------
    ValueError
        Indicate that segment_geodbl_geom is not present, which means that the
        enhancement process was not ran prior to calling this function.

    Returns
    -------
    occ_df : geopandas.GeoDataFrame
        A db describing each segment's side of street' occupancy.

    """
    checkraise(occup_on, ['meter', 'veh'], 'occup_on')

    if enhLapi.empty:
        return gpd.GeoDataFrame()

    if not constants.SEG_DB_GIS in enhLapi.columns:
        raise IncompleteDataError(constants.SEG_DB_GIS, 'enhLapi',
                                  'Try running the enhancement process first.')
    if not 'lap_id' in enhLapi.columns:
        raise IncompleteDataError('lapi_id', 'enhLapi',
                                  'Try running the enhancement process first.')

    def wkt_loads(wkt_str):
        if pd.isna(wkt_str):
            return wkt_str
        return wkt.loads(wkt_str)

    if type(enhLapi[constants.SEG_DB_GIS].iloc[0]) == str:
        enhLapi[constants.SEG_DB_GIS] = enhLapi[constants.SEG_DB_GIS].apply(wkt_loads)

    # 1- Aggregate at <segment, side_of_street, lap_id> level
    grouped = enhLapi.groupby([constants.SEGMENT, constants.SIDE_OF_STREET, 'lap_id'])
    #we use this because nth(0) never fails when you want the first occurence
    res = grouped.agg({constants.PLAQUE:'count'}).rename(columns={constants.PLAQUE:'veh_sighted'})

    # 2- Set the time columns of aggregated data
    res['time'] = grouped.lap_time.nth(0)
    res['time'] = pd.to_datetime(res['time'])

    # 3- Recover segment geography and segment capacity
    res[constants.SEG_DB_GIS] = grouped[constants.SEG_DB_GIS].nth(0)
    res[constants.CAP_SPACE] = grouped[constants.CAP_SPACE].nth(0)
    res[constants.CAP_N_DELIM_S] = grouped[constants.CAP_N_DELIM_S].nth(0)
    res[constants.CAP_N_VEH] = grouped[constants.CAP_N_VEH].nth(0)
    res['seg_restrict'] = grouped['seg_restrict'].nth(0)

    #we'll need to change the index real soon
    res = res.reset_index()

    if occup_on == 'meter': 
        nb_place = res[constants.CAP_SPACE].astype(float).fillna(0) / veh_size + res[constants.CAP_N_DELIM_S].fillna(0)
        nb_place[nb_place < 1] = np.nan
        res['occ'] = res['veh_sighted'] / nb_place
    elif occup_on == 'veh':
        res['occ'] = res['veh_sighted'] / res[constants.CAP_N_VEH].astype(float)

    res['occ'] = res.apply(lambda x: x['occ'] if pd.isna(x['seg_restrict']) else x['seg_restrict'], axis=1)
    res['occ'] = res.apply(lambda x: x['occ'] if x[constants.CAP_N_VEH] != 0 else 'Aucune places', axis=1)

    return gpd.GeoDataFrame(res, geometry=constants.SEG_DB_GIS, crs=DEFAULT_CRS) #TODO: can we inherit the CRS from enhLapi? Or how do we make sure it's always in lat/long?

def _occup_h_pivot_handle(occ_df, geodbl, restrictionHandler, pivot_col='occ'):
    """ Aggregate the occupation at the segment and side of street level. The 
    aggregation is parametred by attribute pivot_col. Default is aggregated value
    is occupancy. In addition, restrictions are applied even if no data is recolted
    by the LAPI vehicule.

    Paramaters
    ----------
    occ_df : pandas.DataFrame
        Unagregated occupancy computed for each segment on each lap of a LAPI vehicule.
    geodbl : geopandas.GeoDataFrame
        Geographical data of roads side of street.
    restrictionHandler : analysis.restrictions.RestrictionHandler
        An instance of the restriction engine for this LAPI data.
    pivot_col : string (Default: 'occ')
        Column values that will be aggregated.

    Returns
    -------
    aggregated_data : geopandas.GeoDataFrame
       Data aggregated at side of street level with restrictions when it applies.
    """

    # pivot this to have a column per hour
    occ_h = occ_df.pivot_table(pivot_col, index=[constants.SEGMENT, constants.SIDE_OF_STREET],
                               aggfunc=lambda x: restriction_aggfunc(x.to_list()),
                               columns='time', dropna=False).reset_index()

    # add the geom
    occ_h['COTE'] = occ_h[constants.SIDE_OF_STREET].map({-1:'Gauche', 1:'Droite'})
    if constants.SECTEUR_NAME in geodbl.columns:
        geodbl_cols = ['geometry', constants.SECTEUR_NAME]
    else:
        geodbl_cols = 'geometry'
    occ_h = (occ_h.join(geodbl.set_index(['ID_TRC', 'COTE'])[geodbl_cols],
                    on=[constants.SEGMENT, 'COTE'],
                    how='left')
              .rename(columns={'geometry':constants.SEG_DB_GIS})
              .drop(columns=['COTE'])
              .drop_duplicates(keep='first')
              )

    #as geopandas.GeoDataFrame
    occ_h = gpd.GeoDataFrame(occ_h, geometry=constants.SEG_DB_GIS, crs=occ_df.crs)

    #add all the roads in the analysis zone
    complete = expand_network(occ_h, geodbl)

    #enforce restrictions
    return enforce_restrictions(complete, restrictionHandler, zero_observ=False)

def occupancy_h(geodbl, enhLapi, resHandler, occup_on='meter',
                round_time_on=30, round_method='ceil', timeslot_beg='0h00',
                timeslot_end='23h59', veh_size=5.5, round_interval={'00h00-24h00': '0'}):
    """
    Compile the occupancy at the granular level of a road segment and an hour.
    The data must first be matched on the streets using the enhancement process.

    Parameters
    ----------
    geodbl : geopandas.GeoDataFrame
        The road network containing both sides of the road to clip data on. All
        of the roads contained in this geodataframe will be returned in the output.
        Clipping this geodataframe to the analysis zone beforehand is recommanded
        to reduce calculation times.
    enhLapi : pandas.DataFrame
        The sighting data, must have been ran through the enhancement process
        beforehand.
    segInfo : pandas.DataFrame
        The network data, containing the number of spaces in the network (either
        in meters with a column named 'Espace_stationnement (m)' or in car spaces
        with a column named 'nb_places') and restrictions to those places compiled
        with columns named 'restrictions', 'res_hour_from', 'res_hour_to', and
        'res_days'. See :py:func:`analysis.occup.parse_restrictions` for a description
        of those columns.
    occup_on : str, optional
        The method to use to calculate the occupancy. The choices are 'meter' to
        calculate directly from the footprint of the sighted vehicules vs the
        availaible space or 'vehicule' to transform the available space in
        car-equivalent spaces and compare on a car vs acr-equiv. basis.
        Default 'meter'.
    round_time_on : int, optional
        Time interval used to round the time passages on. Default 30.
    round_method : str, optional
        Method used to round the passages. Must be one of 'ceil', 'floor',
        or 'round'. Default 'ceil'.
    timeslot_beg : str, optional
        Starting hour for compiling occupancy. Default '0h00'.
    timeslot_end : str, optional
        Stoping hour for compiling occupancy. Default '23h59'.

    Returns
    -------
    occ_h : geopandas.GeoDataFrame
        A db describing each segment's side of street' occupancy by hour.

    """
    checkraise(round_method, ['ceil', 'floor', 'round'], 'round_method')

    occ_df = compile_occupancy(enhLapi, occup_on=occup_on, veh_size=veh_size)

    if occ_df.empty:
        return gpd.GeoDataFrame()

    # extract relevant functions and transform the times:
    #    1 - raw string to datetime
    occ_df['time'] = pd.to_datetime(occ_df.time)

    #    2 - datetime to ctime
    occ_df['time'] = [Ctime.from_datetime(t) for t in occ_df.time]

    #    3 - round to appropriate time interval
    for time_slot, minutes in round_interval.items():
        ri_ts_beg = time_slot.split('-')[0]
        ri_ts_end = time_slot.split('-')[1]
        occ_df.loc[(occ_df['time'] >= Ctime.from_string(ri_ts_beg)) &
                   (occ_df['time'] <= Ctime.from_string(ri_ts_end)), 'time'] += int(minutes) * 100

    occ_df['time'] = [t.round_time(how='ceil', round_min_base=round_time_on) for t in occ_df.time]

    for time_slot, minutes in round_interval.items():
        ri_ts_beg = time_slot.split('-')[0]
        ri_ts_end = time_slot.split('-')[1]
        occ_df.loc[(occ_df['time'] >= Ctime.from_string(ri_ts_beg)) &
                   (occ_df['time'] <= Ctime.from_string(ri_ts_end)), 'time'] -= int(minutes) * 100

    #    4 - parse relevant hours
    occ_df = occ_df[(occ_df['time'] >= Ctime.from_string(timeslot_beg)) &
                    (occ_df['time'] <= Ctime.from_string(timeslot_end))
                    ]

    #    5 - ctime to datetime
    occ_df['time'] = [t.as_string(stringFormat='hhmm') for t in occ_df.time]

    #parse relevant data
    occ_h =       _occup_h_pivot_handle(occ_df, geodbl, resHandler, pivot_col='occ')
    veh_sighted = _occup_h_pivot_handle(occ_df, geodbl, resHandler, pivot_col='veh_sighted')
    capacity =    _occup_h_pivot_handle(occ_df, geodbl, resHandler, pivot_col=constants.CAP_N_VEH)

    #force int type in the capacity strings
    def try_to_force_int_string(x):
        if not isinstance(x, str):
            return x
        try:
            return str(int(float(x)))
        except:
            return x
    capacity = capacity.applymap(try_to_force_int_string)

    return occ_h, veh_sighted, capacity

def occupancy_timeslot(occH):
    """
    Compile the occupancy at the granular level of a road segment and a specified timeslot (maximum one day).

    Parameters
    ----------
    occ_df : pandas.DataFrame
        Occupancy rate compiled by segment, side_of_street and hour.

    Returns
    -------
    occupancy_h : geopandas.GeoDataFrame
        A db describing each segment's side of street' occupancy at the granular level of a timeslot.
    """
    if occH.empty:
        return gpd.GeoDataFrame()

    secteur_name_col = [constants.SECTEUR_NAME] if constants.SECTEUR_NAME in occH.columns else [] 
    occ_ts = (occH.set_index([constants.SEGMENT, constants.SIDE_OF_STREET])
                  .drop(columns=[constants.SEG_DB_GIS] + secteur_name_col)
                  .apply(lambda x: restriction_aggfunc(x.to_list()), axis=1)
                  .reset_index()
                  .rename(columns={0:'mean_occ'})
                  .join(occH.set_index([constants.SEGMENT, constants.SIDE_OF_STREET])[[constants.SEG_DB_GIS]+secteur_name_col],
                        on=[constants.SEGMENT, constants.SIDE_OF_STREET])
                  )
    occ_ts['weight'] = np.count_nonzero(
                           ~(occH.set_index([constants.SEGMENT, constants.SIDE_OF_STREET])
                                  .drop(columns=[constants.SEG_DB_GIS] + secteur_name_col)
                                  .isna()),
                           axis=1
                       )
    return gpd.GeoDataFrame(occ_ts, geometry=constants.SEG_DB_GIS, crs=occH.crs)