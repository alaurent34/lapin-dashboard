import datetime
import pandas as pd
import numpy as np
import geopandas as gpd
import copy

from . import constants
from ..tools.ctime import Ctime
from ..tools.utils import deprecated

DAYS = ['lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim']

def parse_days(day):
    """ Parse a days interval express by string to list of
   datetime.dayofweek values.

    Parameters
    ----------
    day : string
        a string representing a day interval. Takes values from DAYS.

    Return
    ------
    list_of_days : list of int
        int representation of the day interval.

    Example
    -------
    1. Joint interval of several days :
        >>> parse_days('lun-mer') ---> return [0, 1, 2]
    2. Interval of disjoint days :
        >>> parse_days('lun+mer') ---> return [0, 3]
    3. Interval of only one day :
        >>> parse_days('lun') ----> return [0]
    """
    if day == 'dim-sam':
        return list(range(0, 7))
    day = day.strip()
    if day in DAYS:
        return [DAYS.index(day)]

    if '-' in day:
        first = DAYS.index(day.split('-')[0].strip())
        last = DAYS.index(day.split('-')[-1].strip())

        return list(range(first, last+1))

    if '+' in day:
        return [DAYS.index(d.strip()) for d in day.split('+')]

def restriction_aggfunc(list_occ, type='mean'):
    """ Compute the aggregate mean of all occupancy in list. The aggregation
    function behave as this :
        1 - If only a slice of the list is a string, remove all occurances.
        2 - If all elements are numeric, return np.mean(list_occ)
        3 - Else return the first string occurance.

    Parameters
    ----------
    list_occ : list
        The list of all occupancy value to aggregate

    Return
    ------
    occ : str or int
        The occupancy to be displayed.

    Example
    -------
    1. Multi-valuated list
        >>> print(list_occ)
            [0.32, nan, 'travaux']
        >>> occupancy_restriction_aggfun(list_occ) ---> return 0.32
    2. Only strings
        >>> print(list_occ)
            ['travaux', nan, 'travaux']
        >>> occupancy_restriction_aggfun(list_occ) ---> return travaux
    3. Only float
        >>> print(list_occ)
            [0.32, 0.32, 0.32]
        >>> occupancy_restriction_aggfun(list_occ) ---> return 0.32
    """

    # remove nan
    list_occ = [x for x in list_occ if not pd.isna(x)]

    # empty list
    if not list_occ:
        return np.nan

    # count string (i.e. restrictions)
    nb_str_valued_occ = np.count_nonzero([isinstance(occ, str) for occ in list_occ])

    # is occ part-string part-float ? then remove strings
    if nb_str_valued_occ < len(list_occ):
        list_occ = [occ for occ in list_occ if not isinstance(occ, str)]

    # if all occ are restrictions
    elif nb_str_valued_occ == len(list_occ):
        return list_occ[0]
    if type=='mean':
        return np.nanmean(list_occ)
    if type=='sum':
        return np.nansum(list_occ)
    return np.nanmedian(list_occ)

def expand_network(occ_h, geodbl):
    """
    Fuse the occupation dataframe with the geodbl dataframe to obtain a complete
    occupancy_h dataframe.

    Parameters
    ----------
    occ_h : geopandas.GeoDataFrame
        A db describing each segment's side of street' occupancy by hour.
    geodbl : geopandas.GeoDataFrame
        The road network containing both sides of the road to clip data on. All
        of the roads contained in this geodataframe will be returned in the output.
        Clipping this geodataframe to the analysis zone beforehand is recommanded
        to reduce calculation times.

    Returns
    -------
    complete_occ_h : geopandas.GeoDataFrame
        Occupancy rate compiled by segment and hours on each road contained in
        geodbl.

    """
    occ_h = occ_h.copy()
    geodbl = geodbl.copy()

    #clip the data to the road network in the zone
    geodbl[constants.SIDE_OF_STREET] = geodbl.COTE.map({'Gauche':-1, 'Droite':1})

    #find roads that are present in both df
    presents = pd.merge(occ_h, geodbl, how='inner',
                        left_on=[constants.SEGMENT, constants.SIDE_OF_STREET],
                        right_on=['ID_TRC', constants.SIDE_OF_STREET]
                        ).COTE_RUE_ID.tolist()

    #get the missing roads by sorting out the presents ones
    secteur_name_col = [constants.SECTEUR_NAME] if constants.SECTEUR_NAME in geodbl.columns else []
    missing = (geodbl[~geodbl.COTE_RUE_ID.isin(presents)]
               .rename(columns={'ID_TRC':constants.SEGMENT})
               .rename_geometry(constants.SEG_DB_GIS)
               )[[constants.SEGMENT, constants.SIDE_OF_STREET, constants.SEG_DB_GIS]+secteur_name_col]

    return pd.concat([occ_h, missing])

def enforce_restrictions(occ_h, restrictionHandler, zero_observ=True, time_period='hour'):
    """


    Parameters
    ----------
     occ_h : geopandas.GeoDataFrame
        A db describing each segment's side of street' occupancy by hour.
    segInfo : pandas.DataFrame
        The network data, containing the number of spaces in the network (either
        in meters with a column named 'Espace_stationnement (m)' or in car spaces
        with a column named 'nb_places') and restrictions to those places compiled
        with columns named 'restrictions', 'res_hour_from', 'res_hour_to', and
        'res_days'. See :py:func:`analysis.occup.parse_restrictions` for a description
        of those columns.

    Returns
    -------
    corrected_occ_h : TYPE
        DESCRIPTION.

    """
    occ_h = occ_h.copy()

    occ_h = occ_h.set_index([constants.SEGMENT, constants.SIDE_OF_STREET]).sort_index()
    #find relevant columns to parse
    cols = [c for c in occ_h.columns if c not in [constants.SEGMENT, constants.SIDE_OF_STREET,
                                                  constants.SEG_DB_GIS, 'park_type', constants.SECTEUR_NAME]]

    #make sure the restrictions are correctly applied
    for col in cols:
        segInfo = restrictionHandler.get_capacity(time_value=col, time_period=time_period)
        withRestricts = pd.merge(occ_h, segInfo, how='inner',
                         on=[constants.SEGMENT, constants.SIDE_OF_STREET],
                         )[[constants.SEGMENT, constants.SIDE_OF_STREET]].to_dict(orient='split')['data']
        #raise ValueError

        if len(withRestricts) > 0:
            #prepare the dfs
            segInfo = segInfo.set_index([constants.SEGMENT, constants.SIDE_OF_STREET]).sort_index()

            for segId in withRestricts:
                segId = tuple(segId)
                #skip segId not in segInfo
                if not segId in segInfo.index.tolist():
                    continue

                row = segInfo.loc[[segId]].iloc[0]
                #skip no restrictions to save time from parse_restrictions
                if pd.isna(row['restrictions']):
                    #if we had some data here, then we want to keep it
                    if not pd.isna(occ_h.at[segId, col]):
                        continue

                    #otherwise check if we have infos for capacity
                    if ( not pd.isna(row[constants.CAP_N_VEH]) or \
                       not row[constants.CAP_N_VEH] == 0) and zero_observ:
                        #then we only have have 0 views on non-0 capacity
                        occ_h.at[segId, col] = np.float64(0)
                        #else the nan value stays there

                else:
                    #if we have a result that is not "nan" here, we assume that
                    #the restriction doesn't apply always and just return the
                    #data
                    # if not pd.isna(occ_h.at[segId, col]):
                    #     continue
                    #TODO: verify that this work on a project where it's relevant
                    #and if not, then find a way to feed a df with days used to
                    #compile each hours

                    occ_h.loc[segId, col] = segInfo.loc[segId, 'restrictions']

    #set back missing to interger indexing
    occ_h = occ_h.reset_index()

    return occ_h

def compare_two_lapi_results(res1, res2, seg_gis, metric_name='mean_occ'):
    """ Function to compare two already computed lapi metric results in 
    the same space. In the function res2 is compared to res1. Hence the 
    output will show res2 - res1. Also, only the data present on common 
    road will be process in the comparison.
    
    Parameters
    ----------
    res1: pd.DataFrame
        First result.
    res2: pd.DataFrame
        Second result to compare to the first one.
    seg_gis: gpd.GeoDataFrame
        Roads geography for the study zone
    metric_name: str
        Columns name of the metric to compare.
    """
    # 1-Read rempla past and new
    res1 = res1.copy()
    res2 = res2.copy()

    if constants.SEG_DB_GIS in res1.columns:
        res1.drop(columns=constants.SEG_DB_GIS, inplace=True)

    ## change metric columns of second result
    res2.rename(columns={metric_name:metric_name+'_compared'}, inplace=True)

    # 2-Add geometry to occupancy data
    res2[constants.SEG_DB_SIDE] = res2.side_of_street.map({-1:'Gauche', 1:'Droite'})
    res2 = (res2.join(seg_gis.set_index([constants.SEG_DB_ID, constants.SEG_DB_SIDE])[['geometry', constants.SEG_DB_STREET]],
                    on=[constants.SEGMENT, constants.SEG_DB_SIDE],
                    how='left')
              .rename(columns={'geometry':constants.SEG_DB_GIS})
              .drop(columns=[constants.SEG_DB_SIDE])
              .drop_duplicates(keep='first')
              )
    ## as geopandas.GeoDataFrame
    res2 = gpd.GeoDataFrame(res2, geometry=constants.SEG_DB_GIS, crs=seg_gis.crs)

    # 3-Process occupancy of both year to make it comparable
    ## Aucune places, Travaux and Voie réservée have an occupancy of 0
    res2.loc[res2[metric_name+'_compared'].isin(['Travaux', 'Voie réservée']), metric_name+'_compared'] = np.nan
    res1.loc[res1[metric_name].isin(['Aucune places', 'Aucune place', 'Travaux', 'Voie réservée']), metric_name] = np.nan

    ## Non parcourue have an occupancy of nan
    res2.loc[res2[metric_name+'_compared'].isin(['Non parcourue']), metric_name+'_compared'] = np.nan
    res1.loc[res1[metric_name].isin(['Non parcourue']), metric_name] = np.nan

    ## filter street segment both in 2019 and 2021
    occ_merge = res2.merge(res1, on=[constants.SEGMENT, constants.SIDE_OF_STREET], how='inner')

    ## set "N'a plus de stationnement" to stationnement changed
    occ_merge.loc[occ_merge[metric_name+'_compared'].isin(['Aucune places', 'Aucune place']) & (occ_merge[metric_name] > 0), metric_name+'_compared'] = "N'a plus de stationnements"
    occ_merge.loc[occ_merge[metric_name+'_compared'] ==  "N'a plus de stationnements", metric_name] = "N'a plus de stationnements"
    # remove nan values
    occ_merge = occ_merge[~occ_merge[metric_name].isna() & ~occ_merge[metric_name+'_compared'].isna()]

    ### retrieve data
    res1 = occ_merge[[constants.SEGMENT, constants.SIDE_OF_STREET, metric_name, constants.SEG_DB_GIS]]
    res2 = occ_merge[[constants.SEGMENT, constants.SIDE_OF_STREET, metric_name+'_compared', constants.SEG_DB_GIS]]

    # 4-Expand both network to plot all segment of parcours
    col_sec = [constants.SECTEUR_NAME] if constants.SECTEUR_NAME in seg_gis.columns else []
    res1 = expand_network(res1, geodbl=seg_gis).drop(columns=col_sec)
    res2 = expand_network(res2, geodbl=seg_gis).drop(columns=col_sec)

    # 6-Remove nan
    res2.dropna(inplace=True)
    res1.dropna(inplace=True)

    # 7-Compare the results
    def compare_occ(val1, val2):
        if pd.isna(val1) and pd.isna(val2):
            return np.nan
        if not pd.api.types.is_number(val1) and val1 == val2:
            return val1
        if not pd.api.types.is_number(val1) or pd.isna(val1):
            val1 = 0
        if not pd.api.types.is_number(val2) or pd.isna(val2):
            val2 = 0
        return val1 - val2

    compared = np.array(list(map(compare_occ, res2[metric_name+'_compared'].values, res1[metric_name].copy())))

    return res1, res2, compared

@deprecated
def update_capacity(grouped, ignore_hours=False, ignore_days=False, time_col='time'):
    """ Parse the joined data of restrictions and aggregated LAPI record to determine what is the 
    capacity of a segment at one moment.

    """

    # iter on each segment, side_of_street, lap
    segments_reg = []
    for _, seg_cap in grouped:
        regs = []
        cap = 0
        # for all restrictions
        for _, row in seg_cap.iterrows():
            # if there is a restriction on this segments, save it
            if is_restriction(row, ignore_hours, ignore_days, time_col=time_col):
                regs.append(row['restrictions'])
            # and get capacity of non restricted portion of segments
            else:
                cap += row[constants.CAP_SPACE]

        # if capacity is 0, then anotate a restriction else leave it blank
        restriction = np.nan
        if cap == 0:
           restriction = regs[0] 
        new_row = row.copy()
        new_row[constants.CAP_SPACE] = cap
        new_row[constants.CAP_N_VEH] = cap / 5.5
        new_row[['res_hour_from', 'res_hour_to', 'res_days']] = np.nan
        new_row['restrictions'] = restriction

        segments_reg.append(new_row)

    return pd.DataFrame(segments_reg)
            
@deprecated
def parse_restrictions(row, ignore_hours=False, ignore_days=False, metric_col='occ', time_col='time'):
    """ Parse a row of atomic <segment, side_of_street, lap_id> occupation
    with a regulation associated. If there is a regulations, return it's
    name, else return the occupancy.

    Parameters
    ----------
    row : pandas.Series
        a row of atomic segment occupation.

    Return
    ------
    occ : str or int
        return the occupation if there is no regulations in vigor on this
        segment.

    Example
    -------
    1. Row without regulation
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | occ   |
            ...|:---------------|----------------:|--------------:|:------|
            ...| NaN            | NaN             | NaN           | 0.43  |
        >>> parse_restriction(row) ---> return 0.43
    2. Row with regulation not in vigor
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | res_days   | occ   |
            ...|:---------------|----------------:|--------------:|:-----------|:------|
            ...| travaux        | NaN             | NaN           | lun-mar    | 0.43  |
        >>> parse_restriction(row) ---> return 0.43
    3. Row with regulation in vigor
        >>> print(row)
            |    |   segment |   side_of_street | lap_id   |....
            |---:|----------:|-----------------:|:---------|....
            |  0 |   1170007 |               -1 | veh1_1   |....
            ...| restrictions   |   res_hour_from |   res_hour_to | res_days   | occ   |
            ...|:---------------|----------------:|--------------:|:-----------|:------|
            ...| travaux        | NaN             | NaN           | NaN        | 0.43  |
        >>> parse_restriction(row) ---> return 'travaux'
    """

    if is_restriction(row, ignore_hours, ignore_days, time_col=time_col):
        return row['restrictions']
    return row[metric_col]
