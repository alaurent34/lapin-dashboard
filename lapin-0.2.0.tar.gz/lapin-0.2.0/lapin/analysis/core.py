"""
Core processing for LAPI

Created on Wed Jun  9 10:12:27 2021

@author: lgauthier
@author: alaurent
"""

import os
import sys
from copy import deepcopy

import numpy as np
import pandas as pd
import geopandas as gpd
import warnings

from . import constants
from . import basic
from . import occup
from . import rempla
from . import prov
from .utils import parse_days
from .utils import restriction_aggfunc
from .restrictions import RestrictionHandler
from ..transactions.core import TransactionHandler
from ..tools.ctime import Ctime
from ..tools.strings import is_numeric_transformable
from ..tools.utils import MissingDataWarning, deprecated
from ..tools.geohelper import MONTREAL_CRS, DEFAULT_CRS
from ..tools import geohelper
from ..figures import occup as f_occup
from ..figures import rempla as f_rempla
from ..figures import prov as f_prov
from ..figures import base as f_base
from ..transactions import constants as transac_c
from ..enhancement import data as data_m
from .. import config


def expend_time_interval(t_beg, t_end, as_string=True, strformat='hhmm'):
    """ Take a time period express by a hour interval and create a list of all
    the hour present in it.

    Parameters
    ----------
    t_beg: str
        Hour in format f"{HH}h{mm}".
    t_end: str
        Hour in format f"{HH}h{mm}".

    Returns
    -------
    h_list : list of Ctime
        list of expended interval.
    """
    t_beg = Ctime.from_string(t_beg)
    t_end = Ctime.from_string(t_end)
    h_list = [deepcopy(t_beg)]

    while t_beg < t_end:
        t_beg.addTime(10000)
        h_list.append(deepcopy(t_beg))

    if as_string:
        h_list = [t.as_string(stringFormat=strformat) for t in h_list]

    return h_list

def parse_hours_bound(hb_dict, **kwargs):
    """ Return all hours of study in a hoursBounds config dictionary

    Parameters
    ----------
    hb_dict : dict
        Hours bounds dict format. See config file for example.

    Returns
    -------
    h_list : list
        List of all studied hours.
    """
    total_hours = []
    for _, h_bounds in hb_dict.items():
        total_hours.append(expend_time_interval(*h_bounds, **kwargs))

    # we remove first hour
    return list(np.unique(total_hours)[1:])

class Analyser():
    """ Analysis framework. Take as input park vehicule position to 
    compute several evaluation metrics. Data must be in an correct format (i.e. 
    passed to the data enhancer before).

    Parameters
    ----------
    data : pandas.DataFrame
        DESCRIPTION
    seg_info : pandas.DataFrame
        DESCRIPTION
    seg_gis : geopandas.GeoDataFrame
        DESCRIPTION
    delim : geopandas.GeoDataFrame
        DESCRIPTION
    hours_bound : dict
        DESCRIPTION
    act_occup : bool, optional
        DESCRIPTION
    act_rempla : bool, optional
        DESCRIPTION
    act_prov : bool, optional
        DESCRIPTION
    save_path : str, optional
        DESCRIPTION
    crs : dict, optional
        DESCRIPTION
    proj_crs : dict, optional
        DESCRIPTION
    """

    def __init__(self, data, seg_info, seg_gis, delim,
                visDelim, hours_bounds, round_hours, daysBound,
                trips=pd.DataFrame(columns=constants.TRIPS_COLS),
                discretisation_prov=pd.DataFrame(),
                act_occup=True, act_rempla=False, act_prov=False,
                lat_ori_col=constants.ORIGIN_LAT,
                lng_ori_col=constants.ORIGIN_LNG,
                lat_dest_col=constants.DESTINATION_LAT,
                lng_dest_col=constants.DESTINATION_LNG,
                uid_col=constants.UID, date_col=constants.DATETIME,
                lap_col=constants.LAP, lap_time_col=constants.LAP_TIME,
                seg_col=constants.SEGMENT, seg_gis_col=constants.SEG_DB_GIS,
                point_on_seg_col=constants.POINT_ON_STREET,
                save_path=constants.CACHE, crs=DEFAULT_CRS,
                local_crs=MONTREAL_CRS, fig_dpi=None,
                map_dpi=None, leg_dpi=None, comp_sect_agg=False,
                gisBoundsNames="Nom", gisVisBoundsNames="Nom",
                visRotation=None, visBuffer=None, numProj=0,
                titleProj='',
                **kwargs):

        # save data
        self.datastore = data.reset_index(drop=True).copy()
        self.restriction_handler = RestrictionHandler(
            seg_info, 
            cache_path=os.path.join(save_path, 'restrict')
        )
        self.seg_info = self.restriction_handler.seg_info.copy()
        self.seg_gis = seg_gis.copy()
        self.delim = delim
        self.trips = trips.copy()
        self.delimName = gisBoundsNames
        self.visDelim = visDelim
        self.visDelimName = gisVisBoundsNames
        self.visRotation = visRotation
        self.visBuffer = visBuffer
        self.discretisation_prov=discretisation_prov
        self.days_bounds = daysBound

        usercols_2_enhancer = {
            lat_ori_col:constants.ORIGIN_LAT,
            lng_ori_col:constants.ORIGIN_LNG,
            lat_dest_col:constants.DESTINATION_LAT,
            lng_dest_col:constants.DESTINATION_LNG,
            uid_col:constants.UID,
            date_col:constants.DATETIME,
            lap_col:constants.LAP,
            lap_time_col:constants.LAP_TIME,
            seg_col:constants.SEGMENT,
            seg_gis_col:constants.SEG_DB_GIS,
            point_on_seg_col:constants.POINT_ON_STREET
            }

        # rename columns
        self.datastore = self.datastore.rename(columns=usercols_2_enhancer)
        self.seg_info = self.seg_info.rename(columns=usercols_2_enhancer)
        self.seg_gis = self.seg_gis.rename(columns=usercols_2_enhancer)
        self.trips = self.trips.rename(columns=usercols_2_enhancer)

        # transform datetime to datetime
        self.datastore['datetime'] = pd.to_datetime(self.datastore.datetime)

        # other paramters
        self.hours_bounds = hours_bounds
        self.round_hours = round_hours
        self.comp_occup = act_occup
        self.comp_rempla = act_rempla
        self.comp_prov = act_prov
        self.project_save_path=save_path
        self.save_path = deepcopy(self.project_save_path)
        self.basename = f"{numProj}_{titleProj[:3]}-"
        os.makedirs(self.save_path, exist_ok=True)
        self.data_crs = crs
        self.local_crs = local_crs
        self.fig_dpi = kwargs.pop('fig_dpi', None)
        self.map_dpi = kwargs.pop('map_dpi', None)
        self.leg_dpi = kwargs.pop('leg_dpi', None)
        self.comp_sect_agg = comp_sect_agg

        # uniformize crs
        if self.seg_gis.crs != self.data_crs:
            self.seg_gis.to_crs(self.data_crs, inplace=True)
        if self.delim.crs != self.data_crs:
            self.delim.to_crs(self.data_crs, inplace=True)
        if self.visDelim.crs != self.data_crs:
            self.visDelim.to_crs(self.data_crs, inplace=True)

        # create graph
        #roads = data_m.read_data(config.ROADS_CONNECTION)
        #graph = geohelper.construct_graph(
        #    lines=roads,
        #    limits=self.delim, 
        #    crs=MONTREAL_CRS
        #)
        #self.seg_info['De'] = self.seg_info.apply(
        #    lambda x: geohelper.get_roads_intersection_name(graph, x.segment)[0],
        #    axis=1
        #)
        #self.seg_info['À']  = self.seg_info.apply(
        #    lambda x: geohelper.get_roads_intersection_name(graph, x.segment)[1],
        #    axis=1
        #)
        #self.graph = graph

        # initialize results dict
        self.res = {
            'base': pd.DataFrame(),
            'occ_hour': pd.DataFrame(),
            'occ_timeslot': pd.DataFrame(),
            'parking_time': pd.DataFrame(),
            'rempla_at_least': pd.DataFrame(),
            'rempla_at_more': pd.DataFrame(),
            'park_cat_at_least': pd.DataFrame(),
            'park_cat_at_more': pd.DataFrame(),
            'prov': pd.DataFrame(),
            'trips': pd.DataFrame(),
            'park_dist_at_least': pd.DataFrame(),
            'park_dist_at_more': pd.DataFrame(),
           }

    def filter_restriction(self):
        """ This method check for all data point if there is an active 
            regulation where the point is located. Boolean column 'is_restricted'
            is created in the point dataframe.

        """
        data = self.datastore.copy()

        if 'is_restricted' in data.columns:
            print('Restriction already computed.')
            return data
        #seg_info = self.seg_info.copy()

        self.datastore = self.restriction_handler.apply_restriction(
            data,
            constants.INDEX,
            ignore_hours=False,
            ignore_days=False,
            time_col=constants.DATETIME
        )

        return data

    def analyse(self, data='Undefined', trips=pd.DataFrame(), handle_restriction=False, **kwargs):
        """Compute all the analysis accordingly to the config file

        Parameters
        ----------
        data: str or DataFrame (Default: 'Undefined')
            The dataFrame to analyse, if string, use the preloaded data in the analyser.
        handle_restrictions : boolean (Default: False)
            Indicate to clean lapi lecture that are present on a restricted road.

        Returns
        -------
        None

        TODO: Add parameters (maybe kwargs?) to overide the comp_occup, prov and remp self variables.
        """
        if isinstance(data, str):
            data = self.datastore.copy()

        self.res['base'] = self._base(data, **kwargs, handle_restriction=handle_restriction)

        if self.comp_occup:
            occ_h, occ_ts, veh_s, cap = self._occup(data, **kwargs, handle_restriction=handle_restriction)
            self.res['occ_hour'] = occ_h
            self.res['occ_timeslot'] = occ_ts
            self.res['vehicle_sighted'] = veh_s
            self.res['capacity'] = cap

            if self.comp_sect_agg:
                if not constants.SECTEUR_NAME in veh_s.columns or \
                   not constants.SECTEUR_NAME in cap.columns:
                       warnings.warn("La division par secteur n'a pas été effectuée, "+
                                     "l'aggégation par secteur ne peut donc pas être "+
                                     "complétée", MissingDataWarning)
                else:
                    occ, veh, cap = self._occup_agg(veh_s, cap)
                    self.res["agg_secteur_occ"] = occ
                    self.res["agg_secteur_vehicle_sighted"] = veh
                    self.res["agg_secteur_capacity"] = cap

        if self.comp_rempla:
            # we need occupancy for this analysis
            if not self.comp_occup:
                occ_h, occ_ts, _, _ = self._occup(data, **kwargs, handle_restriction=handle_restriction)
            else:
                occ_h = self.res['occ_hour']
                occ_ts = self.res['occ_timeslot']

            pk_time = self._rempla(data, **kwargs, handle_restriction=False)

            # parking time
            self.res['parking_time'] = pk_time
            self.res['rempla_at_least'] = rempla.park_time_street(pk_time[pk_time.first_or_last], self.restriction_handler, self.seg_gis, handle_restriction)
            self.res['rempla_at_more'] = rempla.park_time_street(pk_time[~pk_time.first_or_last], self.restriction_handler, self.seg_gis, handle_restriction)
            self.res['rempla'] = rempla.park_time_street(pk_time, self.restriction_handler, self.seg_gis, handle_restriction)

            # parking categories
            self.res['park_cat_at_least'] = rempla.categorize_parking_usage(
                pk_time[pk_time.first_or_last],
                occ_ts,
            )
            self.res['park_cat_at_more'] = rempla.categorize_parking_usage(
                pk_time[~pk_time.first_or_last],
                occ_ts,
            )
            self.res['park_cat'] = rempla.categorize_parking_usage(
                pk_time,
                occ_ts,
            )

            # partking time hist
            self.res['park_time_dist_at_least'] = rempla.park_time_distribution(
                pk_time[pk_time.first_or_last],
            )
            self.res['park_time_dist_at_more'] = rempla.park_time_distribution(
                pk_time[~pk_time.first_or_last],
            )
            self.res['park_time_dist'] = rempla.park_time_distribution(
                pk_time,
            )

        if self.comp_prov:

            trips_gdf, prov = self._prov(trips, **kwargs, handle_restriction=handle_restriction)
            self.res['prov'] = prov
            # one veh per trip
            self.res['trips'] = trips_gdf

        return self.res

    def plot(self, data, transac_plot=True, prov_hue_order=None, 
             plot_all_capacities=False, **kwargs):
        """ Plotting function. Plot all desired graph for the analysis.

        Parameters
        ----------
        data: str or DataFrame (Default: 'Undefined')
            The dataFrame to analyse, if string, use the preloaded data in the analyser.
        transac_plot: boolean (Default: True)
            Indicate if transactions data from server should be plotted.

        """
        # recover iterable shapely objects
        if isinstance(self.visDelim, pd.core.series.Series):
            if self.visDelimName in self.visDelim.index:
                visDelim = {self.visDelim[self.visDelimName]:self.visDelim['geometry']}
            else:
                visDelim = {'Secteur 1':self.visDelim['geometry']}

        elif isinstance(self.visDelim, pd.core.frame.DataFrame):
            if self.visDelimName in self.visDelim.columns:
                if self.visDelim.shape[0] > 1:
                    visDelim = self.visDelim.set_index(self.visDelimName)['geometry'].to_dict()
                else:
                    visDelim = {self.visDelim[self.visDelimName].iloc[0]: self.visDelim['geometry'].iloc[0]}

            else:
                if self.visDelim.shape[0] > 1:
                    visDelim = {f'Secteur {i+1}':geom for i,geom in enumerate(self.visDelim['geometry'])}
                else:
                    visDelim = {'Secteur 1':self.visDelim['geometry'].iloc[0]}

        #check for dpi overrides
        fig_dpi = kwargs.get('fig_dpi', self.fig_dpi)
        map_dpi = kwargs.get('map_dpi', self.map_dpi)
        leg_dpi = kwargs.get('leg_dpi', self.leg_dpi)

        mapLeg_dpi_kwargs = {}
        if fig_dpi is not None: mapLeg_dpi_kwargs['fig_dpi'] = fig_dpi
        if map_dpi is not None: mapLeg_dpi_kwargs['map_dpi'] = map_dpi
        if leg_dpi is not None: mapLeg_dpi_kwargs['leg_dpi'] = leg_dpi


        fig_dpi_kwargs = {}
        if fig_dpi is not None: fig_dpi_kwargs['fig_dpi'] = fig_dpi

        map_dpi_kwargs = {}
        if map_dpi is not None: map_dpi_kwargs['map_dpi'] = map_dpi

        leg_dpi_kwargs = {}
        if leg_dpi is not None: leg_dpi_kwargs['leg_dpi'] = leg_dpi

        # check for compass rose kwargs
        compass_rose = kwargs.get('compass_rose', True)

        ## base plots
        f_base.plot_heat_map(
            data,
            self.save_path+f'/{self.basename}_data_row_plot.png',
            lat_col=constants.DESTINATION_LAT, 
            lng_col=constants.DESTINATION_LNG,
            crs=self.data_crs, 
            rotation=self.visRotation, 
            compass_rose=compass_rose
        )

        if self.comp_occup:
            if 'add_cat_prc' in kwargs:
                add_cat_prc = kwargs['add_cat_prc']
            else:
                add_cat_prc = False
            if 'anotate_occ' in kwargs:
                anotate_occ = kwargs['anotate_occ']
            else:
                anotate_occ = False
            if 'build_leg' in kwargs:
                build_leg = kwargs['build_leg']
            else:
                build_leg = True

            print('|')
            print('|--- plotting capacity')
            # segments capacity
            path = os.path.join(self.save_path, 'capacity/')
            os.makedirs(path, exist_ok=True)
            ## overall capacity by visDelim
            capacity = self.restriction_handler.get_capacity(time_period='all')
            f_occup.segment_capacity_map(capacity,
                                         self.seg_gis,
                                         visDelim,
                                         path, restrictions=True,
                                         basename=self.basename,
                                         normalized=False,
                                         build_leg=build_leg,
                                         rotation=self.visRotation,
                                         fig_buffer=self.visBuffer,
                                         anotate=anotate_occ,
                                         compass_rose=compass_rose,
                                         **mapLeg_dpi_kwargs)

            ## capacity by day and hour
            if plot_all_capacities:
                for j in constants.CAP_DAYS_HOUR_TO_COMPUTE.keys():
                    hour = constants.CAP_DAYS_HOUR_TO_COMPUTE[j]['from']
                    end = constants.CAP_DAYS_HOUR_TO_COMPUTE[j]['to']
                    step = float(constants.CAP_DAYS_HOUR_TO_COMPUTE[j]['step'])

                    hour = Ctime.from_string(hour)
                    end = Ctime.from_string(end)
                    step = Ctime.from_declared_times(hours=step)
                    while hour <= end:
                        h = hour.as_string('hhmm')
                        capacity = self.restriction_handler.get_capacity(
                            time_period='dh', 
                            time_value=[j,h]
                        )
                        f_occup.segment_capacity_map(capacity,
                                                    self.seg_gis,
                                                    visDelim,
                                                    path, restrictions=True,
                                                    basename=self.basename + f"{j}_{h}_",
                                                    normalized=False,
                                                    build_leg=build_leg,
                                                    rotation=self.visRotation,
                                                    fig_buffer=self.visBuffer,
                                                    anotate=anotate_occ,
                                                    compass_rose=compass_rose,
                                                    save_geojson=True,
                                                    **mapLeg_dpi_kwargs)
                        hour += step
                    
            # Occupancy
            path = os.path.join(self.save_path, 'occ')
            os.makedirs(path, exist_ok=True)

            ## occupancy by timeslot
            f_occup.occupancy_map(occ_df=self.res['occ_timeslot'], cols=['mean_occ'],
                                  delims=visDelim,
                                  savepath=path,
                                  basename=self.basename,
                                  add_cat_prc=add_cat_prc,
                                  build_leg=build_leg,
                                  anotate=anotate_occ,
                                  rotation=self.visRotation,
                                  fig_buffer=self.visBuffer,
                                  compass_rose=compass_rose,
                                  **mapLeg_dpi_kwargs)


            #hours_col = parse_hours_bound(self.hours_bounds)
            cols = [col for col in self.res['occ_hour'].columns if col not in ['segment', 'side_of_street', 'segment_geodbl_geom', 'NomSecteur']]
            cols_trans = [col for col in cols if col in transac_c.HOURS]

            print('|--- plotting occupancy')
            # occupancy by hour
            f_occup.occupancy_map(occ_df=self.res['occ_hour'], cols=cols,
                                  delims=visDelim,
                                  savepath=path,
                                  basename=self.basename,
                                  add_cat_prc=add_cat_prc,
                                  build_leg=build_leg,
                                  anotate=anotate_occ,
                                  rotation=self.visRotation,
                                  fig_buffer=self.visBuffer,
                                  compass_rose=compass_rose,
                                  **mapLeg_dpi_kwargs)

            # transaction plot 
            if transac_plot:
                # transactions comparaison
                f_occup.compared_occupancy_map(occ1=self.res['occ_hour'],
                                               occ2=self.res['paid_parking_occ_hour'],
                                               cols=cols_trans, delims=visDelim,
                                               seg_gis=self.seg_gis,
                                               savepath=path, build_leg=build_leg,
                                               basename=self.basename,
                                               desc='transaction_horraire',
                                               rotation=self.visRotation,
                                               fig_buffer=self.visBuffer,
                                               **mapLeg_dpi_kwargs)

                f_occup.compared_occupancy_map(occ1=self.res['occ_timeslot'],
                                               occ2=self.res['paid_parking_occ_ts'],
                                               cols=['mean_occ'], delims=visDelim,
                                               seg_gis=self.seg_gis,
                                               savepath=path, build_leg=build_leg,
                                               basename=self.basename,
                                               desc='transaction_times_solt',
                                               rotation=self.visRotation,
                                               fig_buffer=self.visBuffer,
                                               **mapLeg_dpi_kwargs)

        if self.comp_rempla:
            if 'build_leg' in kwargs:
                build_leg = kwargs['build_leg']
            else:
                build_leg = True
            path = os.path.join(self.save_path, 'rempla')
            os.makedirs(path, exist_ok=True)

            print('|--- plotting rempla')
            f_rempla.remplacement_map(self.res['rempla_at_more'],
                                      cols=['park_time'],
                                      delims=visDelim,
                                      savepath=path,
                                      build_leg=build_leg,
                                      fig_name_base=f'{self.basename} At_more',
                                      rotation=self.visRotation,
                                      fig_buffer=self.visBuffer,
                                        **map_dpi_kwargs
                                        )

            f_rempla.remplacement_map(self.res['rempla_at_least'],
                                      cols=['park_time'],
                                      delims=visDelim,
                                      savepath=path,
                                      build_leg=build_leg,
                                      fig_name_base=f'{self.basename} At_least',
                                      rotation=self.visRotation,
                                      fig_buffer=self.visBuffer,
                                        **map_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_time(self.res['park_cat_at_least'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} At_least',
                                        **fig_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_time(self.res['park_cat_at_more'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} At_more',
                                        **fig_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_time(self.res['park_cat'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} All',
                                        **fig_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_distrib(self.res['park_time_dist_at_least'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} At_least',
                                        **fig_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_distrib(self.res['park_time_dist_at_more'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} At_more',
                                        **fig_dpi_kwargs
                                        )

            f_rempla.plot_cat_park_distrib(self.res['park_time_dist'],
                                        savepath=path,
                                        fig_base_name=f'{self.basename} All',
                                        **fig_dpi_kwargs
                                        )

        if self.comp_prov:
            if 'add_cat_prov' in kwargs:
                add_cat_prov = kwargs['add_cat_prov']
            else:
                add_cat_prov = False
            if 'anotate_prov' in kwargs:
                anotate_prov = kwargs['anotate_prov']
            else:
                anotate_prov = False
            if 'zoom_reg_prov' in kwargs:
                zoom_reg_prov = kwargs['zoom_reg_prov']
            else:
                zoom_reg_prov = None
            if 'build_leg' in kwargs:
                build_leg = kwargs['build_leg']
            else:
                build_leg = True

            path = os.path.join(self.save_path, 'prov')
            os.makedirs(path, exist_ok=True)

            print('|--- plotting provenance')

            ## Per region and period
            for region, reg_trips in self.res['trips'].groupby(['region']):
                ## Region
                f_prov.plot_distribution(reg_trips,
                                        save_path=path,
                                        basename=self.basename + f'_{region}_all_day_',
                                        **fig_dpi_kwargs
                                        )
                # montreal and CMM provenance map
                prov_reg = self.res['prov'][self.res['prov'].region == region].copy()
                prov_reg = prov_reg.groupby(['reg'])['prc_reg'].mean().to_frame().reset_index()
                prov_reg = prov_reg.join(self.res['prov'].set_index('reg')[['geometry']].drop_duplicates(), on='reg', how='inner')
                prov_reg = gpd.GeoDataFrame(prov_reg, geometry='geometry', crs=self.res['prov'].crs)

                f_prov.choropleth_prov_in_mtl(prov_reg,
                                            path,
                                            add_cat_num=add_cat_prov,
                                            anotate=anotate_prov,
                                            basename=self.basename + f'_{region}_all_day_',
                                            **map_dpi_kwargs)

                f_prov.choropleth_prov_in_artm(prov_reg,
                                            path,
                                            add_cat_num=add_cat_prov,
                                            anotate=anotate_prov,
                                            regs_zoom=zoom_reg_prov,
                                            basename=self.basename + f'_{region}_all_day_',
                                            **map_dpi_kwargs)

                # kde plot
                f_prov.kde_plot_in_artm(reg_trips,
                                        self.res['prov'],
                                        path,
                                        basename=self.basename + f'_{region}_all_day_',
                                        **map_dpi_kwargs)
                # tracedist stacked
                f_prov.trace_dist(reg_trips,
                                self.res['prov'][~self.res['prov'].reg.isin(['Hors ARTM'])],
                                which_days='all',
                                save_path=path,
                                basename=self.basename + f'_{region}_',
                                x_order=prov_hue_order,
                                **fig_dpi_kwargs
                                )

                # tracedist normalized
                f_prov.trace_dist(reg_trips,
                                self.res['prov'][~self.res['prov'].reg.isin(['Hors ARTM'])],
                                which_days='all',
                                how='normalized',
                                save_path=path,
                                basename=self.basename + f'_{region}_',
                                x_order=prov_hue_order,
                                **fig_dpi_kwargs
                                )

                for period, per_reg_trips in reg_trips.groupby(['period']):
                    # distance distribution
                    f_prov.plot_distribution(per_reg_trips,
                                            save_path=path,
                                            basename=self.basename + f'_{region}_{period}_',
                                            **fig_dpi_kwargs
                                            )
                    # montreal and CMM provenance map
                    f_prov.choropleth_prov_in_mtl(self.res['prov'][(self.res['prov'].period == period) & (self.res['prov'].region == region)],
                                                path,
                                                add_cat_num=add_cat_prov,
                                                anotate=anotate_prov,
                                                basename=self.basename + f'_{region}_{period}_',
                                                **map_dpi_kwargs)

                    f_prov.choropleth_prov_in_artm(self.res['prov'][(self.res['prov'].period == period) & (self.res['prov'].region == region)],
                                                path,
                                                add_cat_num=add_cat_prov,
                                                anotate=anotate_prov,
                                                regs_zoom=zoom_reg_prov,
                                                basename=self.basename + f'_{region}_{period}_',
                                                **map_dpi_kwargs)

                    # kde plot
                    f_prov.kde_plot_in_artm(per_reg_trips,
                                            self.res['prov'],
                                            path,
                                            basename=self.basename + f'_{region}_{period}_',
                                            **map_dpi_kwargs)

            # Parking time by distance
            #f_rempla.park_time_provenance(self.res['park_dist_at_least'],
                                        #savepath=path,
                                        #fig_base_name=f'{self.basename} At_least',
                                        #**fig_dpi_kwargs
                                        #)

            #f_rempla.park_time_provenance(self.res['park_dist_at_more'],
                                        #savepath=path,
                                        #fig_base_name=f'{self.basename} At_more',
                                        #**fig_dpi_kwargs
                                        #)


    def save(self, enrich_with_sector_names=True):
        """ Save all data computed in the analysis.

        Parameters
        ----------
        enrich_with_sector_names: Boolean (Default: True)
            Add the sector name to the saved data if True.
        """
        BLANK_LINE = '\n'

        # save base stats
        for name, data in self.res.items():
            data = data.copy()
            if data.empty:
                continue
            if constants.SEG_DB_GIS in data.columns:
                data.drop(columns=constants.SEG_DB_GIS, inplace=True)
            if constants.SEGMENT in data.columns and enrich_with_sector_names and constants.SECTEUR_NAME in self.seg_gis and not constants.SECTEUR_NAME in data:
                data[constants.SEG_DB_SIDE] = data[constants.SIDE_OF_STREET].map({-1:'Gauche', 1:'Droite'})
                data = data.join(self.seg_gis.set_index([constants.SEG_DB_ID, constants.SEG_DB_SIDE])[constants.SECTEUR_NAME], on=[constants.SEGMENT, constants.SEG_DB_SIDE])
                data.drop(columns=constants.SEG_DB_SIDE, inplace=True)

            data.to_csv(os.path.join(self.save_path, name+'.csv'), index=True, encoding='utf-8-sig')

        #write some variable description file
        with open(os.path.join(self.save_path, 'var_help.txt'), 'w') as file:
            file.write("SIDE_OF_STREET:\n" + BLANK_LINE + constants.SIDE_OF_STREET_INFO+"\n")
            file.write(BLANK_LINE)
            file.write("OCCUPATION:\n" + BLANK_LINE + constants.OCCUPATION_INFO+"\n")

    def process(self, handle_restriction=False, analyse='all', transactions=False, **kwargs):
        """ Compute all the analysis defined in the analysis.

        Parameters
        ----------
        handle_restriction: Boolean (Default: True)
            Remove restricted parking hit in the data.
        analyse: str (Default: 'all')
            Decide from which angle the data will be analysed. Value must be in :
            ['all', 'week_day', 'week_end', 'commercials', 'personnals']

        Returns
        -------
        None : Analysis perform without error
        -1 : Missing data for the analysis requested

        TODO: Move the analyse parameter in the analyse() func. Create a private 
        method to filter the data based on that paramater.
        """

        data = self.datastore.copy()
        trips = self.trips.copy()
        
        # 1. filter the data for the analyse angle choosen
        transac_plot = transactions
        if analyse == 'week_day':
            data = data[data[constants.DATETIME].dt.dayofweek.isin([0,1,2,3,4])].copy()
            if self.comp_prov:
                trips = trips[trips[constants.TRIPS_WEEK] == 'week_day'].copy()
        elif analyse == 'week_end':
            transac_plot = False
            data = data[data[constants.DATETIME].dt.dayofweek.isin([5,6])].copy()
            if self.comp_prov:
                trips = trips[trips[constants.TRIPS_WEEK] == 'week_end'].copy()
        elif analyse in ['commercials', 'personnals']:
            if not 'is_com' in data.columns:
                warnings.warn("L'analyse au niveaux du type de véhicule n'a pas"+
                             "pu être exécutée car le type de plaque n'est pas "+
                             "renseigné", MissingDataWarning)
                return -1
            if analyse == 'commercials':
                data = data[data.is_com.copy().fillna(False)].copy()
            else:
                data = data[~data.is_com.copy().fillna(False)].copy()

        if trips.empty and self.comp_prov:
            print('Analyse de provenance demandée mais il n\'y a pas de trajets à annalyser.')
            if data.empty:
                print('Il n\'y a pas de données à annalyser.')
                sys.exit(2)
        elif data.empty and trips.empty:
            print('Il n\'y a pas de données à annalyser.')
            sys.exit(2)

        # 2. set save path in fonction of analyse angle
        self.save_path = os.path.join(self.save_path, analyse)
        os.makedirs(self.save_path, exist_ok=True)

        # 3. perform analysis
        ## LAPI data
        self.analyse(data, trips, handle_restriction=handle_restriction, **kwargs)

        if transac_plot:
            ## Transactions
            paid_parking = TransactionHandler(self.days_bounds, self.delim, self.seg_gis)
            self.res['paid_parking_occ'] = paid_parking.occupancy
            self.res['paid_parking_occ_hour'] = paid_parking.occupancy_hour(filter=analyse)
            self.res['paid_parking_occ_ts'] = paid_parking.occupancy_timeslot(filter=analyse)

        # 4. plot analysis
        self.plot(data, transac_plot=transac_plot, **kwargs)

        # 5. save analysis in csv
        self.save()

        # 6. reset save_path
        self.save_path = deepcopy(self.project_save_path)

    def _base(self, data, handle_restriction, **kwargs):
        """ Compute base statistics on the data.

        Parameters
        ----------
        handle_restriction: Boolean 
            Remove restricted parking hit in the data.
        """
        data = data.copy()
        # remove veh on restricted segments
        if handle_restriction:
            data = data[~data[constants.CAP_IS_RESTRICT]]

        # Parse the hours bounds and compute for each day-hour the occupancy.
        # After computing multiple occupancy, aggregate it.
        stats_list = []
        datas = []
        for days, hours in self.hours_bounds.items():
            days_l = parse_days(days)
            ts_beg = hours[0]
            ts_end = hours[1]

            # parse data
            data_filter = data[data.datetime.dt.dayofweek.isin(days_l)].copy()
            sub_stats, sub_data = basic.compute_observation_stats(data_filter,
                                                timeslot_beg=ts_beg,
                                                timeslot_end=ts_end)
            stats_list.append(sub_stats)
            datas.append(sub_data)

        # aggregate data
        stats = pd.concat(stats_list, axis=0, ignore_index=False)

        # nb plaque unique total
        datas = pd.concat(datas)
        ttal = ['total', datas.shape[0], datas.plaque.unique().shape[0], datas.datetime.dt.hour.unique().shape[0]]
        stats = pd.concat([stats, pd.DataFrame([ttal], columns=['datetime', 'nb_plaques', 'nb_plaques_unq', 'nb_hours']).set_index('datetime')], axis=0)



        return stats

    def _occup(self, data, handle_restriction, occup_on='meter', round_time_on=60, round_method='ceil', veh_size=5.5, **kwargs):
        """Compute occupancy the data and config passed to the Analyser

        Parameters
        ----------
        data : pandas.DataFrame()
            The data on which perform the occup analysis.
        handle_restriction : boolean
            Do we clean lapi lecture that are present on a restricted road ?
        occup_on : str, optional
            The method to use to calculate the occupancy. The choices are 'meter' to
            calculate directly from the footprint of the sighted vehicules vs the
            availaible space or 'vehicule' to transform the available space in
            car-equivalent spaces and compare on a car vs acr-equiv. basis.
            Default 'meter'.
        round_time_on : int, optional
            Time interval used to round the time passages on. Default 30.
        round_method : str, optional
            Method used to round the passages. Must be one of 'ceil', 'floor',
            or 'round'. Default 'ceil'.
        Returns
        -------
        occh : geopandas.GeoDataFrame
            Aggregated occupancy by hour
        occts : pandas.DataFrame
            Aggregated occupancy by timeslot
                """
        data = data.copy()
        # remove veh on restricted segments
        if handle_restriction:
            data = data[~data[constants.CAP_IS_RESTRICT]]

        # Parse the hours bounds and compute for each day-hour the occupancy.
        # After computing multiple occupancy, aggregate it.
        occ_list = []; veh_sighted_list=[]; capacities_list=[]
        for days, hours in self.hours_bounds.items():
            days_l = parse_days(days)
            ts_beg = hours[0]
            ts_end = hours[1]

            # parse data
            data_filter = data[data.datetime.dt.dayofweek.isin(days_l)].copy()
            if data_filter.empty:
                continue

            occ_h, vehS, cap = occup.occupancy_h(self.seg_gis, data_filter, self.restriction_handler,
                                            occup_on=occup_on, round_time_on=round_time_on,
                                            round_method=round_method, veh_size=veh_size,
                                            timeslot_beg=ts_beg, timeslot_end=ts_end,
                                            round_interval=self.round_hours)

            occ_list.append(occ_h)
            veh_sighted_list.append(vehS)
            capacities_list.append(cap)

        # aggregate data
        occ_h = pd.concat(occ_list, axis=0, ignore_index=True)
        veh_sighted = pd.concat(veh_sighted_list, axis=0, ignore_index=True)
        capacities = pd.concat(capacities_list, axis=0, ignore_index=True)
        if occ_h.empty:
            return None, None

        occ_h = occ_h.drop(columns=constants.SEG_DB_GIS).pivot_table(
            index=['segment', 'side_of_street'],
            aggfunc=lambda x: restriction_aggfunc(x.to_list()),
            dropna=False
        ).reset_index()

        # we need to recover the seg_geodbl_geom lost in the aggregating func.
        # This can change if we make changes in analyse.occup. Maybe harmonize
        # columns names accross dataset
        occ_h.loc[occ_h.side_of_street == -1, 'COTE'] = 'Gauche'
        occ_h.loc[occ_h.side_of_street == 1, 'COTE'] = 'Droite'

        occ_h = occ_h.join(
            self.seg_gis.set_index(['ID_TRC', 'COTE'])['geometry'],
            on=['segment', 'COTE'],
            how='left'
        ).rename(columns={'geometry':constants.SEG_DB_GIS})\
         .drop(columns='COTE')

        occ_h = gpd.GeoDataFrame(occ_h, geometry=constants.SEG_DB_GIS)

        # compute occupancy timeslot
        occ_ts = occup.occupancy_timeslot(occ_h)

        return occ_h, occ_ts, veh_sighted, capacities

    def _occup_agg(self, veh_sighted, capacities):
        """ Compute the aggregated occupancy for all sector defined in config file.

        Paramters
        ---------
        veh_sighted : pandas.DataFrame
        Mean number of vehicules observed by side of street

        capacities : pandas.DataFrame
        Capacity by side_of_street.
        """

        #define some suffixes to use and then join the data
        _cap = '_cap'
        _veh = '_veh'

        #define what we join on, all the othe columns are normaly "hours"
        join_on = [constants.SEGMENT, constants.SIDE_OF_STREET, constants.SECTEUR_NAME]

        joined = pd.merge(capacities, veh_sighted, on = join_on,
                              suffixes=[_cap, _veh])

        res = []; veh=[]; cap=[]
        #proceed for each hour independently
        hours = [c for c in capacities.columns if c not in join_on]
        for hour in hours:

            _hourdf = joined.copy()
            #we need to clean everything that was a restrictions - they don't count in
            #aggregate. The rest of the data should be strings also, so we need to
            #identify whatever can be transformed as a float and keep it. NaNs count
            #in this category but agg will ignore them so it's all good.
            _hourdf['tf'+_veh] = _hourdf[hour+_veh].apply(lambda x: is_numeric_transformable(x))
            _hourdf['tf'+_cap] = _hourdf[hour+_cap].apply(lambda x: is_numeric_transformable(x))

            _hourdf = _hourdf[(_hourdf['tf'+_veh]) & (_hourdf['tf'+_cap])]

            #flip what's left to floats
            for col in [hour+_veh, hour+_cap]:
                _hourdf[col] = _hourdf[col].astype(float)

            agg = _hourdf.groupby(constants.SECTEUR_NAME).agg({hour+_veh:'sum', hour+_cap:'sum'})

            #create a total line, it's always usefull
            agg = agg.reset_index()
            agg = pd.concat([
                agg,
                pd.DataFrame().from_dict({constants.SECTEUR_NAME:['Tous secteurs'],
                 hour+_veh:[_hourdf[hour+_veh].sum()],
                 hour+_cap:[_hourdf[hour+_cap].sum()]})
            ], ignore_index=True).set_index(constants.SECTEUR_NAME, drop=True)
            
            #calculate the aggregate occupation level
            agg[hour] = agg[hour+_veh] / agg[hour+_cap]

            res.append(agg[hour].to_frame())
            veh.append(agg[hour+_veh].to_frame())
            cap.append(agg[hour+_cap].to_frame())

        #concant and tranpose since it's easier to read that way
        res = (pd.concat(res, axis=1) * 100 ).T
        veh = pd.concat([r.rename(columns={c:c.strip(_cap) for c in r.columns}) for r in veh], axis=1).T
        cap = pd.concat([r.rename(columns={c:c.strip(_cap) for c in r.columns}) for r in cap], axis=1).T

        #rename the index and drop the columns.name so the export is easier to read
        res.index.rename('Heure', inplace=True); res.columns.rename(None, inplace=True)
        veh.index.rename('Heure', inplace=True); veh.columns.rename(None, inplace=True)
        cap.index.rename('Heure', inplace=True); cap.columns.rename(None, inplace=True)

        return res, veh, cap

    def _rempla(self, data, handle_restriction=False, **kwargs):
        """Basic remplacement calculation function. 

        Parameters
        ----------
        handle_restriction: Boolean (Default: True).
            Do we remove from dataset all unpermited parked vehicule form data ?
        
        Returns
        -------
        rempla: Parking time computation for each parking instance.
        """
        data = data.copy()
        if handle_restriction:
            data = data[~data[constants.CAP_IS_RESTRICT]]

        data['hour'] = [Ctime.from_datetime(t) for t in data.datetime]

        rempl_list = []
        for days, hours in self.hours_bounds.items():
            days_l = parse_days(days)
            ts_beg = Ctime.from_string(hours[0])
            ts_end = Ctime.from_string(hours[1])

            data_filter = data[
                np.logical_and(
                    data.datetime.dt.dayofweek.isin(days_l),
                    np.logical_and(
                        data['hour'] <= ts_end,
                        data['hour'] >= ts_beg
                    )
                )
            ].copy()

            if data_filter.empty:
                continue

            rempl_list.append(rempla.compile_parking_time(data_filter))
        rempl = pd.concat(rempl_list, axis=0)

        return rempl


    def _prov(self, data, **kwargs):
        """Compute provenance of car in the data by the config passed
        to the Analyser.

        Parameters
        ----------
        handle_restriction : boolean
            Do we clean lapi lecture that are present on a restricted road ?

        Returns
        -------
        prov_by_reg : geopandas.GeoDataFrame
            Aggregated provenance by regions
        """
        data = data.copy()

        # handle nan values
        data = data[~data.rtaudl.isna()]
        try:
            data['is_com'] = data['is_com'].fillna(False)
        except KeyError:
            data['is_com'] = False

        # Compute count by region.
        trips_l = []
        prov_l = []
        for (period, region), data_f in data.groupby(['period', 'region']):
            trips_tmp, prov_tmp = prov.prov_by_region(data_f, self.discretisation_prov,
                                                     local_crs=self.local_crs)
            prov_tmp['period'] = period
            prov_tmp['region'] = region

            trips_l.append(trips_tmp) 
            prov_l.append(prov_tmp)
        
        trips_gdf = pd.concat(trips_l).reset_index(drop=True)
        prov_df = pd.concat(prov_l)

        if prov_df.empty:
            return None

        prov_nb = prov_df.pivot_table(
            index=['period', 'region', 'reg'],
            values=['nb_reg', 'nb_com_reg', 'nb_pers_reg'],
            aggfunc='sum'
        ).reset_index()

        prov_perc = prov_df.pivot_table(
            index=['period', 'region', 'reg'],
            values=['prc_reg', 'prc_com_reg', 'prc_pers_reg'],
            aggfunc='mean'
        ).reset_index().drop(columns=['period', 'region', 'reg'])

        prov_df = pd.concat([prov_nb, prov_perc], axis=1)
        prov_df = prov_df.merge(
            self.discretisation_prov,
            left_on='reg',
            right_on='Label'
        ).drop(columns='Label')

        prov_df = gpd.GeoDataFrame(prov_df, geometry='geometry')

        return trips_gdf, prov_df