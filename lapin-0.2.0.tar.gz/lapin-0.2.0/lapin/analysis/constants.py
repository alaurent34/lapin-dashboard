﻿"""
Useful constants

Created on Wed Jun  9 10:12:27 2021

@author: lgauthier
@author: alaurent
"""

from pyproj import CRS

# Matcher
OSRM_MATCH_COLUMNS = ['u', 'v', 'lat_match', 'lng_match']
OSRM_2_MATCHER = {
    'u':'u',
    'v':'v',
    'lat_match': 'lat_match',
    'lng_match': 'lng_match'
}

# Enhancer
INDEX = 'data_index'
UID = 'uuid'
PLAQUE = 'plaque'
ORIGIN_LAT = 'ori_lat'
ORIGIN_LNG = 'ori_lng'
DESTINATION_LAT = 'lat_s'
DESTINATION_LNG = 'lng_s'
DATETIME = 'datetime'
SEGMENT = 'segment'
POINT_ON_STREET = 'point_on_segment_s'
SIDE_OF_STREET = 'side_of_street'
LAP = 'lap'
LAP_TIME = 'lap_time'
SECTEUR_NAME = 'NomSecteur'

# ROADS
SEG_DB_GIS = 'segment_geodbl_geom'
SEG_DB_ID = 'ID_TRC'
SEG_DB_SIDE = 'COTE'
SEG_DB_STREET = 'NOM_VOIE'

REMPL_CAT_NO_PARK = 'Espace inoccupé'

# Capacities
CAP_START_RES = 'deb'
CAP_END_RES = 'fin'
CAP_RES_HOUR_TO = 'res_hour_to'
CAP_RES_HOUR_FROM = 'res_hour_from'
CAP_RES_DAYS = 'res_days'
CAP_RES_TYPE = 'res_type'
CAP_RESTRICTIONS = 'restrictions'
CAP_IS_RESTRICT = 'is_restrict'
CAP_DELIM_SPACE = 'longueur_marquée'
CAP_SPACE = 'longueur_non_marquée'
CAP_N_DELIM_S   = 'nb_places_marquées'
CAP_N_UNDELIM_S = 'nb_places_non_marquées'
CAP_N_VEH = 'nb_places_total'
CAP_CACHE_PATH = './cache'

CAP_PRIORITY = [
    'Travaux',
    'Non arrets', 'Arret de bus',
    'Saillie', 'Non parcourue',
    'Piétonnisation',
    'Terre-plein intérieur',
    'Centre intersection',
    'Interdiction',
    'Voie réservée',
    'Livraison', 'Taxi', 'Taxis',
    'Urgence','Police', 'STM',
    'Parking Parallele',
    'Ecole',
    'Entretien',
    'Entretien '
] 

CAP_DAYS_HOUR_TO_COMPUTE = {
    'lun': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'mar': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'mer': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'jeu': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'ven': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'sam': {'from':'07:00', 'to':'21:00', 'step':'1'},
    'dim': {'from':'07:00', 'to':'21:00', 'step':'1'}
}

# Trips
TRIPS_COLS = ['rtaudl', 'nb_plaque', 'region', 'period', 'week_day', 'dest_lat',
       'dest_lng', 'ori_lat', 'ori_lng']
TRIPS_WEEK = 'week_day'

# generated data
CACHE = './cache/'

# variable informations
SIDE_OF_STREET_INFO = """
    La variable side_of_street dépend du sens de numérisation de la géobase double
    qui lui-même suis le sens d'incrémentation des adresses.

        +-------------+----------------------+----------------+--------+-------+
        | ORIENTATION |     LOCALISATION     | SIDE_OF_STREET |  CÔTÉ  | RIVE  |
        +=============+======================+================+========+=======+
        | EST-OUEST   | Est de St-Laurent    |     -1         | GAUCHE | NORD  |
        +-------------+----------------------+----------------+--------+-------+
        | EST-OUEST   | Est de St-Laurent    |      1         | DROITE | SUD   |
        +-------------+----------------------+----------------+--------+-------+
        | EST-OUEST   | Ouest de St-Laurent  |     -1         | GAUCHE | SUD   |
        +-------------+----------------------+----------------+--------+-------+
        | EST-OUEST   | Ouest de St-Laurent  |      1         | DROITE | NORD  |
        +-------------+----------------------+----------------+--------+-------+
        | NORD-SUD    | Toutes               |     -1         | GAUCHE | OUEST |
        +-------------+----------------------+----------------+--------+-------+
        | NORD-SUD    | Toutes               |      1         | DROITE | EST   |
        +-------------+----------------------+----------------+--------+-------+
    """

OCCUPATION_INFO = """
    La valeur de l'occupation peut prendre les valeurs non-numériques suivantes:

    1.	La catégorie « non parcourue » désigne des tronçons de rue qui n’étaient
        pas incluses dans le plan de collecte de l’étude.
    2.	La catégorie « sans données » (NaN, blanc), quant à elle, peut à la fois
        désigner des tronçons qui étaient prévus mais n’ont pas pu être parcourue
        en raison des conditions terrains (travaux, manque de temps, etc.) ou des
        tronçons où aucun véhicule n’était présent. En effet, il pas possible dans
        l’état présent de la technologie utilisée de distinguer ces deux états
        car ils se traduisent de la même façon dans la base de données.
    3.	La catégorie « aucune place » désigne des tronçons où les obstacles et
        les interdictions de stationnement font en sorte qu’il est toujours
        interdit de s’y immobiliser.
    4.	La catégorie « travaux » désigne des tronçons qui étaient soit impossibles
        à parcourir ou des tronçons dont les places de stationnement étaient
        retirées en raison de chantiers de construction au moment de la collecte.

    """