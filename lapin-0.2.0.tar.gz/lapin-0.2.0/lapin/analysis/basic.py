"""
Created on Wed Jun  9 10:12:56 2021

@author: lgauthier
@author: alaurent
"""
import numpy as np
import pandas as pd

from ..tools.ctime import Ctime

def compute_observation_stats(lapi_enhance, timeslot_beg='00h00', timeslot_end='23h59'):
    """
    This function compute basic stats on LAPI data : count of the total number of vehicule,
    and count disctinct vehicule by day.

    Parameters
    ----------
    lapi_enhance : pandas.DataFrame
        The sighting data, must have been ran through the enhancement process
        beforehand.
    timeslot_beg : str
        Starting hour of the timeslot.
    timeslot_end : str
        Ending hour of the timeslot.

    Returns
    -------
    base_stats : pandas.DataFrame
        The basics observations statistics.
    
    """
    lapi_enhance = lapi_enhance.copy()

    # filter by timeslot
    #    1 - raw string to datetime
    lapi_enhance['time'] = pd.to_datetime(lapi_enhance.datetime)

    #    2 - datetime to ctime
    lapi_enhance['time'] = [Ctime.from_datetime(t) for t in lapi_enhance.time]

    #    4 - parse relevant hours
    lapi_enhance = lapi_enhance[(lapi_enhance['time'] >= Ctime.from_string(timeslot_beg)) &
                    (lapi_enhance['time'] <= Ctime.from_string(timeslot_end))
                    ]

    # make something usefull of datetime
    lapi_enhance.datetime = pd.to_datetime(lapi_enhance.datetime)

    base_stats = pd.concat([
        lapi_enhance.pivot_table(values='plaque', index=lapi_enhance.datetime.dt.date, aggfunc='count').rename(columns={'plaque':'nb_plaques'}),
        lapi_enhance.pivot_table(values='plaque', index=lapi_enhance.datetime.dt.date, aggfunc=lambda x: len(x.unique())).rename(columns={'plaque':'nb_plaques_unq'}),
        lapi_enhance.pivot_table(values='datetime', index=lapi_enhance.datetime.dt.date, aggfunc=lambda x: np.unique((x.dt.hour)).shape[0]).rename(columns={'datetime':'nb_hours'})
    ], axis=1) 
    ttal = ['period_subtotal', lapi_enhance.shape[0], lapi_enhance.plaque.unique().shape[0], lapi_enhance.datetime.dt.hour.unique().shape[0]]
    base_stats = pd.concat([base_stats, pd.DataFrame([ttal], columns=['datetime', 'nb_plaques', 'nb_plaques_unq', 'nb_hours']).set_index('datetime')], axis=0)

    return base_stats, lapi_enhance
