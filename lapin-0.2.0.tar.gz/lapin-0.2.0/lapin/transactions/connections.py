############################################
########## Connections config ##############
############################################

# sql-server (target db, datawarehouse)
PARK_OCCUPANCY = {
    'server': 'prisqlbiprod01',
    'database': 'CPTR_Station',
    'autocommit': False,
}

AXES = {
    'server': 'prisqlbiprod01',
    'database': 'Axes',
    'autocommit': False,
}

STAGING = {
    'server': 'prisqlbiprod01',
    'database': 'Staging',
    'autocommit': False,
}
