import os
import sys
import copy
import time
from tkinter import Tk
from tkinter.filedialog import askopenfilename
import warnings


import pandas as pd
import geopandas as gpd
import numpy as np

from .enhancement.core import enhance
from .enhancement.data import read_data

from .analysis import basic, occup, rempla, core, utils, constants, restrictions
from .figures import occup as f_occup
from .figures import base
from .transactions.core import TransactionHandler

from . import config

from shapely.errors import ShapelyDeprecationWarning

# warnings
# warnings.filterwarnings("ignore", category=ShapelyDeprecationWarning) 


def main(conf_path):
    print('Starting...')

    ##########################
    ##### RETRIEVE CONF ######
    ##########################

    try:
        conf = config.UserConfig(conf_path)
    except Exception as e:
        print('Please provide a valid conf file')
        print(e)
        sys.exit(1)
    print('Treating project : ', conf.titleProj)

    ## LAPI
    where_cond = " AND "
    for date in conf.daysBounds:
        where_cond += config.DEFAULT_WHERE.format(date['from'], date['to'])
        where_cond += ' OR '
    where_cond += " 1=2 "
    config.LAPI_CONNECTION['sql'] = config.DEFAULT_SQL + where_cond + config.ORDER_BY_SQL

    ## DELIM
    config.DELIM_CONNECTION['filename'] = conf.gisBounds
    config.VIS_DELIM_CONNECTION['filename'] = conf.gisVisBounds

    ## PLAQUES
    #config.PLAQUE_CONNECTION['filename'] = conf.plaquesCP
    #config.PLAQUE_IDX_CONNECTION['filename'] = conf.plaquesIdx
    #config.TYPE_PLAQUE_CONNECTION['filename'] = conf.plaquesType
    config.GEOREF_CP_CONNECTION['filename'] = conf.platesOriginGis

    # WORKDIR
    os.makedirs(conf.workFolder, exist_ok=True)

    # OPTIONAL
    if conf.roads != 'Default.def':
        config.ROADS_CONNECTION['filename'] = conf.roads
    if conf.roadsDbl != 'Default.def':
        config.ROADS_DB_CONNECTION['filename'] = conf.roadsDbl

    ##########################
    ####### READ DATA ########
    ##########################

    # LAPI data 
    df = read_data(config.LAPI_CONNECTION)
    # Road data
    roads = read_data(config.ROADS_CONNECTION)
    # Geographical delimitation
    delim = read_data(config.DELIM_CONNECTION)
    visDelim = read_data(config.VIS_DELIM_CONNECTION)
    # Roads with side of streets
    geodbl = gpd.sjoin(
        read_data(config.ROADS_DB_CONNECTION),
        delim.to_crs('epsg:4326'),
        predicate='within', how='inner').rename(columns={conf.gisBoundsNames:core.constants.SECTEUR_NAME}
    )
    # Regions discretisation
    regs = read_data(config.DISCRETISATION_CONNECTION)

    ##########################
    ######## ENHANCE #########
    ##########################

    # read or compute lapi enhancement
    cache_path = os.path.join(conf.workFolder, 'cache')
    print('LAPI Enhancing...')
    df_matched, trips = enhance(df, roads=roads, data_config=config.DATA_CONFIG,
                             roads_config=config.ROADS_CONFIG, shape=delim,
                             geodouble=geodbl,
                             act_prov=conf.act_prov,
                             save_path=cache_path,
                             cp_base_filename=conf.platesOriginFileName,
                             cp_folder_path=conf.platesOriginPath,
                             cp_regions_bounds=conf.platesOriginBounds,
                             cp_regions_bounds_names=conf.platesOriginBoundsName,
                             plates_periods=conf.platesOriginPeriods,
                             cp_conf=config.GEOREF_CP_CONNECTION,
                             lap_smoothing=True)
    print('LAPI enhancement finished!')

    # read or compute stationnement by segments
    try:
        print('Segments enhancing...')
        segments = pd.read_csv(os.path.join(cache_path, 'stationnements_par_segment.csv'))
        print('Getting data from cached!')
    except FileNotFoundError:
        segments = pd.read_excel(conf.capacities)[config.CAPACITIES_COLUMNS]
        segments.to_csv(os.path.join(cache_path, 'stationnements_par_segment.csv'), index=False)
        print('Segments enhancement finished!')

    # Apply restriction
    ### We do this here because in it's current version it take too much time
    restrictHandler = restrictions.RestrictionHandler(segments)
    if conf.handle_restriction:
        try:
            print('LAPI Restrictions...')
            df_matched = pd.read_csv(os.path.join(cache_path, 'data_enhanced_restrict.csv'), low_memory=False)
            print('Getting data from cached !')
        except FileNotFoundError:
            t0 = time.time()
            df_matched[constants.DATETIME] = pd.to_datetime(df_matched[constants.DATETIME])
            df_matched = restrictHandler.apply_restriction(
                    df_matched,
                    constants.INDEX,
                    ignore_hours=False,
                    ignore_days=False,
                    time_col=constants.DATETIME
                )
            t1 = time.time()
            # save them
            df_matched.to_csv(os.path.join(cache_path, 'data_enhanced_restrict.csv'), index=False)
            print(f'Process executed in {t1 - t0} seconds')
            print('LAPI Restrictions finished!')

    ###########################
    ######### ANALYSE #########
    ###########################

    veh_size = conf.vehSize
    if veh_size > 5.5:
        res_path = os.path.join(conf.workFolder, f'resultat/vehicules_size/{veh_size}')
    else:
        res_path = os.path.join(conf.workFolder, f'resultat/')

    analyser = core.Analyser(df_matched, segments, geodbl, delim, visDelim,
                             conf.hourBounds, conf.roundHours, conf.daysBounds, 
                             trips=trips, discretisation_prov=regs,
                             save_path=res_path, **conf.__dict__)

    # Extra config for analysis
    anotation          = conf.anotation
    build_leg          = conf.buildLeg
    occup_on           = conf.occupOn
    handle_restriction = conf.handleRestriction
    compass_rose       = conf.compassRose
    prov_hue_order     = conf.platesOriginPeriods['1'] if conf.act_prov else []
    anotation_prov     = conf.anotationProv
    zoom_reg_prov      = conf.regsZoomProv
    plot_all_capa      = conf.plotAllCapa

    if conf.distinct_com_pers:
        print('Commerciaux / Personnels')
        # commercials analysis
        print('Commerciaux')
        # put handle restriction in conf file
        analyser.process(analyse='commercials',
                         handle_restriction=handle_restriction,
                         build_leg=build_leg,
                         occup_on=occup_on,
                         veh_size=veh_size,
                         anotate_occ=anotation,
                         anotate_prov=anotation_prov,
                         zoom_reg_prov=zoom_reg_prov,
                         prov_hue_order=prov_hue_order,
                         compass_rose=compass_rose,
                         plot_all_capacities=plot_all_capa)

        # personnals analysis
        print('Personnels')
        # put handle restriction in conf file
        analyser.process(analyse='personnals',
                         handle_restriction=handle_restriction,
                         build_leg=build_leg,
                         occup_on=occup_on,
                         veh_size=veh_size,
                         anotate_occ=anotation,
                         anotate_prov=anotation_prov,
                         zoom_reg_prov=zoom_reg_prov,
                         prov_hue_order=prov_hue_order,
                         compass_rose=compass_rose,
                         plot_all_capacities=plot_all_capa)

    elif conf.distinct_week_days:
        print('Semaine / FdS')
        # week days analysis
        print('Semaine')
        # put handle restriction in conf file
        analyser.process(analyse='week_day',
                         handle_restriction=handle_restriction,
                         build_leg=build_leg,
                         occup_on=occup_on,
                         veh_size=veh_size,
                         anotate_occ=anotation,
                         anotate_prov=anotation_prov,
                         zoom_reg_prov=zoom_reg_prov,
                         prov_hue_order=prov_hue_order,
                         compass_rose=compass_rose,
                         plot_all_capacities=plot_all_capa)

        # week end analysis
        print('FdS')
        # put handle restriction in conf file
        analyser.process(analyse='week_end',
                         handle_restriction=handle_restriction,
                         build_leg=build_leg,
                         occup_on=occup_on,
                         veh_size=veh_size,
                         anotate_occ=anotation,
                         anotate_prov=anotation_prov,
                         zoom_reg_prov=zoom_reg_prov,
                         prov_hue_order=prov_hue_order,
                         compass_rose=compass_rose,
                         plot_all_capacities=plot_all_capa)

    # Global analyses
    print('Global')
    # put handle restriction in conf file
    analyser.process(analyse='all',
                     handle_restriction=handle_restriction,
                     build_leg=build_leg,
                     occup_on=occup_on,
                     veh_size=veh_size,
                     anotate_occ=anotation,
                     anotate_prov=anotation_prov,
                     zoom_reg_prov=zoom_reg_prov,
                     prov_hue_order=prov_hue_order,
                     compass_rose=compass_rose,
                     plot_all_capacities=plot_all_capa)
    print('Finished')

if __name__ == '__main__':

    # Select a config file
    Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
    config_file = askopenfilename(filetypes=[('Configuration files', '*.config')],
                                            initialdir=os.path.join(os.getcwd(),'../config_files'),
                                            title="Select files", multiple=False) # show an "Open" dialog box and return the path to the selected file
    # Execute main analysis
    main(config_file)