import pandas as pd
import numpy as np
from shapely.geometry import Point
import osrm

from . import constants

def osrm_parse_matchs(response):

    ### Retrieve match points
    # create an empty response
    empty_response = {'location':[0,0], 'name':None, 'hint':None, 'matchings_index':None, 'waypoint_index':None, 'alternatives_count':None}
    # create list of matchs
    tracepoints = [x if x is not None else empty_response for x in response['tracepoints']]
    # create a DataFrame of matchs
    res = pd.DataFrame.from_records(tracepoints)

    return res

def osrm_parse_legs(response): #, gdf_edges):
    ### retrieve each edge on match_points
    legs_df = pd.DataFrame(columns=['matchings_index', 'waypoint_index', 'u', 'v'])
    for i, matching in enumerate(response['matchings']):
        for j, leg in enumerate(matching['legs']):
            u = leg['annotation']['nodes'][0]
            v = leg['annotation']['nodes'][1]
            leg_i = j
            # append new row
            legs_df.loc[-1] = [i, leg_i, u, v]  # adding a row
            legs_df.index = legs_df.index + 1  # shifting index
            legs_df = legs_df.sort_index()  # sorting by index

            if j == len(matching['legs']) - 1: # on est au dernier point, il faut l'ajouter aussi
                u = leg['annotation']['nodes'][-2]
                v = leg['annotation']['nodes'][-1]
                leg_i = j+1
                # append last point
                legs_df.loc[-1] = [i, leg_i, u, v]  # adding a row
                legs_df.index = legs_df.index + 1  # shifting index
                legs_df = legs_df.sort_index()  # sorting by index

    # legs_df = legs_df.merge(gdf_edges, on=['u','v'], how='inner')
    legs_df = legs_df[['matchings_index', 'waypoint_index', 'u', 'v']]#, 'osmid']]

    # remove potential duplicate edges
    # legs_df = legs_df.loc[legs_df[['matchings_index', 'waypoint_index', 'u', 'v']].drop_duplicates(keep='first').index]

    return legs_df

def osrm_parse_response(response):#, edges_df):

    matchs = osrm_parse_matchs(response)
    legs = osrm_parse_legs(response) #, edges_df)

    matchs = pd.merge(matchs, legs, on=['matchings_index', 'waypoint_index'], how='left')
    # format location
    locations = np.stack(matchs['location'], axis=0)
    matchs['lng_match'] = locations[:,0]
    matchs['lat_match'] = locations[:,1]

    return matchs[constants.OSRM_MATCH_COLUMNS]

class MapMatcher():

    def __init__(self, host, return_edge=True):

        self.type = ''
        self.return_edge=return_edge
        self.host = host
        self.client = None

    def _start_client(self):
        client = osrm.Client(self.host, timeout=10)
        self._check_client(client)

    def _check_client(self, client):
        if isinstance(client, osrm.Client):
            self.type = 'osrm'
            self.client = client
            # self.map_cols = ['lat_ori', 'lng_ori', 'id_trc', 'u', 'v', 'lat_match', 'lng_match'] #, 'side_of_street']
            self.columns = constants.OSRM_MATCH_COLUMNS
        else:
            raise TypeError('MapMatcher constructor called with incompatible client and dtype: {e}'.format(e=type(client)))

    def match(self, coords, **kwargs):
        if self.client is None:
            self._start_client()

        if self.type == 'osrm':
            # assert kwargs['edges_osm_df'] # TODO: Checker pour ce param si osm
            return self._osrm_match(coords, **kwargs)
        else:
            raise NotImplementedError('There is no implementation for this matcher')

    def _osrm_match(self, coords, **kwargs):
        """ Coords is in format lat, lng np.array
        """

        coords = np.asarray(coords)
        assert coords.ndim == 2, 'Coordinates should be 2 dimensions'

        try:
            if kwargs:
                response = self.client.match(coordinates=coords[:, ::-1], **kwargs)
            else:
                response = self.client.match(
                    coordinates=coords[:, ::-1],
                    overview=osrm.overview.full,
                    annotations=True
                )
            if response['code'] != 'Ok':
                return pd.DataFrame()
        except osrm.OSRMClientException as e:
            print(f'Error happened when mapmatching : {e}')
            return pd.DataFrame()

        # retrieve paresed matchs
        matchs = osrm_parse_response(response)
        matchs = matchs.rename(columns=constants.OSRM_2_MATCHER)

        # concat with ori points
        assert matchs.shape[0] == coords.shape[0], f'Something went wrong during map matching: match shape {matchs.shape[0]} != coords shape {coords.shape[0]}'

        # return edges info ?
        if self.return_edge:
            return matchs
        col = self.columns.copy()
        col.remove('u')
        col.remove('v')

        return matchs[col]