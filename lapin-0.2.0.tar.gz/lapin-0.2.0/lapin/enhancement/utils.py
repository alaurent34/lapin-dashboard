import os
import itertools
from operator import itemgetter

import pandas as pd
import numpy as np
import geopandas as gpd
import pymssql
from shapely.geometry import LineString
from shapely.ops import transform
from scipy.spatial import cKDTree
from geopy.distance import geodesic
import osmnx as ox
from jellyfish.cjellyfish import damerau_levenshtein_distance

from . import constants
from ..tools.cgeom import Polyline2D
from ..tools.cgeom import Point as cPoint

def plates_dist(s1, s2, similarity=False):
    ''' Return the Damerau-Levenshtein distance between two licence plates.

    Parameters
    ----------
    s1: string
        First plate.
    s2: string
        Second plate.
    similarity: bool (Default:False)
        If true return the similarity instead of the distance.

    Returns
    -------
    dist: int.
        Distance bewteen plates
    '''
    max_dist = min(len(s1), len(s2)) + (max(len(s1), len(s2)) - min(len(s1), len(s2)))
    dist = damerau_levenshtein_distance(s1, s2)

    assert dist <= max_dist, "Distance cannot be superior to the maximum distance computed."

    if similarity:
        return (max_dist - dist) / max_dist
    
    return dist

def pairwise(str_list, distance=plates_dist):      
    """ Construct a levenshtein distance matrix for a list of 
     strings""" 
    dist_matrix = np.zeros(shape=(len(str_list), len(str_list)))
    for i in range(0, len(str_list)):
        for j in range(i+1, len(str_list)):
                dist_matrix[i][j] = distance(str_list[i], str_list[j])   
    for i in range(0, len(str_list)):
        for j in range(0, len(str_list)):
            if i == j:
                dist_matrix[i][j] = 0
            elif i > j:
                dist_matrix[i][j] = dist_matrix[j][i]
    return dist_matrix

def get_mask_avenue(data_enhanced, roads, avenue):

    roads = roads.copy()
    data = data_enhanced.copy()

    # ID_TRC of avenue with direction of traffic = direction of digitalisation
    avenue_seg_1 = roads[np.logical_and(roads.NOM_VOIE.str.contains(avenue), roads.SENS_CIR == 1)].ID_TRC.unique()
    # ID_TRC of avenue with direction of traffic != direction of digitalisation
    avenue_seg_2 = roads[np.logical_and(roads.NOM_VOIE.str.contains(avenue), roads.SENS_CIR == -1)].ID_TRC.unique()

    # roads segments that are not in the left of Rosemont
    mask_1 = ~np.logical_and(data.segment.isin(avenue_seg_1), data.side_of_street == -1)
    mask_2 = ~np.logical_and(data.segment.isin(avenue_seg_2), data.side_of_street == 1)

    return mask_1 & mask_2


def get_network_graph(city, network_type, simplify=False, save_path='./'):
     # lecture graph réseau routier
    try:
       gdf_edges = gpd.read_file(os.path.join(save_path,'edges_omnx'))
       # gdf_edges.drop(columns='geometry', inplace=True)
       gdf_edges = pd.DataFrame(gdf_edges)
       print('...from cache')
    except FileNotFoundError:
        print('...from osmnx')
        G = ox.graph_from_place(city, network_type=network_type, simplify=simplify)
        _, gdf_edges = ox.graph_to_gdfs(G)
        gdf_edges.to_file(os.path.join(save_path,'edges_omnx'))

    return G, gdf_edges

