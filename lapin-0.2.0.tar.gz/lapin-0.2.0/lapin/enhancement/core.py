from msilib.schema import File
import os
import sys
import re
import numpy as np
import pandas as pd
import geopandas as gpd

import pyproj
from shapely.ops import transform
from shapely.geometry import Point, MultiPoint
from geopy.distance import geodesic, great_circle
from sklearn.cluster import DBSCAN

from .mapmatching import MapMatcher
from . import utils
from . import constants

from .data import read_plaque
from ..tools import geohelper
from ..tools.cgeom import Vector2D
from ..tools.geohelper import MONTREAL_CRS, DEFAULT_CRS

def enhance(data, data_config, roads, roads_config, geodouble, shape, save_path,
           osrmhost='http://localhost:5000', act_occu=True, act_rempla=True,
           act_prov=False, cp_base_filename=None, cp_folder_path=None,
           cp_regions_bounds=None, cp_regions_bounds_names=None, plates_periods=None,
           cp_conf=None, lap_smoothing=True):
    """ Main function for enhancing row collected LAPI data. In sequence, this function:
        1. Mapmatch the collected data to the road with OSRM.
        2. Linear reference data to the geobase of Montreal.
        3. Compute logic vehicule lap through the streets.
        4. Smooth data inchorence by creating missing data and 
        clustering same vehicule position.
        5. Compute the side of curb on wich each vehicule is parked.
        6. Clean doublon and unwanted streets.
        7. Compute provenance if needed.


    Parameters
    ----------
    data: pandas.DataFrame
        Raw data collected through LAPI systems.
    data_config: dict
        Configuration for the names of the mandatory columns of raw data.
    roads: geopandas.GeoDataFrame
        Data of the roads centerline. We use the geobase of Montreal in our project.
    roads_config: dict
        Configuration for the names of the mandatory columns of roads centerline.
    geodouble: geopandas.GeoDataFrame
        Data representing the curbside of the roads centerlines.
    shape: geopandas.GeoDataFrame
        Delimitation of the study.
    save_path: string
        Ouptut path for the cache.
    osrmhost: string (Default: 'http://localhost:5000')
        URL of the OSRM engine.
    act_occu: boolean (Default: True)
        Unused. Deprecated.
    act_rempla: boolean (Default: True)
        Unused. Deprecated.
    act_prov: boolean (Default: False)
        Decide if the preprocessing of the data needed for the provenance analysis
        should be completed.
    plaque_conf: dict (Default: None)
        Configuration for the list of plate if act_prov is True.
    idx_conf: dict (Default: None)
        Configuration for the index between plate and postal code if act_prov is True.
    type_conf: dict (Default: None)
        Configuration for the file of vehicule type if act_prov is True.
    cp_conf: dict (Default: None)
        Configuration for the file of postal code if act_prov is True.

    Returns 
    -------
    enhanced_data: pandas.DataFrame
        Enhanced dataset of the raw data.

    Todo
    ----
    1. When we will be able to determine the side of the street with accuracy, we'll need
       to compute that before the laps and then compute laps on segment and side of street.
       Also, we need to ensure that lap smoothing work on side_of_street too. Especially 
       with dual sided routes. 
    2. If we're able to know on wich segments the LAPI's car was, then we should try to remove 
       hits reported on wrong segment. Thoose erroned hit will reduce the mean occupancy.
    """
    try:
        data_enhanced = pd.read_csv(save_path+'/data_enhanced.csv')
        print('Getting data from cached!')
    except FileNotFoundError:
        # instanciation de osrm
        osrmhost = osrmhost #TODO: à mettre dans config

        # enhancer
        enhancer = Enhancer(data, **data_config, save_path=save_path)

        # mapmatching
        print('MapMatching...')
        enhancer.mapmatching(osrmhost)

        # linear referencing
        print('Linear Referencing...')
        data_enhanced = enhancer.linear_referencing(roads, **roads_config, mapmatching=True, shape=shape)
        ## cleaning after geo_referencing
        data_enhanced = enhancer.clean_data(roads, **roads_config, distance=10)

        print('Lap computing...')
        # lapi collection timeframes
        ## should be done in last to prevent non sequential lap_id
        data_enhanced = enhancer.lapi_lap_sequences(delta_treshold=120)
        print('Car direction along street...')
        # get direction of the LPD veh on the street
        data_enhanced = enhancer.get_car_direction_along_street(roads=roads)

        print('Data smoothing...')
        # data smoothing for side_of_street and missing laps
        print('Park_position')
        data_enhanced = enhancer.park_pos_smoothing(delta=5.5)

        if lap_smoothing:
            print('Lap smoothing')
            data_enhanced = enhancer.lap_smoothing()

        print('Side of street...')
        # side of street
        data_enhanced = enhancer.side_of_street(roads, **roads_config, lat_c='lat_s', lng_c='lng_s')

        print('Data cleaning...')
        # Cleansing
        ## feeding the geodb geometry for mapping purposes
        data_enhanced = enhancer.add_segment_geom(geodouble)
        data_enhanced = enhancer.clean_data(roads, **roads_config, distance=10)

        # check
        enhancer.tests()

        print('Saving...')
        # saving
        data_enhanced.to_csv(os.path.join(save_path,'data_enhanced.csv'), index=False)

    # get origins
    if act_prov:
        try:
            trips = pd.read_csv(save_path+'/trips.csv')
            print('Trips - Getting data from cached!')
        except FileNotFoundError:
            print("Computing origins...")
            plaques = read_plaque(cp_base_filename, cp_folder_path, cp_regions_bounds,
                                cp_regions_bounds_names, plates_periods, cp_conf)
            trips = get_immo_origins(plaques, distance=True)
            trips.to_csv(os.path.join(save_path, 'trips.csv'), index=False)

        return data_enhanced, trips
    return data_enhanced, pd.DataFrame()

def get_immo_origins(plaques_data, distance=True):
    """ Add columns ori_lat, ori_lng and dist_ori_m to data. Those
    columns correspond to infered origin of the vehicules sighted.

    Parameters
    ----------
    plaques_data: pd.DataFrame.
        Correspondance between immatricualtion plaque and postal codes. 
    distance : boolean (Default: True).
        Indicates if the trip distance is to be computed.

    Returns
    -------
    data : pd.DataFrame
        Enhancer data with columns ori_lat, ori_lng and dist_ori_m added.
    """
    def distance(lat_x, lng_x, lat_y, lng_y):
        if np.isnan(lat_x) or np.isnan(lng_x):
            return -1
        if np.isnan(lat_y) or np.isnan(lng_y):
            return -1

        return geodesic((lng_x, lat_x), (lng_y, lat_y)).m

    data = plaques_data.copy()

    # distance
    if distance : 
        data["dist_ori_m"] = data.apply(
            lambda x: distance(x.dest_lat, x.dest_lng, x.ori_lat, x.ori_lng),
            axis=1
        )

        return data

def traitement_stationnement_par_seg(path, columns_of_interest, rename, sheets=[],
                                     mapping={'nord':-1, 'est':-1}, save_path=''):
    """ One time function used to compute the on street capacity for Bellechasse. 
    This function need to be removed and store elsewhere as it is too specific.

    """
    # parse all sheets
    df = pd.DataFrame()
    for sheet in sheets:
        df_tmp = pd.read_excel(path, sheet)
        # select columns
        df_tmp = df_tmp[df_tmp.columns.intersection(columns_of_interest)]
        # set the column as the one of the enhanced data
        df_tmp.rename(columns=rename, inplace=True)
        # concat
        df = pd.concat([df, df_tmp])

    # get the same representation as enhanced data
    df.side_of_street.replace(mapping, inplace=True)

    # drop nan segments
    df = df[~df.segment.isna()]

    # save
    df.to_csv(os.path.join(save_path, 'stationnements_par_segment.csv'), index=False)

    return df

class Enhancer():
    """ Enhancer framework. Helper class to tranform raw point into the input data for the 
    Analyser Framework.

    Paramaters
    ----------
    data: pandas.DataFrame
        The row data to enhance.
    lat_col: str (Default: 'lat')
        Column name for the latitude coordinate in data.
    lng_col: str (Default: 'lng')
        Column name for the latitude coordinate in data.
    uid_col: str (Default: 'uuid') 
        Column name for the uid of the car.
    date_col: str (Default: 'datetime')
        Column name for the timestamp of collection.
    save_path: str (Default: './cache/')
        Path for saving enhance data.
    crs: str (Default: 'epsg:4326')
        CRS of the latitude/longitude point.
    proj_crs: str (Default: 'epsg:32188')
        CRS to project the points into.
    """

    def __init__(self, data, lat_col=constants.LATITUDE, lng_col=constants.LONGITUDE,
                 uid_col=constants.UID, date_col=constants.DATETIME,
                 save_path=constants.CACHE, crs=DEFAULT_CRS,
                 proj_crs=MONTREAL_CRS, **kwargs):
        """ TODO
        """

        self.save_path=save_path
        self.data = data.copy()
        usercols_2_enhancer = {
            lat_col : constants.LATITUDE,
            lng_col : constants.LONGITUDE,
            uid_col : constants.UID,
            date_col : constants.DATETIME
            }
        self.crs = crs
        # rename columns
        self.data = self.data.rename(columns=usercols_2_enhancer)
        # make primary_key
        self.data = self.data.reset_index().rename(columns={'index':'data_index'})
        # save columns
        self.columns = list(self.data.columns)

        # create directory
        os.makedirs(self.save_path, exist_ok=True)

    def _to_crs(self, crs):
        """TODO
        """
        pass

    def set_data(self, data):
        """ Update data stored in enhancer.

        Parameters
        ----------
        data: pandas.DataFrame
            The new data. Columns have to be in enhancer format.
        """
        self.data = data
        self.columns = list(self.data.columns)

    def filter_by_mask(self, mask):
        """ Return and update data filtered.

        Parameters
        ----------
        mask: pandas.Series
            Mask to filter the data.
        """

        data = self.data.copy()
        data = data[mask]
        
        self.set_data(data)

        return data


    def mapmatching(self, host, return_edge=False):
        """ Return and updadte data with collected points matched onto the road.

        Parameters
        ----------
        host: str
            The url for the OSRM host.
        return_edge: boolean (Default: False)
            Return OSRM edge where points have matched.

        Returns
        -------
        data: pandas.DataFrame
            Data with matched point onto the roads. Addd columns 'lat_matched' and 'lng_matched'.
        """
        data = self.data.copy()

        try:
            df = pd.read_csv(os.path.join(self.save_path, 'data_matched.csv'))
            print('Mapmatching was already cached !')
        except FileNotFoundError:

            # mapmatcher
            mapmatcher = MapMatcher(host, return_edge=False)

            # make a day column
            data[constants.DATETIME] = pd.to_datetime(data[constants.DATETIME])
            data['day'] = data[constants.DATETIME].dt.date

            ### mapmatching
            ## iterate over each trip from each day
            df = pd.DataFrame()
            groups = data.groupby([constants.UID, 'day'])

            for (trip_id, date), data_trips in groups:
                print(f'Treating vehicule {trip_id} on day {date}')
                coords = data_trips[['lat', 'lng']].dropna().values
                # matching
                data_enanced = mapmatcher.match(coords)
                data_enanced['data_index'] = data_trips['data_index'].values
                # concat
                df = pd.concat([df, data_enanced])

            # drop day column
            data.drop(columns='day',inplace=True)
            print('Saving mapmatching...')
            # saving a cached version
            df.to_csv(os.path.join(self.save_path, 'data_matched.csv'), index=False)

        # enhancing data
        data = data.merge(df, on='data_index', how='left')
        self.set_data(data)

        return self.data

    def linear_referencing(self, roads, shape, roads_id_col='ID_TRC', mapmatching=True, local_crs=MONTREAL_CRS):
        """ Compute and return the linear reference (LR) of the points onto the road.

        Paramaters
        ----------
        roads: geopandas.GeoDataFrame
            Geometrie of the roads to match the points onto.
        shape: geopandas.GeoDataFrame
            Polygons. Spatial delimitation for the project. 
        roads_id_col: str (Default: 'ID_TRC')
            Column name. Unique identifier for the roads.
        mapmatching: boolean (Default: True)
            Choose matched point instead of collected points.
        local_crs: str (Default: 'epsg:32188')
            CRS of the local aera of the project.

        Return
        ------
        data: pandas.DataFrame
            Data with LR computed.
        """

        data = self.data.copy()
        if mapmatching:
            data = gpd.GeoDataFrame(data, geometry=gpd.points_from_xy(data['lng_match'], data['lat_match']), crs=self.crs)
        else:
            data = gpd.GeoDataFrame(data, geometry=gpd.points_from_xy(data['lng'], data['lat']), crs=self.crs)

        # Enforce crs matching
        roads = roads.copy().to_crs(self.crs)
        shape = shape.copy().to_crs(self.crs)

        # Clip data to the study zone limits
        columns_to_remove = ['index_right']+list(shape.columns) # maybe this can be remove since we enforce the columns at the end
        columns_to_remove.remove('geometry')
        roads_clip = gpd.sjoin(roads, shape, predicate='within', how='inner')\
                                               .reset_index(drop=True)\
                                               .drop(columns=columns_to_remove)
        data_clip = gpd.sjoin(data, shape, predicate='within', how='inner')\
                                               .reset_index(drop=True)\
                                               .drop(columns=columns_to_remove)

        # if no data in zone, exit
        if data_clip.empty:
            print('No Data in the studied area !')
            sys.exit(2)

        data_x_roads = geohelper.rtreenearest(data_clip, roads_clip, gdfB_cols=[roads_id_col])

        # drop points that fall in two zones
        data_x_roads_index = data_x_roads.sort_values(['data_index', 'dist'])[['data_index']].drop_duplicates(keep='first').index
        data_x_roads = data_x_roads[data_x_roads.index.isin(data_x_roads_index)].reset_index(drop=True)

        #### compute linear referencing
        # each point must be projected to compute distance in meters accuratly
        wgs84 = pyproj.CRS('EPSG:4326')
        local = local_crs
        project = pyproj.Transformer.from_crs(wgs84, local, always_xy=True).transform
        # loop all points
        list_dist = []
        for i in range(data_x_roads.shape[0]):
            line = roads_clip.loc[roads_clip[roads_id_col] == data_x_roads.loc[i, roads_id_col], 'geometry'].iloc[0]
            line = transform(project, line)
            point = Point(data_x_roads.loc[i, 'lng'], data_x_roads.loc[i, 'lat'])
            point = transform(project, point)
            list_dist.append(line.project(point))
        # set linear referencement
        data_x_roads['point_on_segment'] = list_dist

        ### Data cleansing
        # Add the two LR columns
        data_x_roads = data_x_roads[self.columns + [roads_id_col, 'point_on_segment']]
        data_x_roads.rename(columns={roads_id_col:'segment'}, inplace=True)

        # set data
        self.set_data(data_x_roads)

        return data_x_roads

    def side_of_street(self, roads, roads_id_col, data_road_col='segment', lat_c=constants.LATITUDE, lng_c=constants.LONGITUDE):
        """ Compute and return the side of street of the point collected as 
        the position of the point in regard to the matched road segment.

        Parameters
        ----------
        roads: geopandas.GeoDataFrame
            Geometrie of the roads to match the points onto.
        roads_id_col: str (Default: 'ID_TRC')
            Column name. Unique identifier for the roads.
        data_road_col: str (Default: 'segment')
            Column name. Unique identifier for the roads in data.
        lat_c: str (Default: 'lat')
            Column name for the latitude coordinate in data.
        lng_c: str (Default: 'lng')
            Column name for the latitude coordinate in data.

        Return
        ------
        data: pandas.DataFrame
            Data with side_of_street computed.
        """
        data = self.data.copy()
        if not 'dir_veh' in data.columns:
            raise ValueError("Column dir_veh must be created first.")

        # list of roads line
        roads_lines = pd.merge(data, roads, how='left', left_on=data_road_col, right_on=roads_id_col)['geometry']
        # list of points
        points = np.array(list(map(Point, data[lng_c], data[lat_c])), dtype=object)
        # vectorized func
        data['side_of_street'] = geohelper.vectorized_r_o_l(roads_lines, points)

        # TODO: clean side_of_street with known veh_direction
        ### data = pd.merge(data, roads[[roads_id_col, 'SENS_CIR']], how='left', left_on=data_road_col, right_on=roads_id_col)
        ### print('Incorect side of the streed data removed :', data.loc[(data.SENS_CIR == 0) & (data.dir_veh != -2) & (data.side_of_street != data.dir_veh), :].shape[0])
        ### data = data.loc[~((data.SENS_CIR == 0) & (data.dir_veh != -2) & (data.side_of_street != data.dir_veh)), :]# = data.loc[(data.SENS_CIR == 0) & (data.dir_veh != -2), 'dir_veh']
        ### data.drop(columns=[roads_id_col, 'SENS_CIR'])

        # save
        self.set_data(data)

        return data

    def primary_lap_sequence(self, delta_treshold=10):
        """ Create primary_lap and primary_lap_time columns in the DataFrame.
        Lap is infered for each road segment and vehicules that passed on it. If
        reading for a road segment by a vehicule have a gap of more than
        delta_treshold second, then a lap is created. The primary_lap_time is 
        infered as the first reading that makes the lap.

        Parameters
        ----------
        delta_treshold: int (Default:10)
            Time threshold used to infer laps, in seconds.

        Returns:
        data: pd.DataFrame
            Class data enhance with a primary lap sequence.
        """

        data = self.data.copy()
        #data veh_id because the pattroler_id is way to large to use as a key identifier
        data = data.assign(veh_id = data.uuid.replace({data.uuid.unique()[i]:i+1
                                                       for i in range(len(data.uuid.unique()))}))

        veh_point_max = data.groupby('veh_id').size().sort_index()
        #transform the date to something usable
        data.datetime = pd.to_datetime(data.datetime)
        data.sort_values('datetime', inplace=True)

        grouped = data.groupby(['segment', 'veh_id'])
        groups=[]
        for name, group in grouped:
            group.sort_values('datetime', inplace=True)
            group['td'] = [0] + [td.total_seconds() for td in
                                 np.asarray(group.datetime.tolist())[1:] -
                                 np.asarray(group.datetime.tolist())[:-1]
                                 ]
            group['primary_lap'] = (group.td > delta_treshold).cumsum()
            # each vehicule should have a different start lap 
            group['primary_lap'] = group['primary_lap'] + veh_point_max[name[1]-1] if name[1] != 1 else group['primary_lap'] 
            # get first lap time of every lap
            lap_time = group.groupby(['primary_lap']).datetime.nth(0).to_frame('primary_lap_time')
            group = group.join(lap_time, on='primary_lap')
            # save data 
            groups.append(group.drop(columns=['td']))

        data = pd.concat(groups)

        #self.set_data(data)

        return data

    def lapi_lap_sequences(self, delta_treshold=10):
        """ Adds lap and lap_time columns. Compute consecutive lap sequence 
        for all the segment and all the readings, independently of the vehicule
        that collected it. Based on Enhancer.primary_lap_sequence.

        If two vehicules starts a lap on the same segment as the same time,
        prevalance if accorded to one vehicule arbitrary. This prevalance is
        conserved for all others occurences of this scenario. 

        Parameters
        ----------
        delta_treshold: int (Default:10)
            Time threshold used to infer laps, in seconds.

        Returns
        -------
        data: pd.DataFrame
            Class data enhance with a primary lap sequence.
        """

        data = self.primary_lap_sequence(delta_treshold=delta_treshold)
        # sort data by primary_lap_time
        data.sort_values(['primary_lap_time', 'primary_lap'], inplace=True)

        grouped = data.groupby('segment')
        groups = []
        for name, group in grouped:
            # sort data by primary_lap_time
            group.sort_values(['primary_lap_time', 'primary_lap'], inplace=True)
            group['lap'] = (group.primary_lap.diff() != 0).cumsum()
            groups.append(group)

        data = pd.concat(groups)
        data['lap_id'] = 'veh' + data['veh_id'].astype('str') + '_' + data['lap'].astype('str') 

        # data cleaning
        data.rename(columns={'primary_lap_time':'lap_time'}, inplace=True)
        data.drop(columns='primary_lap', inplace=True)
        data.drop(columns='veh_id', inplace=True)

        self.set_data(data)

        return data

    def add_segment_geom(self, geobaseDouble):
        """ Add column segment_geodbl_geom. This columns correspond to
        the geometry of the geobase double passed in input.

        Parameters
        ----------
        geobaseDouble : pd.DataFrame.
            Geometry og road netwoork with side of street. Segment ID must 
            be the same as used in Enhancer data.

        Returns
        -------
        data : pd.DataFrame
            Enhancer data with geometry column segment_geodbl_geom added.

        """
        #we assume that df passed through the enhancement process first
        data = self.data.copy()

        #we need this to match correctly with the geobaseDouble
        data['COTE'] = data.side_of_street.map({-1:'Gauche', 1:'Droite'})

        data = (data.join(geobaseDouble.set_index(['ID_TRC', 'COTE'])['geometry'],
                          on=['segment', 'COTE'])
                    .rename(columns={'geometry':'segment_geodbl_geom'})
                    )

        self.set_data(data)

        return data

    def drop_duplicate_scan(self):
        """ Clean double readings in data. Doublons are determined by
        columns ['lap_id', 'segment', 'side_of_street', 'plaque'].
        
        Returns
        -------
        data: pd.DataFrame
            Enhancer data cleaned from doublons.

        Raise
        -----
        ValueError:
            Missing a columns in the DataFrame.
        """

        data = self.data.copy()

        if not 'lap_id' in data.columns:
            raise ValueError("Column lap_id must be created first.")
        if not 'segment' in data.columns:
            raise ValueError("Column semgent must be created first.")
        if not 'side_of_street' in data.columns:
            raise ValueError("Column side_of_street must be created first.")

        data = data[data.index.isin(data[['lap_id', 'segment', 'side_of_street', 'plaque']].drop_duplicates(keep='first').index)]

        self.set_data(data)

        return data

    def remove_points_far_from_road(self, roads, roads_id_col, distance=8):
        """ Clean data points that are far aside from the road segment.

        Paramaters
        ----------
        roads: gpd.GeoDataFrame.
            GeoDataFrame of the road networks.
        roads_id_col: string.
            Column name of road identifier.
        distance: int (Default: 8).
            Determine the buffer to classify noise points. In meters.
        """

        data = self.data.copy()
        if not 'segment' in data.columns:
            raise ValueError("Column semgent must be created first.")

        # roads to data crs
        roads.to_crs(self.crs, inplace=True)

        # list of roads line
        roads_lines = pd.merge(data, roads, how='left', left_on='segment', right_on=roads_id_col)['geometry']
        # list of points
        points = np.array(list(map(Point, data[constants.LONGITUDE], data[constants.LATITUDE])), dtype=object)           

        # compute distance
        dists = geohelper.vectorized_dist(roads_lines, points)

        # remove far points
        data = data[dists < distance]

        # save
        self.set_data(data)

        return data

    def park_pos_smoothing(self, delta=5):
        ''' Clean geographic position of plaque sighted in the data. Cluster 
        consecutive observations of same plaque sighted that are close (<delta).
        New geographic point for clustered plaque is determined as the median of
        all readings clustered. 

        Parameters
        ----------
        delta: int (Default: 10).
            Distance for clustering. In meters.

        Returns
        -------
        data: pd.DataFrame.
            Ehancer data, cleaned by clustering process.
        '''
        data = self.data.copy()

        # treat date columns
        data.datetime = pd.to_datetime(data.datetime)

        data.sort_values(['plaque','segment', 'lap', 'datetime'], inplace=True)
        grouped = data.groupby(['plaque', 'segment', 'dir_veh', data.datetime.dt.date])

        res = []
        for _, plaque_data in grouped:
            plaque_data.sort_values(['lap', 'datetime'], inplace=True)
            # generate median point for this cluster of vehicule
            median_point = plaque_data[['lng', 'lat']].iloc[0].values
            new_points_list = []
            cluster = [0]
            #print(median_point[1], ', ', median_point[0], ', 0, point, 0')

            for i in range(1, plaque_data.shape[0]):
                dist = great_circle(median_point[::-1], plaque_data.iloc[i][['lat', 'lng']].values).m
                #print(plaque_data.iloc[i][['lng', 'lat']].values[1], ', ', plaque_data.iloc[i][['lng', 'lat']].values[0], f', {i}, point, {dist}')
                
                if dist <= delta :
                    # update median point for cluster
                    median_point = MultiPoint([Point(median_point), Point(plaque_data[['lng', 'lat']].iloc[i])]).centroid.xy
                    median_point = np.array(median_point).flatten()
                    #print(median_point[1], ', ', median_point[0], f', m{i-1}-{i}, median, None')
                    
                    # extend cluster with this park
                    cluster.append(cluster[-1])

                else: # Point not in cluster
                    # create new cluster
                    cluster.append(cluster[-1]+1)
                    # append previous cluster median point
                    new_points_list.append(median_point)
                    # select new median point
                    median_point = plaque_data[['lng', 'lat']].iloc[i].values

            new_points_list.append(median_point) # append last point cluster

            # set cluster info
            plaque_data['cluster_id'] = cluster
            point_smooth = [Point(new_points_list[c]) for c in cluster]
            plaque_data['lat_s'] = [point.y for point in point_smooth]
            plaque_data['lng_s'] = [point.x for point in point_smooth]
            point_on_street_smooth = plaque_data.groupby('cluster_id')['point_on_segment'].agg('mean')
            plaque_data['point_on_segment_s'] = [point_on_street_smooth[cluster] for cluster in cluster]

            res.append(plaque_data)

        # save
        data_smoothed = pd.concat(res, axis=0)
        self.set_data(data_smoothed)

        return data_smoothed

    def get_car_direction_along_street(self, roads, roads_id_col='ID_TRC', use_roadmatching=True):
        '''Compute the direction of the LPD car on the segment for each lap
        
        Parameters
        ---------
        roads: GeoDataFrame
            Road netword GeoDataFrame
        use_roadmatching: bool (Default: True)
            Indicate to use road matched latitude and longitude or not. If 
            not, the raw data is used.

        Return
        ------
        data: pd.DataFrame.
            Ehancer data, with direction of LPD car computed. Columns dir_veh is 
            added.
        '''
        data = self.data.copy()
        if not 'lap' in data.columns:
            raise ValueError("Column lap must be created first.")
        if use_roadmatching and not 'lat_match' in data.columns:
            raise ValueError("""When using roadmatching, column lat_matched 
            and lng_matched must be created first.""")
        
        lat_c, lng_c = ('lat_match', 'lng_match') if use_roadmatching else ('lat', 'lng')
        
        groups = []
        for (segment, _), group in data.groupby(['segment', 'lap']):
            if group.shape[0] == 1:
                group['dir_veh'] = -2
                groups.append(group)
                continue

            group.sort_values(['datetime'], inplace=True)
           
            # get road direction
            road_x, road_y = roads[roads[roads_id_col] == segment].geometry.iloc[0].xy 
            road_x = np.array(road_x)[[0, -1]]
            road_y = np.array(road_y)[[0, -1]]
            road_vec = Vector2D.from_xylists(road_x, road_y)

            # get vehicule direction
            lap_x = group.iloc[[0, -1]][lng_c].values
            lap_y = group.iloc[[0, -1]][lat_c].values
            lap_vec = Vector2D.from_xylists(lap_x, lap_y)

            if lap_vec.get_lenght() == 0:
                group['dir_veh'] = -2
                groups.append(group)
                continue

            group['dir_veh'] = 1 if road_vec.get_angle_with_vector(lap_vec, as_degree=True) <= 90 else -1
            groups.append(group)
        data = pd.concat(groups)

        self.set_data(data)
        return data

    def lap_smoothing(self, max_lap_creation=3600):
        ''' Heuristic to add fake observations in Enhancer data. A fake 
        observation is added when a vehicule observed is part of same 
        geographical cluster and there is a lap gap beetween one observation
        and the next. 

        Returns
        -------
        data: pd.DataFrame

        Example
        -------

        Consider the following data:
        >>> data.head()
        |     segment | plaque   |   cluster_id | uuid |   lap | lap_id   | lap_time            | datetime            |
        |------------:|:---------|-------------:|:-----|------:|:---------|:--------------------|:--------------------|
        | 1.39006e+06 | G250     |            0 | 0    |    10 | veh2_10  | 2022-06-21 16:08:16 | 2022-06-21 16:08:25 |
        | 1.39006e+06 | G250     |            0 | 0    |    14 | veh2_14  | 2022-06-21 19:06:25 | 2022-06-21 19:06:29 |
        | 1.39006e+06 | G250     |            0 | 1    |    17 | veh1_17  | 2022-06-21 20:08:16 | 2022-06-21 20:08:22 |

        We can see that lap 11, 12, 13, 15 and 16 are missing but that the vehicule is part of the same cluster.

        >>> Enhancer(data).lap_smoothing()
        >>> data.head()
        |     segment | plaque   |   cluster_id | uuid |   lap | lap_id   | lap_time            | datetime            | modification   |
        |------------:|:---------|-------------:|:-----|------:|:---------|:--------------------|:--------------------|:---------------|
        | 1.39006e+06 | G250     |            0 | 0    |    10 | veh2_10  | 2022-06-21 16:08:16 | 2022-06-21 16:08:25 | nan            |
        | 1.39006e+06 | G250     |            0 | 0    |    11 | veh1_11  | 2022-06-21 16:08:24 | 2022-06-21 16:08:33 | added          |
        | 1.39006e+06 | G250     |            0 | 0    |    12 | veh1_12  | 2022-06-21 18:07:12 | 2022-06-21 18:07:21 | added          |
        | 1.39006e+06 | G250     |            0 | 0    |    13 | veh2_13  | 2022-06-21 18:07:12 | 2022-06-21 18:07:21 | added          |
        | 1.39006e+06 | G250     |            0 | 0    |    14 | veh2_14  | 2022-06-21 19:06:25 | 2022-06-21 19:06:29 | nan            |
        | 1.39006e+06 | G250     |            0 | 0    |    15 | veh1_15  | 2022-06-21 19:13:28 | 2022-06-21 19:13:32 | added          |
        | 1.39006e+06 | G250     |            0 | 0    |    16 | veh2_16  | 2022-06-21 20:08:15 | 2022-06-21 20:08:19 | added          |
        | 1.39006e+06 | G250     |            0 | 1    |    17 | veh1_17  | 2022-06-21 20:08:16 | 2022-06-21 20:08:22 | nan            |

        Missing laps have been added, along with the columns modification.

        '''

        data = self.data.copy()
        data.to_csv('./data_before_lap_smooth.csv')

        # treat date columns
        data.datetime = pd.to_datetime(data.datetime)
        data.lap_time = pd.to_datetime(data.lap_time)
        data['day'] = data.datetime.dt.date

        # sort values
        data.sort_values(['segment', 'day', 'lap', 'datetime'], inplace=True)
        # compute laps start and end
        lapsGB = data.groupby(['segment', 'lap'])[['datetime', 'lap_id', 'dir_veh']]
        laps = lapsGB.nth(0).rename(columns={'datetime':'first'})

        data_to_insert = []
        data['modification'] = np.nan

        grouped = data.groupby(['plaque', 'segment', 'dir_veh', 'cluster_id'])

        for (_, segment, dir_veh, _), plaque_data in grouped:
            plaque_data.sort_values('lap', inplace=True)

            for i in range(1, plaque_data.shape[0]):
                # check if lap are consecutive
                lap_before = plaque_data.iloc[i-1][['lap']].values[0]
                lap_after = plaque_data.iloc[i][['lap']].values[0]
                lap_time_before = plaque_data.iloc[i-1][['lap_time']].values[0]
                lap_time_after = plaque_data.iloc[i][['lap_time']].values[0]
                day_before = plaque_data.iloc[i-1].datetime.date()
                day_after = plaque_data.iloc[i].datetime.date()

                # if elapsed time is to much, don't smooth
                if (lap_time_after - lap_time_before).total_seconds() >= max_lap_creation:
                    continue

                # time for the car to get to the veh
                time_delta = plaque_data.iloc[i-1][['datetime']].values[0] -\
                        plaque_data.iloc[i-1][['lap_time']].values[0] 
                
                if lap_before != lap_after - 1 and day_before == day_after:        # There is a gap in the laps seq, fill it
                    for lap_missing in range(lap_before+1, lap_after):
                        if laps.loc[(segment, lap_missing), 'dir_veh'] != dir_veh:
                            continue
                        try:
                            row_to_insert = plaque_data.iloc[i-1].copy()
                            row_to_insert['data_index'] = f"I{lap_missing}_{row_to_insert['data_index']}"
                            row_to_insert['lap'] = lap_missing
                            row_to_insert['lap_id'] = laps.loc[(row_to_insert['segment'], lap_missing), 'lap_id']
                            row_to_insert['lap_time'] = laps.loc[(row_to_insert['segment'], lap_missing), 'first']
                            row_to_insert['datetime'] = row_to_insert['lap_time'] + time_delta
                            row_to_insert['modification'] = 'added'
                            
                            data_to_insert.append(row_to_insert.to_frame().T)
                        except KeyError: # There is a non temporal a gap in the lap sequence (i.e. deleted data) : skip
                            pass

            data_to_insert.append(plaque_data)

        data_smoothed = pd.concat(data_to_insert, axis=0)
        data_smoothed.sort_values('datetime', inplace=True)

        # save
        self.set_data(data_smoothed)

        return data_smoothed


    def filter_plates(self, personalized_plates=False):
        ''' Drop readings that are noise readings.

        Personalized plates based on : https://saaq.gouv.qc.ca/immatriculation/plaque-immatriculation-personnalisee

        Normal plates based on : https://saaq.gouv.qc.ca/immatriculation/categories-plaques-immatriculation

        Parameters
        ----------
        personalized_plates: boolean (Default: False)
            Indicator to keep personalized plates in the data. 

        Returns
        -------
        data: pd.DataFrame
            Enhance data filtered.
        '''
        data = self.data.copy()

        # keep this here in case it will come to use
        to_remove = r'[B8][AR]*R\w*|TR[O0]*[TT]*[0O]*[I1]R\w*|[E]*C[0O][L]*[1I]*E[R]*|[U]*TL[1I]SER|P[O0]{0,1}LICE'

        # personalized plates from 5 to 7 chars
        personized_plates_57 = r'[a-z]{0,2}[a-z]{5}|\d[a-z]{4,6}|[a-z]{4,6}'
        personized_plates_24 = r'\w{2,4}'

        # normal plates
        promenade = r'\d{3}[a-z]{3}|\d{3}H\d{3}|[a-z]{3}\d{3}|[a-z]\d{2}[a-z]{3}'
        promenade_cc_cd = r'c[cd]\d{4}'
        commercial = r'f[a-z]{2}\d{4}'
        trailer = r'r[a-z]\d{4}[a-z]'
        five_digit = r'(a|ae|ap|au)\d{5}'
        six_digit = r'(c|l|f)\d{6}'
        radio = r'(VA2|VE2)[a-z]{2,3}'
        electric = r'[vcl]\d{3}1VE$|c[cd]\d1VE'
        movable =  r'x[0-9a-z]\d{5}'
        other = r'[cf][a-z]{3}\d{3}'

        if personalized_plates:
            patterns = [
                personized_plates_57,
                personized_plates_24,
                promenade,
                promenade_cc_cd,
                commercial,
                trailer,
                five_digit,
                six_digit,
                radio,
                electric,
                movable,
                other
            ]
        else:
            patterns = [
                promenade,
                promenade_cc_cd,
                commercial,
                trailer,
                five_digit,
                six_digit,
                radio,
                electric,
                movable,
                other
            ]

        compiled_plates = re.compile(r'^(' + '|'.join(x for x in patterns) + r')', re.IGNORECASE)    

        # filter plates 
        data_f = data[data.plaque.apply(lambda x: True if re.match(compiled_plates, x) else False)]

        # print removed plates
        removed_plaque = ' ; '.join(data[~data.data_index.isin(data_f.data_index)].plaque.sort_values().unique())
        print(f'Plates removed by the process : {removed_plaque}')

        self.set_data(data_f)

        return data_f

    def denoize_plates(self):
        """ Function to remove noize from the OCR perform on plates. 
        
        Done by clustering plates along Damerau-Levenshtein Distance.

        Returns
        -------
        data: pd.DataFrame.
            Data with plates reading cleansed.

        Raise
        -----
            ValueError

        """
        data = self.data.copy()

        if not 'segment' in data.columns:
            raise ValueError("Column segment must be created first.")

        res = []
        test = False
        for _, df in data.groupby('segment'):
            plates = df.plaque.drop_duplicates().values
            pdist = utils.pairwise(list(plates))
            dbsc = DBSCAN(eps=2, min_samples=1, metric='precomputed').fit(pdist)

            labels, counts = np.unique(dbsc.labels_, return_counts=True)
            for label in labels[counts > 1]:
                test = True
                p_list = plates[dbsc.labels_ == label]
                c_center = df[df.plaque.isin(p_list)].plaque.value_counts().index[0]
                p_dict = {}
                for  p in p_list:
                    p_dict[p] = c_center
                df.replace({'plaque': p_dict}, inplace=True)
            res.append(df)
        
        if test:
            print('Des plaques ont changés de noms')
        data = pd.concat(res)
        self.set_data(data)

        return data


    def clean_data(self, roads, roads_id_col, distance=8, street_name=None):
        """ Perform cleaning operation sequentially. 
            1. Remove_points_far_from_road
            2. Filter plates
            3. Drop duplicates scan
            4. Remove street if wanted

        Parameters
        ----------
        roads: gpd.GeoDataFrame
            Geometry of roads.
        roads_id_col: string
            Name of ID columns of roads.
        distance: int (Default: 8)
            Remove points at this distance of a road. In meter.
        street_name: string (Default: '')
            Name of the street to remove from the data.
        Returns
        -------
        data: pd.DataFrame.
            Data cleaned.
        """
        # remove too far points
        self.remove_points_far_from_road(roads, roads_id_col, distance)
        # denoize plates
        self.denoize_plates()
        # filter plates data
        self.filter_plates()
        # drop duplicates
        try:
            self.drop_duplicate_scan()
        except ValueError as e:
            print('Duplicates could not be removed : ', str(e))
            pass
        # remove street
        if street_name:
            mask = utils.get_mask_avenue(self.data, roads, avenue=street_name)
            self.filter_by_mask(mask)

        # get data
        data = self.data.copy()

        return data

    def tests(self):
        """ Perform some rudimentary data quality test.
        """

        data = self.data.copy()
        # Lap non sequential
        nb_unseq_lap = np.count_nonzero( 
            data[['segment', 'lap']].drop_duplicates().sort_values(['segment','lap']).lap.diff() != 1
        )
        if nb_unseq_lap != data.segment.unique().shape[0]:
            print(f'nb_unseq_lap : {nb_unseq_lap} != nb_segment : {data.segment.unique().shape[0]}\n')
            print('There is lap_id which are not sequential, expect some errors in parking_time() compilation')
