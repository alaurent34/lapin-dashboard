import itertools
import os
import numpy as np
import pandas as pd
import geopandas as gpd
from ..tools.geohelper import DEFAULT_CRS
from sqlalchemy import create_engine, text, types

def getEngine(server, database, driver, Trusted_Connection='yes', autocommit=True, fast_executemany=True, **kwargs):
    """ Create a connection to a sql server via sqlalchemy
    Arguments:
    server -- The server name (str). e.g.: 'SQL2012PROD03'
    database -- The specific database within the server (str). e.g.: 'LowFlows'
    driver -- The driver to use for the connection (str). e.g.: SQL Server
    trusted_conn -- Is the connection to be trusted. Values are 'yes' or 'No' (str). 
    """
    
    if driver == 'SQL Server':
        engine = create_engine(
            f"mssql+pyodbc://{server}/{database}"
            f"?driver={driver}"
            f"&Trusted_Connection={Trusted_Connection}"
            f"&autocommit={autocommit}",
            fast_executemany=fast_executemany
        )
    else: 
        raise NotImplementedError('No other connections supported')
    return engine

def createWktElement(geom):
    """ Transform byte geometry to text WKT
    """
    return geom.wkt

class Geometry(types.UserDefinedType):
    """ Class to specify the geometry type to sqlalchimy for SQLServer
    """

    def get_col_spec(self):
        return "GEOMETRY"

    def bind_expression(self, bindvalue):
        # Note that this does *not* format the value to the expression text, but
        # the bind value key.
        return text(f'GEOMETRY::STGeomFromText(:{bindvalue.key}, 4326)').bindparams(bindvalue)

def read_data(data_config):
    """ TODO
    """
    if data_config['type'] == 'sql':
        con = getEngine(**data_config)
        #pymssql.connect(server=data_config['server'], database=data_config['database'])
        return pd.read_sql(con=con, sql=data_config['sql'])
    elif data_config['type'] == 'geodata':
        load = gpd.read_file(**data_config)
        if load.crs is None:
            raise ValueError(f'Missing crs for {data_config["filename"]}, cannot proceed further')
        return load.to_crs(DEFAULT_CRS)
    elif data_config['type'] == 'xls':
        return pd.read_excel(data_config['filename'])

def read_plaque(base_filename, folder_path, regions_bounds, regions_bounds_names, plates_periods, geocode_conf):
    """ TODO
    """
    basefilename = base_filename
    path = folder_path
    regions = gpd.read_file(regions_bounds).to_crs('epsg:32188')
    regions_list = regions[regions_bounds_names].to_list()
    periods = plates_periods.values()
    cp_gis = read_data(geocode_conf)

    data = []
    for r, p, w in itertools.product(regions_list, *periods):
        data_tmp = pd.read_excel(os.path.join(path, basefilename.format(r, p, w)))
        data_tmp.columns = ['rtaudl', 'champ2', 'code_muni', 'muni', 'code_region', 'nb_plaque']
        data_tmp = data_tmp[['rtaudl', 'nb_plaque']]
        data_tmp['region'] = r
        data_tmp['period'] = p
        data_tmp['week_day'] = w
        centroid = regions.loc[regions[regions_bounds_names] == r].centroid.to_crs('epsg:4326').values[0]
        data_tmp['dest_lat'] = centroid.y
        data_tmp['dest_lng'] = centroid.x
        data_tmp = data_tmp[~data_tmp.rtaudl.isna()]
        data_tmp.rtaudl = data_tmp.rtaudl.str.upper()
        data.append(data_tmp)
        
    data = pd.concat(data)
    data = data.join(cp_gis.set_index('postalcode')[['geometry']], on='rtaudl', how='inner')
    data['ori_lat'] = data.geometry.apply(lambda x: x.centroid.y)
    data['ori_lng'] = data.geometry.apply(lambda x: x.centroid.x)
    data = data.drop(columns='geometry')

    # repeat count to have single veh trips
    data = data.reset_index(drop=True)
    data = data.loc[data.index.repeat(data.nb_plaque)]
    data = data.reset_index(drop=True)
    data = data.drop(columns='nb_plaque')

    return data

def read_plaque_deprecated(plaques_config, plaques_idx_config, types_config, geocode_config):
    """ TODO
    """
    # Treat plaques_config
    plaques = read_data(plaques_config)
    idx = read_data(plaques_idx_config).rename(columns={'NO_PLAQUE':'plaque', 'Champ2':'champ2'})

    plaques.columns = ['rtaudl', 'champ2', 'code_muni', 'muni', 'code_region', 'nb_plaque']
    plaques =  plaques.merge(idx, on='champ2', how='left')
    plaques = plaques[~plaques.plaque.isna()]
    plaques.drop(columns=['champ2', 'code_muni', 'muni', 'code_region', 'nb_plaque'], inplace=True)

    # treat geocode_config
    geocode_rta = read_data(geocode_config).to_crs('epsg:32188')
    geocode_rta['centroid'] = geocode_rta.geometry.centroid
    geocode_rta.drop(columns=['objectid', 'st_area_sh', 'st_length_'], inplace=True)

    # merge plaque, geocode
    plaques = plaques.merge(
        geocode_rta[['postalcode', 'centroid']],
        left_on='rtaudl', right_on='postalcode',
        how='inner'
    ).drop(columns='postalcode')

    # get lat_ori, lng_ori
    plaques = gpd.GeoDataFrame(plaques.rename(columns={'centroid':'geometry'}), geometry='geometry', crs=geocode_rta.crs)
    plaques.to_crs('epsg:4326', inplace=True)
    plaques['lat'] = plaques.geometry.y
    plaques['lng'] = plaques.geometry.x
    plaques.drop(columns='geometry')

    # treat type config
    try:
        type_plaque = read_data(types_config)
        type_plaque.columns = ['plaque', 'type_veh', 'type_util', 'type_user']
        type_plaque['is_com'] = np.logical_and(type_plaque.type_util != 'PROME', ~type_plaque.type_util.isna())
        type_plaque = type_plaque[['plaque', 'is_com']]

        # merge plaque, type
        plaques = plaques.merge(type_plaque, on='plaque', how='left')
    except FileNotFoundError:
        print('No information about the vehicule type !')
        pass

    return plaques