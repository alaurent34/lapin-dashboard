"""
Useful constants
"""
# Matcher
OSRM_MATCH_COLUMNS = ['u', 'v', 'lat_match', 'lng_match']
OSRM_2_MATCHER = {
    'u':'u',
    'v':'v',
    'lat_match': 'lat_match',
    'lng_match': 'lng_match'
}

# Enhancer
UID = 'uuid'
LATITUDE = 'lat'
LONGITUDE = 'lng'
ORIGIN_LAT = 'origin_lat'
ORIGIN_LNG = 'origin_lng'
DESTINATION_LAT = 'destination_lat'
DESTINATION_LNG = 'destination_lng'
DATETIME = 'datetime'

# generated data
CACHE = './cache/'
